#!/bin/sh

#execute with root permission 
#sudo ./install.sh

# args: config-line
update_configtxt() {
    BOOTCFG="/boot/config.txt"
    if ! grep -q "$1" "$BOOTCFG"; then
        echo "$1" >> "$BOOTCFG"
    fi
}

apt-get update
apt-get install python3 python3-pip wiringpi python3-tk
sudo apt-get install libatlas-base-dev
sudo pip3 install wiringpi

sudo apt-get install gnuplot

#Python requirements
pip3 install -r requirements.txt

#make sure you can use tty
usermod -a -G tty $(whoami)
usermod -a -G dialout $(whoami)

# Add PWM configuration to the config.txt
update_configtxt "dtoverlay=pwm,pin=18,func=2"
update_configtxt "gpio=18=a5"

./update.sh

#TODO install JLinkExe
wget https://www.segger.com/downloads/jlink/JLink_Linux_arm.tgz
mkdir /opt/SEGGER/JLink


#install the local MQTT broker
#and make sure it runs at bootup with systemctl enable broker.service

#necessary to get user into dialout and tty group
reboot
