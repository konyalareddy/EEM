'''
Similar to WirepasMiddleware.py class,
but oriented to send commands and read events from Anylift devices
'''
from robot.api.deco import keyword, library
from robot.libraries.BuiltIn import BuiltIn
from robot.api import logger 


from time import sleep

from Mesh import *

import logging
import json
import base64
import ssl
import re

try:
    import paho.mqtt.client as mqtt
except ModuleNotFoundError:
    print("Please install Paho mqtt wheel: pip install paho-mqtt")
    exit(-1)



@library(scope='GLOBAL', auto_keywords=True)
class AnyliftMiddleware(Mesh):


    def connect(self, host, port, username, password,
                gateway_id, network_address):


        # Create an MQTT client
        self.mqtt = mqtt.Client(client_id="a:lx1oxl:yabb330-provisioning-app",
            clean_session=True, protocol=mqtt.MQTTv311)

        #use the 1.10.0-SS-Mesh-v1-test AnyliftApplication(30-11-20) without setting user and pass
        if username != "" and password != "":

            logging.debug("use credentials: {} - {}".format(username, password))

            self.mqtt.tls_set(ca_certs=None, certfile=None, keyfile=None, 
                cert_reqs=ssl.CERT_REQUIRED, tls_version=ssl.PROTOCOL_TLS, ciphers=None)
            self.mqtt.username_pw_set(username, password)
        

        self.mqtt.on_connect = self._on_connect_callback
        self.mqtt.on_disconnect = self._on_disconnect_callback

        assert network_address is not None
        self.network_address = network_address

        self.host = host

        logging.debug("Connecting to MQTT: {}".format(host))

        self.connected = False
        self.mqtt.connect(host, int(port), keepalive=480)
        self.mqtt.loop_start()

        # Wait for 5 seconds the answer
        timeout = 10
        while not self.connected and timeout > 0:
            logging.debug("Connection timeout in {}".format(timeout))
            sleep(1)
            timeout -= 1

        if not timeout:
            raise NameError("Cannot connect to MQTT")


        logging.debug("Connected to MQTT")
        self.mqtt.loop_stop()


        if gateway_id == "" or gateway_id is None:
            self.topic_base = "iot-2"
        else:
            #use gateway id as Anylift ID
            self.topic_base = "iot-2/type/anylift/id/{}".format(gateway_id)

        logging.debug("Using topic base: {}".format(self.topic_base))

        
    def _on_connect_callback(self, client, userdata, flags, rc):
        logging.debug("..Connected to MQTT, rc: {}".format(rc))
        self.connected = True

    def _on_disconnect_callback(self, client, userdata, rc):
        logging.debug("..MQTT disconnected rc={}".format(rc))
        self.connected = False

    def info(self):
        event_received = None

        def _on_message(client, userdata, message):
            nonlocal event_received
            logging.debug(message.payload)
            event_received = json.loads(message.payload)['d']

        self.send_receive_mqtt_message(
            "/cmd/dst/fmt/json",
            "/evt/dst/fmt/json",
            {},
            _on_message,
            timeout=5,
        )

        if event_received is None:
            raise NameError("Didn't receive events on topic.")

        return event_received

    def get_idle_event(self):
        event_received = None

        self.configure_with_json({ 'idle_event': 1, 'idle_interval': 30 })

        def _on_message(client, userdata, message):
            nonlocal event_received
            print(message.topic)
            print(message.payload)
            event_received = json.loads(message.payload)
            return True

        # Only receive from the idle event
        self.send_receive_mqtt_message(
            None,
            "/evt/idle/fmt/json",
            {},
            _on_message,
            timeout=35,
        )

        self.configure_with_json({ 'idle_event': 1, 'idle_interval': 14400 })

        return event_received

  
    def ping_single(self, address):

        topic = "local/wirepas/cmd"

        data_dict = {"ping": int(address)}

        data_json = json.dumps(data_dict)

        logging.debug("Publishing on topic: {}, data: {}".format(topic, data_dict))

        def _on_publish(client, userdata, mid):
            logging.debug("publish callback message ID: {}".format(mid))

        self.mqtt.on_publish =_on_publish

        mex = self.mqtt.publish(topic, payload=None, qos=2, retain=False)

        logging.debug("message ID: {}".format(mex.mid))

        mex.wait_for_publish()


    def _hex_to_base64(self, input):
        #bytes format needed for base64, decode uft-8 needed to get a string
        return base64.b64encode(bytes.fromhex(input)).decode("utf-8") 

    def _base64_to_hex(self, input):
        return base64.b64decode(input).hex()

    def get_config(self):
        topic_cfg = "{}/cmd/cfg/fmt/json".format(self.topic_base)
        topic_cfg_evt = "{}/evt/cfg/fmt/json".format(self.topic_base)

        event_received = None

        def _on_message(client, userdata, message):
            nonlocal event_received
            #logging.debug(message.payload)
            event_received = json.loads(message.payload)['wirepas']


        self.mqtt.on_message =_on_message

        logging.debug("Subcribe on topic: {}".format(topic_cfg_evt))

        self.mqtt.subscribe(topic_cfg_evt, qos=0)

        logging.debug("Publishing on topic: {}, data: None".format(topic_cfg))

        self.mqtt.loop_start()

        mex = self.mqtt.publish(topic_cfg, payload=None, qos=2, retain=False)

        mex.wait_for_publish()

        logging.debug("published")

        timeout = 10

        while event_received is None and timeout > 0:
            logging.debug("Timeout in {}".format(timeout))
            sleep(1)
            timeout -= 1

        if event_received is None:
            raise NameError("Didn't receive events on topic.")

        logging.debug("Done")

        self.mqtt.loop_stop()

        return event_received


    def _default_anylift_json_config(self):
        base64_cipher_key = self._hex_to_base64('100F0E0D0C0B0A090807060504030201')
        base64_authentication_key = self._hex_to_base64('0102030405060708090A0B0C0D0E0F10')
        return {"wirepas":
            {
                "node_address": "1",
                "network_address": "{}".format(self.network_address),
                "network_channel": "2",
                "node_role": "17", #low latency sink

                #TODO: unclear what up/down means here
                "downstream_endpoints": [
                    [
                        "255",
                        "240"
                    ],
                    [
                        "101",
                        "101"
                    ],
                    [
                        "100",
                        "100"
                    ],
                    [
                        "1",
                        "1"
                    ],
                    [
                        "2",
                        "2"
                    ],
                    [
                        "3",
                        "3"
                    ],
                    [
                        "30",
                        "30"
                    ]
                ],
                "upstream_endpoints": [
                    [
                        "240",
                        "255"
                    ],
                    [
                        "101",
                        "101"
                    ],
                    [
                        "100",
                        "100"
                    ],
                    [
                        "1",
                        "1"
                    ],
                    [
                        "2",
                        "2"
                    ],
                    [
                        "3",
                        "3"
                    ],
                    [
                        "30",
                        "30"
                    ]
                ],
                "authentication_key": "{}".format(base64_authentication_key),
                "encryption_key": "{}".format(base64_cipher_key),
            }
        }

    def create_sniffer_cmd_config(self, ch1, ch2='', service='', sensors=''):
        """This creates a JSON-style YABB330 sniffer configuration from arguments
        that are similar to the TLD.create_sniffer_cmd_config.

        The values for the JSON come from the IoT-SSR-53 requirement.
        """

        def split_list(lst):
            return re.split(r'\s*,\s*', lst)

        serial_config_values = {
            'off': 'serial_off',
            '7n1': 'serial_7n1',
            '8n1': 'serial_8n1',
            '7o1': 'serial_7o1',
            '8o1': 'serial_8o1',
            '7e1': 'serial_7e1',
            '8e1': 'serial_8e1',
            '7n2': 'serial_7n2',
            '8n2': 'serial_8n2',
            '7o2': 'serial_7o2',
            '8o2': 'serial_8o2',
            '7e2': 'serial_7e2',
            '8e2': 'serial_8e2',
        }

        def parse_channel_config(chdata):
            type_values = {
                'no': 'no_activity',
                'unknown': 'unknown_bus_sniffer',
                'uart': 'uart_bus_sniffer',
                'can': 'can_bus_sniffer',
                'unknown_bits': 'unknown_bus_bits_sniffer',
            }
            polarity_values = {
                'n': 'negative',
                'p': 'positive',
            }
            inverted_values = {
                '': False,
                'inverted': True,
            }

            fields = split_list(chdata.lower())
            return {
                'type': type_values[fields[0]],
                'polarity': polarity_values[fields[1]],
                'bitrate': int(fields[2]),
                'config': serial_config_values[fields[3]],
                'inverted': inverted_values[fields[4]],
                'gain': int(fields[5]) & 0xFF,
            }

        def parse_service_config(srvdata):
            type_values = {
                'off': 'service_port_off',
                'uart': 'service_port_uart',
                'rs232': 'service_port_rs232',
                'rs422': 'service_port_rs422',
                'rs485_full_duplex': 'service_port_rs485_full_duplex',
                'rs485_half_duplex': 'service_port_rs485_half_duplex',
                'can': 'service_port_can',
                'rs422_low_speed': 'service_port_rs422_low_speed',
                'rs485_full_duplex_low_speed': 'service_port_rs485_full_duplex_low_speed',
                'rs485_half_duplex_low_speed': 'service_port_rs485_half_duplex_low_speed',
            }
            flow_values = {
                '': 0,
            }
            option_values = {
                '': 0,
                'thyssen_break': 1,
            }

            fields = split_list(srvdata.lower())
            return {
                'type': type_values[fields[0]],
                'bitrate': int(fields[1]),
                'config': serial_config_values[fields[2]],
                # TODO: There is no flow field or options field defined
                # 'flow': flow_values[fields[3]],
                # 'options': option_values[fields[4]],
            }

        sensor_values = {
            '': False,
            'sensors': True,
        }

        # if channel2 configuration is not given, use the same as for channel1
        if ch2 == '':
            ch2 = ch1

        # If service configuration is not given, disable it
        if service == '':
            service = 'off,0,off,,,'

        return {
            'ch1': parse_channel_config(ch1),
            'ch2': parse_channel_config(ch2),
            'service_port': parse_service_config(service),
            'sensors': sensor_values[sensors],
        }


    def configure_with_json(self, data_dict):
        topic_cfg = "{}/cmd/cfg/fmt/json".format(self.topic_base)

        data_json = json.dumps(data_dict)

        logging.debug("Publishing on topic: {}, data: {}".format(topic_cfg, data_dict))

        self.mqtt.loop_start()

        mex = self.mqtt.publish(topic_cfg, payload=data_json, qos=2, retain=False)

        mex.wait_for_publish()

        self.mqtt.loop_stop()

        logging.info("Cfg sent")


    def configure(self, additional_config={}):

        data_dict = self._default_anylift_json_config()
        data_dict = {**data_dict, **additional_config}

        self.configure_with_json(data_dict)


    def configure_sniffing(self, ch1, ch2='', service='', sensors=''):
        data_dict = {
            'yabb330': self.create_sniffer_cmd_config(ch1, ch2, service, sensors)
        }
        self.configure_with_json(data_dict)


    def send(self, address=1, payload='0000',
        source_endpoint=255, destination_endpoint=240, timeout=15):

        #for Robot everything is a string
        address = int(address)
        source_endpoint = int(source_endpoint)
        destination_endpoint = int(destination_endpoint)

        assert payload
        # avoid confusion when matching strings in hex such as e1 vs E1
        payload = payload.lower()
        payload = self._hex_to_base64(payload)


        topic = "{}/cmd/mesh_raw/fmt/json".format(self.topic_base)

        data_dict = {
            'dst_addr': address,
            'data': payload,
            'src_ep': source_endpoint,
            'dst_ep': destination_endpoint
        }

        data_json = json.dumps(data_dict)

        logging.debug("Publishing on topic: {}, data: {}".format(topic, data_dict))

        self.mqtt.loop_start()

        mex = self.mqtt.publish(topic, data_json, qos=2)

        mex.wait_for_publish()

        self.mqtt.loop_stop()

    def receive(self, address=1,
                source_endpoint=240, destination_endpoint=255,
                timeout=30, amount=1):

        #for Robot everything is a string
        # Listen to all traffic
        if address is None:
            events = dict()
        else:
            # Listen to a specific address
            address = int(address)
            events = []

        source_endpoint = int(source_endpoint)
        destination_endpoint = int(destination_endpoint)
        amount = int(amount)
        timeout = int(timeout)

        topic = "{}/evt/mesh_raw/fmt/json".format(self.topic_base)

        all_messages = []

        def _on_response_received(client, userdata, mqtt_message):
            nonlocal events
            payload = json.loads(mqtt_message.payload)
            nonlocal all_messages
            all_messages.append(payload)
            try:
                data = self._base64_to_hex(payload['data'])
                addr = int(payload['src_addr'])
                print('SRC addr {} (expect {}) data {}'.format(addr, address, data))
                if address is not None:
                    if address == addr:
                        events.append(data)
                    else:
                        logging.debug("not matching")
                else:
                    # Append or create a list item
                    events.setdefault(addr, []).append(data)
            except Exception as e:
                logging.debug("unexpected format")
                print('Exception {}'.format(e))
                pass

        self.mqtt.on_message =_on_response_received

        logging.debug("Subcribe on topic: {}".format(topic))

        logging.debug("Expect data on source_ep {}, dst_ep: {}".format(
            source_endpoint,
            destination_endpoint
        ))

        logging.debug("Wait Event on topic %s" % topic)

        self.mqtt.subscribe(topic, qos=0)
        self.mqtt.loop_start()

        while len(events) < amount and timeout > 0:
            logging.debug("Timeout in {}".format(timeout))
            sleep(1)
            timeout -= 1

        self.mqtt.loop_stop()
        self.mqtt.unsubscribe(topic)

        logging.debug('All messages: {}'.format(all_messages))
        logging.debug('Events: {}'.format(events))

        if timeout == 0 and len(events) == 0:
            logging.debug("Timeout to received")
            raise NameError("Didn't receive events on topic.")

        logging.debug("Done")

        return events

    def send_receive(self, address=1, 
                    payload='0000',
                    send_source_endpoint=255,  send_destination_endpoint=240,
                    receive_source_endpoint=240,  receive_destination_endpoint=255,
                    timeout=30, amount=1):

        '''
        self.send(address=dest_addr, payload=payload,
            source_endpoint=send_source_endpoint, destination_endpoint=send_destination_endpoint)

        return self.receive(address=dest_addr, source_endpoint=receive_source_endpoint, 
            destination_endpoint=receive_destination_endpoint)
        '''

        #for Robot everything is a string
        address = int(address)
        send_source_endpoint = int(send_source_endpoint)
        send_destination_endpoint = int(send_destination_endpoint)
        receive_source_endpoint = int(receive_source_endpoint)
        receive_destination_endpoint = int(receive_destination_endpoint)
        timeout = int(timeout)
        amount = int(amount)


        assert payload
        # avoid confusion when matching strings in hex such as e1 vs E1
        payload_orig = payload.lower()
        payload = self._hex_to_base64(payload_orig)


        topic_cmd = "{}/cmd/mesh_raw/fmt/json".format(self.topic_base)
        topic_evt = "{}/evt/mesh_raw/fmt/json".format(self.topic_base)

        data_dict = {
            'dst_addr': address,
            'data': payload,
            'src_ep': send_source_endpoint,
            'dst_ep': send_destination_endpoint
        }

        data_json = json.dumps(data_dict)

        events = []

        raw_message = None

        def _on_message(client, userdata, message):
            nonlocal events
            payload = json.loads(message.payload)
            logging.debug(payload)
            nonlocal raw_message
            raw_message = payload

            try:
                #todo filter address?
                addr = int(payload['src_addr'])
                logging.debug("Received packet from addr: {}".format(addr))
                if int(payload['src_ep']) == receive_source_endpoint and \
                    int(payload['dst_ep']) == receive_destination_endpoint:
                    data = self._base64_to_hex(payload['data'])
                    events.append(data)
                    logging.debug("Rx in Hex: {}".format(data))
                else:
                    logging.debug("not matching")
            except:
                logging.debug("unexpected format")
                pass

        self.mqtt.on_message =_on_message

        logging.debug("Subcribe on topic: {}".format(topic_evt))
        logging.debug("Expect data on source_ep {}, dst_ep: {}".format(receive_source_endpoint
            , receive_destination_endpoint))

        self.mqtt.subscribe(topic_evt, qos=0)

        logging.debug("Publishing on topic: {}, data: {}".format(topic_cmd, data_json))
        logging.debug("Hex: {}".format(payload_orig))

        self.mqtt.loop_start()

        mex = self.mqtt.publish(topic_cmd, payload=data_json, qos=2, retain=False)

        mex.wait_for_publish()

        logging.debug("published")


        while len(events) < amount and timeout > 0:
            logging.debug("Timeout in {}".format(timeout))
            sleep(1)
            timeout -= 1

        if len(events) == 0:
            raise NameError("Didn't receive events on topic.")

        logging.debug("Done")

        self.mqtt.loop_stop()
        self.mqtt.unsubscribe(topic_evt)

        logging.debug("send_receive raw message: {}".format(raw_message))

        return events

    def send_receive_mqtt_message(self, topic_cmd, topic_evt, data,
                                  onmessage_fn, qos=0, timeout=5, topic_base=None):
        """Generic send and receive message via MQTT."""

        if topic_base is None:
            topic_base = self.topic_base

        if topic_cmd is not None:
            topic_cmd = '{}{}'.format(topic_base, topic_cmd)

        topic_evt = '{}{}'.format(topic_base, topic_evt)

        timeout = int(timeout)
        qos = int(qos)

        data_json = None
        if data is not None:
            data_json = json.dumps(data)

        should_stop = False

        def _on_message(client, userdata, message):
            nonlocal should_stop
            should_stop = onmessage_fn(client, userdata, message)

        self.mqtt.on_message = _on_message

        logging.debug("Subcribe on topic: {}".format(topic_evt))
        self.mqtt.subscribe(topic_evt, qos=0)

        self.mqtt.loop_start()

        if topic_cmd is not None:
            logging.debug("Publishing on topic: {}, data: {}".format(topic_cmd, data_json))
            mex = self.mqtt.publish(topic_cmd, payload=data_json, qos=qos, retain=False)
            mex.wait_for_publish()
            logging.debug("published")

        while should_stop is False and timeout > 0:
            logging.debug("Timeout in {}".format(timeout))
            sleep(1)
            timeout -= 1

        self.mqtt.loop_stop()
        self.mqtt.unsubscribe(topic_evt)

    def list_nodes(self, timeout = 30, amount=10):
        topic_cmd = "local/wirepas/cmd"
        topic_evt = "local/wirepas"

        timeout = int(timeout)
        amount = int(amount)

        data_dict = {"neighbors": ""}

        data_json = json.dumps(data_dict)

        nodes = []

        event_received = False

        def _on_message(client, userdata, message):
            nonlocal event_received
            nonlocal nodes
            payload = json.loads(message.payload)
            logging.debug(payload)

            try:
                n = int(payload['number_of_neighbors'])
                event_received = True
                if n != 0:
                    #assumed to be a list
                    nodes = list(payload["neighbors"])
            except:
                logging.debug("wrong message")
                pass


        self.mqtt.on_message =_on_message

        logging.debug("Subcribe on topic: {}".format(topic_evt))

        self.mqtt.subscribe(topic_evt, qos=0)

        logging.debug("Publishing on topic: {}, data: {}".format(topic_cmd, data_json))

        self.mqtt.loop_start()

        mex = self.mqtt.publish(topic_cmd, payload=data_json, qos=2, retain=False)

        mex.wait_for_publish()

        logging.debug("published")

        while event_received is False and timeout > 0:
            logging.debug("Timeout in {}".format(timeout))
            sleep(1)
            timeout -= 1

        if event_received is False:
            raise NameError("Didn't receive events on topic.")

        self.mqtt.loop_stop()
        self.mqtt.unsubscribe(topic_evt)

        logging.info("Done listing, found nodes: {}".format(nodes))

        return nodes

    #override the mesh.py since AL does many things in automatic
    def start_otap_nodes(self, otap_file, nodes_str,
                version, application):

        try:
            self.upload_scratchpad(otap_file)
        except:
            pass #Might fail because or read only filesystem

        self.restart_stidi_application()

        #ping the sink, make sure it's running
        self.wait_available(1)

        time.sleep(5)

        self.almid.configure()

        #for Anylift device, you just upload the file and wait....

        self.verify_application(nodes_str, version, application)
    

    def send_receive_anylift_json(self, data, timeout=5, target='mesh'):
        topic_cmd = "{}/cmd/{}/fmt/json".format(self.topic_base, target)
        topic_evt = "{}/evt/{}/fmt/json".format(self.topic_base, target)

        data_json = None
        if data is not None:
            data_json = json.dumps(data)

        payload = None
        def _on_message(client, userdata, message):
            nonlocal payload
            payload = json.loads(message.payload)

        self.mqtt.on_message = _on_message
        logging.debug("Subcribe on topic: {}".format(topic_evt))
        logging.debug("Publishing on topic: {}, data: {}".format(topic_cmd, data_json))

        self.mqtt.subscribe(topic_evt, qos=0)
        self.mqtt.loop_start()

        # Send data only if data given
        if data_json is not None:
            mex = self.mqtt.publish(topic_cmd, payload=data_json, qos=2, retain=False)
            mex.wait_for_publish()
            logging.debug("published")

        while payload is None and timeout > 0:
            logging.debug("Timeout in {}".format(timeout))
            sleep(1)
            timeout -= 1

        self.mqtt.loop_stop()
        self.mqtt.unsubscribe(topic_evt)

        logging.debug("Received JSON payload: {}".format(payload))

        return payload

    def join(self, node_str=""):
        #request phase
        rc_already_joined=409
        rc_accepted=102

        #after wait (up to 2 minutes)
        rc_tout=404
        rc_success=200

        try:
            node_str = int(node_str)
        except:
            pass

        data_dict = {
                    "reqId":"0056",
                    "action":"join",
                    "nodeId": node_str,
                    "keyIdx": int(1)
                    }

        def parse_rc(payload):
            try:
                return int(payload['rc'])
            except:
                raise NameError("wrong message")

        payload = self.send_receive_anylift_json(data_dict, timeout=5)
        rc = parse_rc(payload)

        if rc == rc_accepted:
            logging.debug("request accepted")

            # Wait for a response for 300 seconds
            payload = self.send_receive_anylift_json(None, timeout=300)

            if payload is None:
                raise NameError("Didn't receive events on topic.")

            rc = parse_rc(payload)

            if rc == rc_success:
                logging.debug("SUCCESS")

            if rc == rc_tout:
                raise NameError("Request has timed out (120 sec)")
        else:
            logging.debug("Request not accepted")

            if rc == rc_already_joined:
                logging.debug("already joined!")
            else:
                raise NameError("Request not accepted")

        logging.info("Done")


    def change_application(self, node_str, application="yabb330_app", verify=True):

        # convert the application name to Anylift format
        appmap = {"yabb330_app": "yabb330"}
        if application in appmap:
            application = appmap[application]

        try:
            node_str=int(node_str)
        except:
            pass

        data_dict = {
            "reqId": "assign-{}-{}".format(node_str, application),
            "action": "assign",
            "application": application,
            "nodeId": node_str
        }

        rc_assigned=102
        rc_updated=200

        def parse_rc(payload):
            try:
                return int(payload['rc'])
            except:
                raise NameError("wrong message")

        payload = self.send_receive_anylift_json(data_dict, timeout=30)
        rc = parse_rc(payload)

        if rc == rc_assigned:
            logging.debug("application assigned")

            # Wait for a response for maximum of 7 minutes
            payload = self.send_receive_anylift_json(None, timeout=7*60)
            rc = parse_rc(payload)
            if rc == rc_updated:
                logging.debug("application updated")
                return
            else:
                raise NameError('Application update failed: {}'.format(rc))
        else:
            raise NameError('Application assign failed: {}'.format(rc))

    def enable_remote_test_call(self, enable=True):
        data_dict = {
            'yabb330': {
                'remote_test_call': enable
            }
        }
        self.configure_with_json(data_dict)

    def remote_test_call(self, reqid='0', should_be_disabled=False):
        """A test command to make a car to move."""
        data_dict = {
            'reqId': 'remote-test-call-{}'.format(reqid),
            'action': 'testCall',
        }

        payload = self.send_receive_anylift_json(data_dict, timeout=65,
                                                 target='yabb330')
        rc = payload['rc']

        if should_be_disabled and rc != 403:
            raise NameError('Remote test call should be disabled but responded with {}'.format(rc))

        if rc == 200:
            logging.info('Remote test call successful')
        elif rc == 504:
            raise NameError('Remote test call timed out')

    def remove_stidi_node(self, node_nameplate, reqid='00'):
        """Remove given stidi from the Anylift database."""
        data_dict = {
            'reqId': 'remove-stidi-node-{}'.format(reqid),
            'action': 'remove',
            'nodeId': node_nameplate,
        }

        payload = self.send_receive_anylift_json(data_dict, timeout=30)

        rc = payload['rc']
        if rc == 200:
            logging.info('Removing {} stidi succeeded'.format(node_nameplate))
        else:
            raise NameError('Removing stidi {} failed with: {}'.format(node_nameplate, rc))

    def join_original(self, node_str=""):
        topic_cmd = "{}/cmd/mesh/fmt/json".format(self.topic_base)
        topic_evt = "{}/evt/mesh/fmt/json".format(self.topic_base)

        #request phase
        rc_already_joined=409
        rc_accepted=102

        #after wait (up to 2 minutes)
        rc_tout=404
        rc_success=200


        data_dict = {
                    "reqId":"0056", 
                    "action":"join", 
                    "nodeId": int(node_str), 
                    "keyIdx": int(1)
                    }

        data_json = json.dumps(data_dict)

        event_received = None

        def _on_message(client, userdata, message):
            nonlocal event_received
            payload = json.loads(message.payload)
            logging.debug(payload)
            try:
                event_received = int(payload['rc'])
            except:
                logging.debug("wrong message")
                pass

        self.mqtt.on_message =_on_message

        logging.debug("Subcribe on topic: {}".format(topic_evt))

        self.mqtt.subscribe(topic_evt, qos=0)

        logging.debug("Publishing on topic: {}, data: {}".format(topic_cmd, data_json))

        self.mqtt.loop_start()

        mex = self.mqtt.publish(topic_cmd, payload=data_json, qos=2, retain=False)

        mex.wait_for_publish()

        logging.debug("published")

        timeout = 5

        while event_received is None and timeout > 0:
            logging.debug("Timeout in {}".format(timeout))
            sleep(1)
            timeout -= 1

        if event_received is None:
            raise NameError("Didn't receive events on topic.")

        self.mqtt.loop_stop()


        if event_received == rc_accepted:
            logging.debug("request accepted")

            event_received = None

            def _on_message(client, userdata, message):
                nonlocal event_received
                payload = json.loads(message.payload)
                logging.debug(payload)
                try:
                    event_received = int(payload['rc'])
                except:
                    logging.debug("wrong message")
                    pass

            self.mqtt.on_message =_on_message

            self.mqtt.loop_start()

            logging.debug("Subcribe on topic: {}".format(topic_evt))

            self.mqtt.subscribe(topic_evt, qos=0)

            timeout = 300 #a bit more than 2 minutes

            while event_received is None and timeout > 0:
                logging.debug("Timeout in {}".format(timeout))
                sleep(1)
                timeout -= 1

            if event_received is None:
                raise NameError("Didn't receive events on topic.")

            self.mqtt.loop_stop()

            if event_received == rc_success:
                logging.debug("SUCCESS")

            if event_received == rc_tout:
                raise NameError("Request has timed out (120 sec)")


        else:
            logging.debug("Request not accepted")

            if event_received == rc_already_joined:
                logging.debug("already joined!")
            else:
                raise NameError("Request not accepted")

        logging.info("Done")

        
import unittest
import time
    
class TestALMid(unittest.TestCase):

    def setUp(self):

        log_level = logging.INFO
        #log_level = logging.DEBUG

        logging.basicConfig(format='Date-Time : %(asctime)s : %(filename)s - %(funcName)s - %(lineno)d - %(message)s',
                            level=log_level)

        self.almid = AnyliftMiddleware()

        if False:

            #Connect to broker running on the device (dev-test)
            self.almid.connect(host="192.168.100.18",
                port=1883,
                username="",
                password="",
                gateway_id = None,
                network_address=895
                )
        else:
            #Connect to IoT platform
            self.almid.connect(host="lx1oxl.messaging.internetofthings.ibmcloud.com",
                port=8883,
                username="a-lx1oxl-bpmtxgcoko",
                password="FdR&QRbQvzlaJ+ku4@",
                gateway_id = "357042064191126",
                network_address=895
                )

        #todo once only
        #self.almid.restart_stidi_application()



    @unittest.skip("skipping")
    def test_a_internal(self):

        res = self.almid._hex_to_base64('100F0E0D0C0B0A090807060504030201')
        self.assertEqual(res, "EA8ODQwLCgkIBwYFBAMCAQ==")

        res = self.almid._base64_to_hex("AAA=")
        self.assertEqual(res, "0000")

        res = self.almid._base64_to_hex("gAA=")
        self.assertEqual(res, "8000")

        #self.almid.cleanup()

        #self.almid.upload_scratchpad("yabb330_app.otap")

    #@unittest.skip("skipping")
    def test_b_base(self):
        info = self.almid.info()
        logging.info(info['sw_version'])


        cfg = self.almid.get_config()
        logging.info(cfg)

        
        time.sleep(5)

        self.almid.configure()

        time.sleep(2)

        #ping the sink, make sure it's running
        self.almid.wait_available(1)

        time.sleep(5)
        

        #basically a ping to the sink
        self.almid.ping(1)


        '''
        self.almid.send()
        ev_list = self.almid.receive()
        logging.info(ev_list[0])
        '''
         
        
    @unittest.skip("skipping")
    def test_c_join(self):

        nodes = self.almid.list_nodes(amount=1)

        if len(nodes) > 0:
            self.skipTest("Already provisioned devices")

        self.almid.enable_join_beacon()
        self.almid.join("40306562")
        self.almid.disable_join_beacon()

        nodes = self.almid.list_nodes(amount=1)

        self.assertTrue(len(nodes) > 0)

    @unittest.skip("skipping")
    def test_d_secondary(self):

        nodes = self.almid.list_nodes(amount=2)

        self.assertTrue(len(nodes) > 0)

        for addr in nodes:
            self.almid.ping(addr)

        for addr in nodes:
            self.almid.get_version_area(addr)

        node_yabb330 = "40306562"

        try:
            self.almid.change_application(node_yabb330)
        except:
            pass

        self.almid.start_otap_nodes("yabb330_app.otap", node_yabb330,
             "V0.1.6.0", "yabb330_app")



if __name__ == '__main__':
    unittest.main()
