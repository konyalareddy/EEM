'''
Similar to WirepasMiddleware.py class,
but oriented to send commands and read events from Anylift devices
'''
from robot.api.deco import keyword, library
from robot.libraries.BuiltIn import BuiltIn
from robot.api import logger 

from time import sleep
import logging


@library(scope='GLOBAL', auto_keywords=True)
class Mesh(object):

    #FFFFFFFF broadcast
    BCAST = int(4294967295)
    APP_LIST = {
                'stidi_app': "ff6b84",
                'yabb330_app': "fe6b84",
                'hydro_app': "fd6b84"
                }

    def ping(self, address=1, retry=1, gap_seconds=10, timeout=30):
        address=int(address)
        retry=int(retry)
        gap_seconds=int(gap_seconds)
        timeout=int(timeout)

        while retry > 0:
            try:
                logging.info("Ping the node: {}".format(address))
                #self.ping_single(address)
                self.send_expect(address, timeout=timeout)

                logging.info("OK")
                return
            except Exception as e:
                retry -= 1
                if retry <= 0:
                    raise e
                sleep(gap_seconds)

    def send_expect(self, dest_addr=1, 
                    payload='0000', expect='8000',
                    send_source_endpoint=255,  send_destination_endpoint=240,
                    receive_source_endpoint=240,  receive_destination_endpoint=255,
                    timeout=30):

        assert payload 
        payload = payload.lower()

        assert expect
        expect = expect.lower()


        logging.debug("Addr: {}, Send: {},  expect: {}".format(dest_addr, payload, expect))

        response_payload = self.send_receive(dest_addr, payload,
                 send_source_endpoint, send_destination_endpoint, 
                 receive_source_endpoint,receive_destination_endpoint, 
                 timeout)

        logging.debug("received: {}".format(response_payload))
        response_payload = response_payload[0]

        if response_payload.find(expect) >= 0:
            logging.debug("Received expected response")
        else:
            raise NameError("Payload not matching expectation ")


    def getPayloadValues(self, payload, start, end):
        #logging.debug("From payload {} extract octects from {} to {}".format(payload, start, end))
        ret =  [payload[i:i+2] for i in range(0, len(payload), 2)][start:end]
        #logging.debug("Extracted {} ".format(ret))
        return ret

    def nodes_str_to_list(self, nodes_str):
        #assert type(nodes_str) is str
        nodes_str = str(nodes_str)

        l = list()
        try:
            nodes = nodes_str.split(',')
            logger.debug(nodes)
            l=list(map(int, nodes))
        except:
            return l.append(nodes_str)

        return l

    def process_scratchpad(self, node, sequence):

        seq_hex = "{:02x}".format(sequence)
        logging.debug("Request process of sequence {} - hex: {}".format(sequence, seq_hex))
        payload = "040001001a01{}030005020a00".format(seq_hex)
        expected = "840081009a01{}83008502".format(seq_hex)
        self.send_expect(node, payload, expected)

    def validateNodes(self, nodes, tries=3, check_running=False, gap=10):
        logging.info("Validate nodes {}, current sequence {}".format(nodes, self.sequence_number))
        if check_running:
            logging.info("Validate if sequence is RUNNING on nodes")

        valid = False
        while tries > 0 and not valid:
            logging.info("Tries left: {}".format(tries))
            for node in nodes:
                try:
                    stored, running = self.get_sequence(node)

                    if stored is not self.sequence_number:
                        logging.debug("Node {} stored seq {} not matching".format(node, stored))
                        break
                    else:
                        logging.info("Node {} stored seq {} is matching".format(node, stored))

                    if check_running:
                        if running is not self.sequence_number:
                            logging.debug("Node {} RUNNING seq {} not matching".format(node, running))
                            break
                        else:
                            logging.info("Node {} RUNNING seq {} is matching".format(node, stored))

                    valid = True
                except:
                    logging.debug("Validating node: {} failed.".format(node))
                    break

            tries -= 1
            if tries > 0 and not valid:
                logging.info("Try again after {}s sleep.".format(gap))
                sleep(gap)

        if not valid:
            logging.debug("Validating failed.")
            raise NameError("Validation failed.")

        logging.info("Validation success")


    def updateNodes(self, nodes):
        logging.info("Start processing scratchpad on nodes")

        for node in nodes:
            try:
                logging.info("Node {} - seq: {}".format(node, self.sequence_number))
                self.process_scratchpad(node, self.sequence_number)
            except:
                raise NameError("Failed to process scrachtpad {}, hex: {}.".format(
                    node, self.sequence_number))

        logging.info("Success to process scratchpad")

        try:
            self.validateNodes(nodes, tries=6, check_running=True)
        except:
            logging.debug("Failed to bootup with newer sequence")
            raise NameError("Failed to bootup with newer sequence")

        logging.info("All nodes are running with new sequence")

    def parse_sequences(self, response_payload):
        #Sequence number of the scratchpad present in the
        #node, or 0 if there is no scratchpad present in the node
        seq_in_hex = self.getPayloadValues(
            response_payload, 8, 9)[0]
        stored_seq = int(seq_in_hex, 16)

        #running on node: Sequence number of the application that produced the 
        #firmware currently running on the node
        seq_in_hex = self.getPayloadValues(
            response_payload, 32, 33)[0]
        running_seq = int(seq_in_hex, 16)

        return stored_seq, running_seq


    def get_sequence(self, address=1):

        address = int(address)

        response_payload = self.get_scratchpad(address)

        stored_seq, running_seq = self.parse_sequences(response_payload)

        logging.info('Node {}, stored_seq {}, running_seq {}'.format(address, 
            stored_seq, running_seq))

        return stored_seq, running_seq


    def parse_version_area(self, response_payload):

        app_area_id = self.getPayloadValues(
            response_payload, 33, 37)

        app_area_id = ''.join(app_area_id)

        major_hex = self.getPayloadValues(
            response_payload, 37, 38)[0]

        major = int(major_hex, 16)

        minor_hex = self.getPayloadValues(
            response_payload, 38, 39)[0]

        minor = int(minor_hex, 16)

        maint_hex = self.getPayloadValues(
            response_payload, 39, 40)[0]

        maint = int(maint_hex, 16)

        devel_hex = self.getPayloadValues(
            response_payload, 40, 41)[0]
        devel = int(devel_hex, 16)

        version = "V{:d}.{:d}.{:d}.{:d}".format(major, minor, maint, devel)

        #logging.debug(version)

        return version, app_area_id

        

    def get_version_area(self, address=1):

        address = int(address)

        response_payload = self.get_scratchpad(address)

        version, app_area_id = self.parse_version_area(response_payload)

        logging.info('Node {}, version {}, area id {}'.format(address, 
            version, app_area_id))

        return version, app_area_id


    def list_nodes_running_application(self, version):

        nodes = self.list_nodes(amount=1)

        nodes_matching = []

        for addr in nodes:
            _v, _id = self.get_version_area(addr)
            if _v.find(version) >= 0:
                logging.info("Match found, node {} runs version {}".format(addr, version))
                nodes_matching.append(addr)

        if len(nodes_matching) == 0:
            raise NameError("There is no node runnign the application")

        return nodes_matching

    def get_scratchpad(self, address=1):

        logging.debug("Request scratchpad for address {}".format(address))
        #request scratchpad status
        response_payload = self.send_receive(address, payload='1900', timeout=30)

        #todo check that it starts with 9927?

        logging.debug("Raw scratchpad: {}".format(response_payload))

        return response_payload[0]

    def check_propagation(self, nodes):
        logging.info("Check propagation of sequence.")

        try:
            self.validateNodes(nodes, tries=10, gap=30)
        except:
            raise NameError("Scratchpad propagation failed.")

        logging.info("Scratchpad propagation was successfull.")

    #This fx is actually testing again the version number, not only otap sequences
    def start_otap_nodes(self, otap_file, nodes_str
        , version, application):
        assert type(otap_file) is str

        logging.info("Perform OTAP with file {} on nodes {}".format(otap_file, nodes_str))

        nodes = self.nodes_str_to_list(nodes_str)

        self.upload_scratchpad(otap_file)

        self.otap_nodes(nodes)
        logging.info("OTAP with file {} SUCCESS on nodes {}".format(otap_file, nodes_str))

        self.verify_application(nodes_str, version, application)

    def otap_nodes(self, nodes):

        self.check_propagation(nodes)

        self.updateNodes(nodes)

    def otap_sink(self):

        self.validateNodes([self.sink_address], tries=10, check_running=True)

        logging.info("OTAP SUCCESS on the sink")


    def verify_application(self, nodes_str,
                version, application, retry = 10):

        logging.info("Verify running of application {} - {}".format(application, version))

        app_area_id = self.get_app_area_for_application(application)

        nodes = self.nodes_str_to_list(nodes_str)

        while retry > 0:
            logging.info("Retry left: {}".format(retry))
            for n in nodes:
                v, a = self.get_version_area(nodes_str)
                retry = retry - 1
                if a.find(app_area_id) >= 0 and version.find(v) >= 0:
                    logging.info("Application {} up to date on node {}".format(application, nodes_str))
                    return
        
        if retry == 0:
            raise NameError("Could not find application on the node")

    def enable_join_beacon(self, nodes_str="1"):
        nodes = self.nodes_str_to_list(nodes_str)

        logging.info("Enable join beacons for nodes: {}".format(nodes))
        for n in nodes:
            try:
                # Enable beacon
                logging.info("Enable join beacons node: {}".format(n))
                self.send_expect(n,
                          payload='610E20A10700B8D389000408FB507664',
                          expect='E10E20A10700B8D389000408FB507664')
                logging.info("Joining beacon enabled on the node")

            except:
                raise NameError("Error with joining beacon (enable)")

    def disable_join_beacon(self, nodes_str="1"):
        nodes = self.nodes_str_to_list(nodes_str)

        logging.info("Disable join beacons for nodes: {}".format(nodes))
        for n in nodes:
            try:
                # Enable beacon
                logging.info("Disable join beacons node: {}".format(n))
                self.send_expect(n,
                          payload='6200',
                          expect='E200')
                logging.info("Joining beacon disabled on the node")

            except:
                raise NameError("Error with joining beacon (disable)")

    def _get_app_area_from_response(self, payload):
        return payload[68:74]#3 bytes only
        

    def current_application(self, address):
        response_payload = self.get_scratchpad(address)

        app_read = self._get_app_area_from_response(response_payload)

        logging.debug("Current application id: {}".format(app_read))

        for k, a in self.APP_LIST.items():
            if a == app_read:
                return k

        raise NameError("Application not matching with any known")


    def get_app_area_for_application(self, application):
        try:
            return self.APP_LIST[application]
        except:
            raise NameError("Application not known")

    def change_application(self, node_str, application="yabb330_app", verify=True):

        node = int(node_str)

        current = self.current_application(node)

        logging.debug("Current application: {}".format(current))

        if current == application:
            logging.debug("Application already assigned to {} on node {}".format(application, node))
            return

        app_area_id = self.get_app_area_for_application(application)

        logging.info("Change to application: {} - id:{}".format(application, app_area_id))

        # role assignment, there is a bun now, node does not reply, you can poll
        try:
            self.send(node,
                payload=app_area_id,
                source_endpoint=100,
                destination_endpoint=100,
                timeout=15
                )
        except:
            raise NameError("Cannot assign role to new node")

        logging.info("change sent")

        if verify:
            sleep(10)
            self.wait_available(node)

            current = self.current_application(node)

            logging.debug("Current application: {}".format(current))

            if application != current:
                raise NameError("Application did not change")

            logger.info("Application change verified")


    def wait_available(self, node):

        logging.info("Wait for node: {} to be available".format(node))

        self.ping(node, retry=3, gap_seconds=10)

    def info(self):
        raise NameError("Implemented in Anylift device only")

    def _send_update_request(self, node):
        # Send the update request to restart the node in 10 seconds
        payload = self.send_receive(node, payload='05020A00', timeout=30)
        logging.info(payload)
        payload = payload[0]

        # The restart has 10 + 20 seconds of maximum delay
        restartdelay = 10 + 20
        if payload.startswith('8502'):
            restartdelay = int(payload[4:6], 16) + 1

        logging.info('Waiting {} seconds for the node {} to restart'.format(
            restartdelay, node
        ))
        sleep(restartdelay)

    def enable_low_latency_mode(self, nodes_str="1", toggle=False):
        nodes = self.nodes_str_to_list(nodes_str)

        modes = {
            'low_latency': '92',
            'normal': '82',
        }

        logging.info("Enable low-latency for nodes: {}".format(nodes))
        for n in nodes:
            try:
                logging.info("Enable low-latency node: {}".format(n))

                mode = modes['low_latency']

                # Check if the node is already in the low-latency mode
                noderole = self.send_receive(n, payload='0E020400', timeout=30)
                logging.info(noderole)
                noderole = noderole[0]
                if not toggle:
                    if noderole.endswith(modes['low_latency']):
                        logging.info('Node already in low-latency mode')
                        continue
                else:
                    if noderole.endswith(modes['low_latency']):
                        mode = modes['normal']

                # Send data to enable low-latency:
                # 0100 (begin)
                # 0D03040092 (noderole -> 92 low_latency / 82 normal mode)
                # 0300 (end)
                self.send_expect(n,
                                 payload='01000D030400{}0300'.format(mode),
                                 expect='81008D030400{}8300'.format(mode))

                # Update and boot the node
                self._send_update_request(n)

            except:
                raise NameError("Error with setting low-latency")

    def _clear_stidi_keys(self, node):
        """Zero the cCipherKey and cAuthenticationKey CSAP attributes."""
        self.send_expect(
            node,
            payload='01000D120D00FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF0D120E00FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF0300',
            expect='81008D020D008D020E008300'
        )

    def read_stidi_attributes(self, nodes_str="1"):
        nodes = self.nodes_str_to_list(nodes_str)

        print(nodes_str)
        print(nodes)

        for n in nodes:
            ret = self.send_receive(
                n,
                payload='01000E0201000E0202000E0203000E0204000E0214000E0215000E0216000300',
            )
            print('Received: {}'.format(ret))

    def _set_stidi_cnetworkchannel(self, node, value='05'):
        """Set the cNetworkChannel attribute to given value"""
        self.send_expect(
            node,
            payload='01000D030300'+value+'0300',
            expect= '81008D030300'+value+'8300'
        )

    def reset_stidi_joining(self, nodes_str="1"):
        nodes = self.nodes_str_to_list(nodes_str)

        for n in nodes:
            try:
                # Send data to reset stidi joining:
                # 0400 (cancel to reset to known state)
                # 0100 (begin)
                # 0D050200DEBC0A (Set cNetworkAddress to 0x0ABCDE)
                # 0300 (end)
                self.send_expect(n,
                                 payload='040001000D050200DEBC0A0300',
                                 expect='840081008D050200DEBC0A8300')

                # The channel needs to be set to 0x05 for the joining to be
                # successful. The 0x05 is the default channel the stidi is
                # programmed with.
                self._set_stidi_cnetworkchannel(n, '05')

                # Update and boot the node
                self._send_update_request(n)
            except Exception as e:
                raise NameError("Error with resetting stidi joining for node {}: {}".format(
                    n, e
                ))

    def reboot_nodes(self, nodes_str="1"):
        '''Forcibly reboot the node by toggling the low_latency configuration.'''
        self.enable_low_latency_mode(nodes_str, toggle=True)

    def set_led_color(self, nodes_str="1", color="red"):
        colors = {
            'off': '00',
            'red': '01',
            'green': '02',
            'blue': '04',
            'yellow': '03',
            'magenta': '05',
            'cyan': '06',
            'white': '07',
        }
        color = color.lower()
        code = colors[color]

        nodes = self.nodes_str_to_list(nodes_str)

        for n in nodes:
            logging.info("Set led of {} to {}".format(n, color))

            self.send(address=n,
                      source_endpoint=3, destination_endpoint=3,
                      payload=code, timeout=10)


import unittest
    
class TestMesh(unittest.TestCase):

    def test_base(self):

        log_level = logging.INFO
        log_level = logging.DEBUG

        logging.basicConfig(format='Date-Time : %(asctime)s : %(filename)s - %(funcName)s - %(lineno)d - %(message)s',
                            level=log_level)

        mesh = Mesh()

        sink_address = 1
        new_node_address = "1746560966,1867991337"

        test_nodes = mesh.nodes_str_to_list(new_node_address)

        self.assertEqual(test_nodes[0], 1746560966)
        self.assertEqual(test_nodes[1], 1867991337)

        test_nodes = mesh.nodes_str_to_list("568205")

        self.assertEqual(test_nodes[0], 568205)

        test_nodes = mesh.nodes_str_to_list(1)

        self.assertEqual(test_nodes[0], 1)

        #payload from a sink running dualmcu_app
        payload = "992720100000dd1c6c01ff609c0100358b6a060100000500002e609c0100358b6a06746b8405000024"

        stored_seq, running_seq = mesh.parse_sequences(payload)

        self.assertEqual(stored_seq,int(108))
        self.assertEqual(running_seq,int(106))

        version, app_area_id = mesh.parse_version_area(payload)

        self.assertEqual(version,'V5.0.0.36')
        self.assertEqual(app_area_id, '06746b84')

        payload2="9927200a00000cda030200d08401003f7d02060100000500002ef0dc010091450106fe6b8400060899"

        app_area_id = mesh._get_app_area_from_response(payload2)
        self.assertEqual(app_area_id, 'fe6b84')


    def test_verify_application(self):
        mesh = Mesh()
        payload = "992720100000dd1c6c01ff609c0100358b6a060100000500002e609c0100358b6a06746b8405000024"

        mesh.APP_LIST['dualmcu_app'] = '746b84'
        mesh.get_scratchpad = lambda x: payload

        print(mesh.APP_LIST)
        # Verify that the following function does not assert. I.e. finds the
        # below application and version.
        mesh.verify_application('123', 'V5.0.0.36', 'dualmcu_app', 1)



if __name__ == '__main__':
    unittest.main()
