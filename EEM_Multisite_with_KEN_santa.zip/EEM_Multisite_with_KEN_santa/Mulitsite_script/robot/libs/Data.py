import io
import re
import itertools

class Data:
    '''Class for data handling.'''

    def __init__(self):
        pass

    def from_file(self, fname, uptobytes):
        """Reads bytes from given filename or file-like object up to given number of
        bytes. If there is not enough bytes in the file, multiplies the given
        data so enough bytes is returned.
        """
        uptobytes = int(uptobytes)
        fdata = None
        if hasattr(fname, 'read'):
            fdata = fname.read()
        else:
            with open(fname, 'rb') as fp:
                fdata = fp.read()

        if len(fdata) >= uptobytes:
            return fdata[:uptobytes]

        # If read data is smaller than wanted, multiply the data
        mul = int((uptobytes / len(fdata))) + 1
        fdata = mul * fdata
        return fdata[:uptobytes]

    def to_hex(self, array):
        """Converts a byte-string to a hex string that can be injected to a serial
        port."""
        return " ".join([hex(c)[2:] for c in array]).upper()

    def to_string(self, intarray):
        """Converts an array of ints or bytes into a string."""
        return bytes(intarray).decode('utf-8', errors='ignore')

    def from_hexstring_to_string(self, hexstring):
        return bytes.fromhex(hexstring).decode()

    def get_corrupted_file(self, fname, length=None, replacements=None):
        """Returns a file-like object from the given file and does manipulations to
        it.
        Currently supported:

        length=integer
        Cuts the file down to given length

        replacements=[[offset-integer, string-data], ...]
        Replaces certain offsets with given strings. The offsets should be
        increasing integers of absolute offsets in the file.
        """

        if not hasattr(fname, 'read'):
            fw = open(fname, 'rb')
        else:
            fw = fname
        data = fw.read()

        if replacements is not None:
            i = 0
            chunks = []
            for offset, replace in replacements:
                replace = replace.encode()
                if len(data) < offset + len(replace):
                    raise ValueError(
                        'Replacement in offset {} of length {} is out of bounds'.format(
                            offset, len(replace)
                        )
                    )
                chunks.append(data[i:offset])
                chunks.append(replace)
                i = i + offset + len(replace)

            chunks.append(data[i:len(data)-1])
            data = b''.join(chunks)

        if length is not None:
            if len(data) < length:
                raise ValueError(
                    'Given length {} too long for the file length {}'.format(
                        length, len(data)
                    )
                )
            data = data[0:length]

        return io.BytesIO(data)

    def parse_version_file(self, fname):
        data = ''
        if hasattr(fname, 'read'):
            data = fname.read()
        else:
            with open(fname) as fp:
                data = fp.read()

        lines = data.splitlines()
        splitter = re.compile(r'^([^=]+)=(.*)$')
        ret = {}
        for line in lines:
            fields = splitter.match(line)
            ret[fields[1]] = fields[2]

        return 'V{}.{}.{}.{}'.format(
            ret['app_major'],
            ret['app_minor'],
            ret['app_maintenance'],
            ret['app_development']
        )

    def parse_yabb_version_file(self, fname):
        """Parses The YABB330 firmware's version file to a space separated big endian
hex string.
        """
        data = ''
        if hasattr(fname, 'read'):
            data = fname.read()
        else:
            with open(fname) as fp:
                data = fp.read()

        lines = data.splitlines()
        splitter = re.compile(r'^.*SW_VERSION_([^ ]+) +\(([0-9]+)u?\).*$')
        ret = {}
        for line in lines:
            fields = splitter.match(line)
            if fields:
                ret[fields[1]] = fields[2]

        def pad(field):
            val = int(ret[field])
            return '{:02X}'.format(val)

        return '{} {} {} {}'.format(
            pad('PATCH'),
            pad('MINOR'),
            pad('MAJOR'),
            pad('HW_ID'),
        )

    def should_have_string_prefix(self, string, prefix):
        if string.find(prefix) != 0:
            raise ValueError("prefix '{}' is not found in string '{}'".format(prefix, string))

    def combine_dict_arrays(self, d1, d2):
        """Returns d1 dict of arrays that has the array items of d2 appended to it."""
        for k in d2:
            prev = []
            if k in d1:
                prev = d1[k]
            prev.extend(d2[k])
            d1[k] = prev
        return d1

    def split_string_to_list(self, string, chunksize=2):
        return [string[i:i+chunksize] for i in range(0, len(string), chunksize)]

    def string_to_boolean(self, strvalue):
        return strvalue.lower() in ('true', 't', '1')

    def shuffle_list(self, listvar):
        import random
        ret = listvar.copy()
        random.shuffle(ret)
        return ret

    def generate_increasing_list(self, template, count):
        '''Creates a list of strings in a list according to a template'''
        count = int(count)
        templen = template.count('_')
        template = template.replace('_', '')
        return [template + str(i).zfill(templen) for i in range(count)]

    def field_permutate(self, templatestring, field_separator=':',
                        fromto_separator='-'):
        """Generates an array of strings from a template with fields that can have a
        range of values. E.g.:

        "1:1" -> ["1:1"]
        "1-3:1" -> ["1:1", "2:1", "3:1"]
        """
        fields = templatestring.split(field_separator)
        fieldvalues = []

        for f in fields:
            if fromto_separator not in f:
                fieldvalues.append([f])
            else:
                start, end = f.split(fromto_separator)
                start = int(start)
                end = int(end)
                fieldvalues.append(
                    [str(v) for v in range(start, end+1)]
                )

        return [field_separator.join(perm) for perm in
                itertools.product(*fieldvalues)]


import unittest


class TestData(unittest.TestCase):
    def setUp(self):
        self.data = Data()

    def test_from_file(self):

        data = [
            {'in': b'', 'count': 0, 'out': b''},
            {'in': b'abc', 'count': 1, 'out': b'a'},
            {'in': b'abc', 'count': 3, 'out': b'abc'},
            {'in': b'abc', 'count': 4, 'out': b'abca'},
            {'in': b'abc', 'count': 6, 'out': b'abcabc'},
            {'in': b'abc', 'count': 10, 'out': b'abcabcabca'},
        ]

        for d in data:
            with self.subTest(d):
                f = io.BytesIO(d['in'])
                out = self.data.from_file(f, d['count'])
                self.assertEqual(d['out'], out)

    def test_get_corrupted_file(self):
        data = [
            {'in': b'', 'out': b'', 'args': {}, 'fails': False},
            {'in': b'', 'out': b'', 'args': {'length': 0}, 'fails': False},
            {'in': b'', 'out': b'', 'args': {'length': 1}, 'fails': True},
            {'in': b'abc', 'out': b'a', 'args': {'length': 1}, 'fails': False},
            {'in': b'abc', 'out': b'ab', 'args': {'length': 2}, 'fails': False},
            {'in': b'abc', 'out': b'aXX',
             'args': {'replacements': [(1, 'XX')]}, 'fails': False},
            {'in': b'abc', 'out': b'',
             'args': {'replacements': [(1, 'XXX')]}, 'fails': True},
            {'in': b'abcdef', 'out': b'aXcYYY',
             'args': {'replacements': [(1, 'X'), (3, 'YYY')]}, 'fails': False},
            {'in': b'abcdef', 'out': b'aXcYY',
             'args': {'replacements': [(1, 'X'), (3, 'YYY')], 'length': 5}, 'fails': False},
        ]

        for d in data:
            with self.subTest(d):
                filedata = io.BytesIO(d['in'])
                if d['fails']:
                    with self.assertRaises(ValueError):
                        out = self.data.get_corrupted_file(filedata, **d['args'])
                else:
                    out = self.data.get_corrupted_file(filedata, **d['args'])
                    self.assertEqual(out.read(), d['out'])

    def test_parse_version_file(self):
        def vd(a, b, c, d):
            return 'app_major={}\napp_minor={}\napp_maintenance={}\napp_development={}' .format(a, b, c, d)
        data = [
            {'in': '', 'out': '', 'raises': KeyError},
            {'in': vd(1, 2, 3, 4), 'out': 'V1.2.3.4', 'raises': None},
            {'in': vd(1, 2, '', 4), 'out': 'V1.2..4', 'raises': None},
            {'in': vd(1, 2, 3, 'abc'), 'out': 'V1.2.3.abc', 'raises': None},
            {'in': vd(1, 2, 3, 'abc')[:10], 'out': '', 'raises': KeyError},
        ]
        for d in data:
            with self.subTest(d):
                filedata = io.StringIO(d['in'])
                if d['raises'] is not None:
                    with self.assertRaises(d['raises']):
                        out = self.data.parse_version_file(filedata)
                else:
                    out = self.data.parse_version_file(filedata)
                    self.assertEqual(out, d['out'])

    def test_parse_yabb_version_file(self):
        def ver(hw, major, minor, patch):
            return '''
#define SW_VERSION_HW_ID   ({}u) //! Follwoing the build, B1, B2, etc...
#define SW_VERSION_MAJOR   ({}u)
#define SW_VERSION_MINOR   ({}u)
#define SW_VERSION_PATCH   ({})
#define SW_VERSION_HW_ID_MASK   (SW_VERSION_HW_ID << 24u)
#define SW_VERSION_MAJOR_MASK   (SW_VERSION_MAJOR << 16u)
#define SW_VERSION_MINOR_MASK   (SW_VERSION_MINOR << 8u)
#define SW_VERSION_PATCH_MASK   (SW_VERSION_PATCH << 0u)
#define FIRMWARE_VERSION  (SW_VERSION_HW_ID_MASK | SW_VERSION_MAJOR_MASK | SW_VERSION_MINOR_MASK | SW_VERSION_PATCH_MASK)
 '''.format(hw, major, minor, patch)

        data = [
            {'in': '', 'out': '', 'raises': KeyError},
            {'in': ver(1, 2, 3, 4), 'out': '04 03 02 01', 'raises': None},
            {'in': ver(2, 0, 1, 121), 'out': '79 01 00 02', 'raises': None},
            {'in': 'xyz\n' + ver(2, 0, 1, 121), 'out': '79 01 00 02', 'raises': None},
            {'in': ver(2, 0, 1, 121) + 'abc', 'out': '79 01 00 02', 'raises': None},
            {'in': ver(2, 0, 1, 138) + 'abc', 'out': '8A 01 00 02', 'raises': None},
        ]
        for d in data:
            with self.subTest(d):
                filedata = io.StringIO(d['in'])
                if d['raises'] is not None:
                    with self.assertRaises(d['raises']):
                        out = self.data.parse_yabb_version_file(filedata)
                else:
                    out = self.data.parse_yabb_version_file(filedata)
                    self.assertEqual(out, d['out'])


    def test_should_have_string_prefix(self):
        data = [
            {'str': '', 'pfx': '', 'raises': None},
            {'str': 'a', 'pfx': '', 'raises': None},
            {'str': 'a', 'pfx': 'b', 'raises': ValueError},
            {'str': 'a', 'pfx': 'a', 'raises': None},
            {'str': ' a', 'pfx': 'a', 'raises': ValueError},
            {'str': 'abc123', 'pfx': 'abc', 'raises': None},
            {'str': 'abc123', 'pfx': '123', 'raises': ValueError},
        ]
        for d in data:
            with self.subTest(d):
                if d['raises'] is not None:
                    with self.assertRaises(d['raises']):
                        self.data.should_have_string_prefix(d['str'], d['pfx'])
                else:
                    self.data.should_have_string_prefix(d['str'], d['pfx'])

    def test_combine_dict_arrays(self):
        data = [
            {'d1': {}, 'd2': {}, 'out': {}},
            {'d1': {'a': [1, 2]}, 'd2': {'a': [3]}, 'out': {'a': [1, 2, 3]}},
            {'d1': {'a': [1, 2]}, 'd2': {'b': [3]}, 'out': {'a': [1, 2], 'b': [3]}},
            {'d1': {'a': [1, 2]}, 'd2': {}, 'out': {'a': [1, 2]}},
            {'d1': {}, 'd2': {'a': [1, 2]}, 'out': {'a': [1, 2]}},
            {'d1': {}, 'd2': {'a': [1], 'b': []}, 'out': {'a': [1], 'b': []}},
        ]
        for d in data:
            with self.subTest(d):
                out = self.data.combine_dict_arrays(d['d1'], d['d2'])
                self.assertEqual(out, d['out'])

    def test_field_permutate(self):
        data = [
            {'in': '', 'out': ['']},
            {'in': '1:1', 'out': ['1:1']},
            {'in': '1-2:1', 'out': ['1:1', '2:1']},
            {'in': 'abc:1-2:1', 'out': ['abc:1:1', 'abc:2:1']},
            {'in': '6-8:1:1-2', 'out': ['6:1:1', '6:1:2', '7:1:1', '7:1:2',
                                        '8:1:1', '8:1:2']},
        ]
        for d in data:
            with self.subTest(d):
                out = self.data.field_permutate(d['in'])
                self.assertEqual(out, d['out'])

if __name__ == '__main__':
    unittest.main()
