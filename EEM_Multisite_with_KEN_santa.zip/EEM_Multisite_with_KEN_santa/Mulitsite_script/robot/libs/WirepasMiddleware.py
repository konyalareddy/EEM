# Copyright 2020 Wirepas Ltd. All Rights Reserved.
#
# See file LICENSE.txt for full license details.
#
from robot.api.deco import keyword, library
from robot.libraries.BuiltIn import BuiltIn
from robot.api import logger 

import time
import argparse
import uuid
import ssl
from time import sleep

import base64
import logging
import os

from pathlib import Path 


#from cmd import Cmd

from Mesh import *
from WirepasProvServer import WirepasProvServer


try:
    import paho.mqtt.client as mqtt
except ModuleNotFoundError:
    print("Please install Paho mqtt wheel: pip install paho-mqtt")
    exit(-1)

try:
    import wirepas_messaging
    import wirepas_messaging.gateway.api as wp_api
except ModuleNotFoundError:
    print("Please install Wirepas messaging wheel: pip install wirepas-messaging")
    exit(-1)

@library(scope='GLOBAL', auto_keywords=True)
class WirepasMiddleware(Mesh):

    def connect(self, host, port, username, password,
                gateway_id, network_address, sink_id="sink0",
                sink_address=1, encrypt=True):

        #Cmd.__init__(self)#is this really needed?

        # Create an MQTT client
        self.mqtt = mqtt.Client()
        '''
        self.mqtt.tls_set(ca_certs=None, certfile=None, keyfile=None,
                          cert_reqs=ssl.CERT_REQUIRED,
                          tls_version=ssl.PROTOCOL_TLSv1_2, ciphers=None)

        self.mqtt.tls_insecure_set(True)
        '''

        self.mqtt.username_pw_set(username,
                                  password)

        self.mqtt.on_connect = self._on_connect_callback
        self.mqtt.on_disconnect = self._on_disconnect_callback

        self.mqtt.connect(host, int(port))
        self.mqtt.loop_start()

        assert gateway_id is not None
        assert network_address is not None
        assert sink_id is not None

        self.gateway_id = int(gateway_id)
        self.network_address = int(network_address)
        self.encrypt = bool(encrypt)
        self.sink_id = str(sink_id)
        self.sink_address = int(sink_address)



        self.busy = False
        self.connected = False

        # Wait for 5 seconds the answer
        timeout = 5
        while not self.connected and timeout > 0:
            logging.debug("Connection timeout in {}".format(timeout))
            sleep(1)
            timeout -= 1

        if not timeout:
            raise NameError("Cannot connect to MQTT")

        #make sure stack runs on the sink
        #self.sink_stack_set(True)

    def _on_connect_callback(self, client, userdata, flags, rc):
        logging.info("..Connected to MQTT")
        self.connected = True

    def _on_disconnect_callback(self, client, userdata, rc):
        logging.info("..MQTT disconnected rc={}".format(rc))
        self.connected = False



    '''
    List the nodes responding withing the timeout
    or when reached the amount of nodes
    '''
    def list_nodes(self, timeout = 30, amount=10):

        timeout= int(timeout)
        amount = int(amount)

        assert timeout > 5
        assert amount >= 1

        receive_source_endpoint = 240
        receive_destination_endpoint = 255

        

        topic_receive = "gw-event/received_data/{}/{}/{}/{}/{}".format(self.gateway_id,
                                                                       self.sink_id, self.network_address,
                                                                       receive_source_endpoint, receive_destination_endpoint)


        nodes = []

        def _on_response_received(client, userdata, mqtt_message):
            nonlocal nodes
            response = wirepas_messaging.gateway.api.ReceivedDataEvent.from_payload(
                mqtt_message.payload)
            response_payload = response.data_payload.hex()
            logging.debug("Address: {} - Received Event: {}".format(response.source_address,response_payload))
            if response_payload.find('8002') >= 0:
                nodes.append(response.source_address)
                logging.info("Address: {} responded to ping".format(response.source_address))


        logging.debug("Wait Event on topic %s" % topic_receive)
        self.mqtt.message_callback_add(topic_receive, _on_response_received)
        self.mqtt.subscribe(topic_receive, qos=0)

        logging.info("Broadcast ping, read what node responds, timeout {}".format(timeout))
        self.send(self.BCAST, payload='00020565')

        

        while timeout > 0 and len(nodes) < amount :
            logging.debug("Timeout in {}".format(timeout))
            sleep(1)
            timeout -= 1


        logging.info("Done listing, found nodes: {}".format(nodes))

        #might be empty list, return same value only once
        return list(set(nodes))
    


    def send(self, address=1, payload='0000',
                  source_endpoint=255, destination_endpoint=240,
                  timeout=5):
        #for Robot everything is a string
        address = int(address)
        source_endpoint = int(source_endpoint)
        destination_endpoint = int(destination_endpoint)

        assert payload
        # avoid confusion when matching strings in hex such as e1 vs E1
        payload = payload.lower()
        payload = bytes.fromhex(payload)
        logging.debug("Send Address: {} Payload: {} ".format(address, payload))

        topic_request = "gw-request/send_data/{}/{}".format(
            self.gateway_id, self.sink_id)
        topic_response = "gw-response/send_data/{}/{}".format(
            self.gateway_id, self.sink_id)

        
        # Generate request
        req = wirepas_messaging.gateway.api.SendDataRequest(
            dest_add=address, src_ep=source_endpoint, 
            dst_ep=destination_endpoint, qos=2, payload=payload, sink_id=self.sink_id)

        self.send_request_to_topic(topic_request, topic_response, req,
                                   wirepas_messaging.gateway.api.SendDataResponse.from_payload,
                                   timeout=timeout)


    def send_receive(self, dest_addr=1, payload='0000',
                  send_source_endpoint=255, send_destination_endpoint=240,
                  receive_source_endpoint=240, receive_destination_endpoint=255,
                  timeout=5):

        #for Robot everything is a string
        dest_addr = int(dest_addr)
        send_source_endpoint = int(send_source_endpoint)
        send_destination_endpoint = int(send_destination_endpoint)
        receive_source_endpoint = int(receive_source_endpoint)
        receive_destination_endpoint = int(receive_destination_endpoint)
        timeout = int(timeout)

        assert payload
        # avoid confusion when matching strings in hex such as e1 vs E1
        payload = payload.lower()
        payload = bytes.fromhex(payload)
        logging.debug("Address: {} Payload: {} ".format(dest_addr, payload))

        topic_request = "gw-request/send_data/{}/{}".format(
            self.gateway_id, self.sink_id)
        topic_response = "gw-response/send_data/{}/{}".format(
            self.gateway_id, self.sink_id)

        
        # Generate request
        req = wirepas_messaging.gateway.api.SendDataRequest(
            dest_add=dest_addr, src_ep=send_source_endpoint, 
            dst_ep=send_destination_endpoint, qos=0, payload=payload)


        topic_receive = "gw-event/received_data/{}/{}/{}/{}/{}".format(self.gateway_id,
                                                                       self.sink_id, self.network_address,
                                                                       receive_source_endpoint, receive_destination_endpoint)


        response_payload = None

        def _on_response_received2(client, userdata, mqtt_message):
            nonlocal response_payload
            response = wirepas_messaging.gateway.api.ReceivedDataEvent.from_payload(
                mqtt_message.payload)
            response_payload = response.data_payload.hex()
            logging.debug("Received Event: {}".format(response_payload))


        self.mqtt.message_callback_add(topic_receive, _on_response_received2)
        self.mqtt.subscribe(topic_receive, qos=1)

        self.send_request_to_topic(topic_request, topic_response, req,
                                   wirepas_messaging.gateway.api.SendDataResponse.from_payload,
                                   timeout=5)

        logging.debug("Wait Event on topic %s" % topic_receive)

        while response_payload is None and timeout > 0:
            logging.debug("Timeout in {}".format(timeout))
            sleep(1)
            timeout -= 1

        if timeout == 0:
            logging.debug("Timeout to received")
            raise NameError("Didn't receive data from received_data topic.")

        logging.debug("Done")

        return [response_payload]


    #if address=N, filter on that, otherwise then return dict
    def receive(self, address=1,
                  source_endpoint=240, destination_endpoint=255,
                  timeout=30, amount=1):

        #for Robot everything is a string
        try:
            address = int(address)
            filter_address = True
            responses_payload = []
        except:
            filter_address = False
            responses_payload = dict()

        source_endpoint = int(source_endpoint)
        destination_endpoint = int(destination_endpoint)
        timeout = int(timeout)
        amount = int(amount)


        logging.debug("Listen on Address: {} s_ep: {} d_ep: {}".format(address, 
            source_endpoint, destination_endpoint))


        topic_receive = "gw-event/received_data/{}/{}/{}/{}/{}".format(self.gateway_id,
                                                                       self.sink_id, self.network_address,
                                                                       source_endpoint, destination_endpoint)


        
        def _on_response_received3(client, userdata, mqtt_message):
            nonlocal responses_payload
            response = wirepas_messaging.gateway.api.ReceivedDataEvent.from_payload(
                mqtt_message.payload)

            if filter_address:
                if int(response.source_address) == address:
                    responses_payload.append(response.data_payload.hex())
                    logging.debug("Received Events: {}".format(responses_payload))
                else:
                    logging.debug("Filtered out: {}".format(response))
            else:
                #append to a list of elements, if first time, make a list with one element
                try:
                    responses_payload[response.source_address].append(response.data_payload.hex())
                except:
                    #trick to get all the string in single entry of the list
                    l = list()
                    l.append(response.data_payload.hex())
                    responses_payload[response.source_address]=l


        self.mqtt.message_callback_add(topic_receive, _on_response_received3)
        self.mqtt.subscribe(topic_receive, qos=1)


        logging.debug("Wait Event on topic %s" % topic_receive)

        while len(responses_payload) < amount and timeout > 0:
            logging.debug("Timeout in {}".format(timeout))
            sleep(1)
            timeout -= 1

        if timeout == 0 and len(responses_payload) == 0:
            logging.debug("Timeout to received")
            raise NameError("Didn't receive data from received_data topic.")

        logging.debug("Done")

        return responses_payload


    def send_request_to_topic(self, request_topic, response_topic, request, from_payload, timeout=5):
        success_received = False
        response_received = False

        def _on_response_received(client, userdata, mqtt_message):
            nonlocal success_received
            nonlocal response_received

            response = from_payload(
                mqtt_message.payload)

            if response.req_id == request.req_id:
                logging.debug(response.res)
                response_received = True
                
                if response.res is wp_api.GatewayResultCode.GW_RES_OK:
                    success_received = True

        self.mqtt.message_callback_add(response_topic, _on_response_received)
        self.mqtt.subscribe(response_topic, qos=1)

        try:
            self.mqtt.publish(request_topic, request.payload, 1)
            logging.debug("Publish to topic %s" % request_topic)
        except Exception as e:
            logging.error(str(e))
            raise NameError("Cannot send data.")

        logging.debug("Wait response on topic %s" % response_topic)

        while not response_received and timeout > 0:
            logging.debug("Timeout in {}.".format(timeout))
            sleep(1)
            timeout -= 1

        if timeout == 0:
            logging.debug("Timeout to receive response")
            raise NameError("Timeout received, wasn't able get response.")

        if not success_received:
            raise NameError("Did not receive GW_RES_OK")



    def send_sink_config(self, new_config):
        # Hardcoded values. If only a subset of those parameters are needed, just comment them

        topic_request = "gw-request/set_config/{}/{}".format(
            self.gateway_id, self.sink_id)
        topic_response = "gw-response/set_config/{}/{}".format(
            self.gateway_id, self.sink_id)

        # Generate request
        req = wirepas_messaging.gateway.api.SetConfigRequest(
            self.sink_id, new_config)

        logging.debug("Send sink config: {}".format(new_config))
        self.send_request_to_topic(topic_request, topic_response, req,
                                          wirepas_messaging.gateway.api.SetConfigResponse.from_payload)

    def configure(self):
        

        # workaround for bug: https://github.com/wirepas/gateway/issues/194
        # First stop the sink then send the new configuration
        self.sink_stack_set(False)

        new_config = {
            'node_role': 0x11,  # 0x01 is sink while 0x11 is sink CSMA-CA
            'node_address': 1,  # Value to adapt
            'network_address': int(self.network_address),  # Value to adapt
            'network_channel': 2,  # Value to adapt
            # 'app_config_diag': 60, # Value to adapt
            # 'app_config_seq': int(10), # Value to adapt
            # 'app_config_data': bytes.fromhex('AABB0102'), # Value to adapt
        }

        if self.encrypt:
            logging.debug("Use nodes ecryption")
            new_config['cipher_key'] = bytes.fromhex(
                '100F0E0D0C0B0A090807060504030201')
            new_config['authentication_key'] = bytes.fromhex(
                '0102030405060708090A0B0C0D0E0F10')

        logging.info("Configure the sink with net addr: {} - encrypt: {}".format(self.network_address, self.encrypt))
        logging.debug(new_config)

        # Connection is on, do the config
        try:
            self.send_sink_config(new_config)
        except:
            raise NameError("Cannot configure the sink/gateway")

        # workaround for bug: https://github.com/wirepas/gateway/issues/194
        # First stop the sink then send the new configuration
        self.sink_stack_set(True)

        logging.info("Done")

    def sink_stack_set(self, started=True):
        if started:
            logging.info("Request START stack on sink")
        else:
            logging.info("Request STOP stack on sink")

        new_config = {
            'started': started  # Value to adapt
        }

        # Connection is on, do the config
        try:
            self.send_sink_config(new_config)
        except:
            raise NameError("Cannot restart the stack")


    def load_scractchpad(self, otap_file, sequence):

        otap_file_array = open(otap_file, "rb")
        otap_file_bytes = otap_file_array.read()
        otap_file_array.close()

        request = "gw-request/otap_load_scratchpad/{}/{}".format(
            self.gateway_id, self.sink_id)
        response = "gw-response/otap_load_scratchpad/{}/{}".format(
            self.gateway_id, self.sink_id)

        req = wp_api.UploadScratchpadRequest(
            sink_id=self.sink_id,
            scratchpad=otap_file_bytes,
            seq=sequence
        )

        #self.sink_stack_set(False)

        logging.info("Upload OTAP file {} with sequence {}".format(otap_file, sequence))

        self.send_request_to_topic(request, response, req, 
            wp_api.UploadScratchpadResponse.from_payload, timeout=30)

        #self.sink_stack_set(True)
        #sleep(3)

        #Make sure new sequence was actually uploaded
        self.validateNodes([self.sink_address], tries=5)

        logging.info("Upload OTAP file success") 

    

    def process_sink(self):
        
        request = "gw-request/otap_process_scratchpad/{}/{}".format(
            self.gateway_id, self.sink_id)
        response = "gw-response/otap_process_scratchpad/{}/{}".format(
            self.gateway_id, self.sink_id)

        #self.sink_stack_set(False)

        req = wp_api.ProcessScratchpadRequest(
            sink_id=self.sink_id
        )

        logging.info("Start OTAP on sink") 

        self.send_request_to_topic(request, response, req,
                                   wp_api.ProcessScratchpadResponse.from_payload, timeout=30)

        #self.sink_stack_set(True)

        logging.info("OTAP sequence used on sink") 

    def upload_scratchpad(self, otap_file):

        #reload the sequence number
        self.sequence_number, _ = self.get_sequence(self.sink_address)

        self.sequence_number = self.sequence_number + 1

        self.load_scractchpad(otap_file, self.sequence_number)

        logging.info("Wait for propagation to nodes (30s).")
        sleep(30)


    def join(self, nodes_str=""):
        nodes = self.nodes_str_to_list(nodes_str)

        logging.info("Join mesh network for nodes: {}".format(nodes))

        # SPAWN a process for wm-wps
        ps = WirepasProvServer()


        #One needs to export this path during installation
        #example use in the robot folder the command: export ROBOTBASEPATH=$(pwd) 
        base = os.getenv('ROBOTBASEPATH', '')

        assert base is not None

        '''
        Currently there is no way to change the config.yml
        '''

        logging.debug("net addr: {}".format(self.network_address))

        if self.network_address == int(895):       
            config_file=Path(base, "environment/open_join_config_A.yml") #895
        elif self.network_address == int(200):
            config_file=Path(base, "environment/open_join_config_B.yml") #200
        else:
            raise NameError("Only 895 and 200!")

        logging.debug("using cfg file: {}".format(config_file))

        #also the settings file must match the inout to the class connect
        ps.start(
            settings=Path(base, "environment/kone_selfhosted.yml"),
            config=config_file
            )

        try:
            logging.info("Waiting...")
            ps.wait_success()
        except:
            raise NameError("Error! New equipment in mesh network not visible!")



import unittest    

class TestWPMid(unittest.TestCase):

    #executed per each test...
    def setUp(self):

        log_level = logging.INFO
        log_level = logging.DEBUG

        logging.basicConfig(format='Date-Time : %(asctime)s : %(filename)s - %(funcName)s - %(lineno)d - %(message)s',
                            level=log_level)


        network_address = 895
        gw_id = 50

        self.wpmid = WirepasMiddleware()
        self.wpmid.connect(
            host="99.80.45.71",
            port=1883,
            username="wirepas",
            password="UYV6NeWABaxBtx2jaMqe",
            gateway_id=gw_id,
            network_address=network_address)


        self.wpmid.configure()

        time.sleep(2)

        #ping the sink, make sure it's running
        self.wpmid.wait_available(1)

        time.sleep(5)

    def test_a_join(self):

        nodes = self.wpmid.list_nodes(amount=1)

        if len(nodes) > 0:
            self.skipTest("Already provisioned devices")

        self.wpmid.enable_join_beacon()
        self.wpmid.join()
        self.wpmid.disable_join_beacon()

        nodes = self.wpmid.list_nodes(amount=1)

        self.assertTrue(len(nodes) > 0)

    def test_b_base(self):

        nodes = self.wpmid.list_nodes(amount=2)

        self.assertTrue(len(nodes) > 0)

        for addr in nodes:
            self.wpmid.ping(addr)

        for addr in nodes:
            self.wpmid.get_version_area(addr)

        node_yabb330 = "2088540176"

        try:
            self.wpmid.change_application(node_yabb330)
        except:
            pass


        self.wpmid.start_otap_nodes("yabb330_app.otap", node_yabb330,
             "V0.1.6.153", "yabb330_app")
        


if __name__ == '__main__':
    #unittest.main()
    suite = unittest.TestLoader().loadTestsFromTestCase(TestWPMid)
    unittest.TextTestRunner(verbosity=2).run(suite)
