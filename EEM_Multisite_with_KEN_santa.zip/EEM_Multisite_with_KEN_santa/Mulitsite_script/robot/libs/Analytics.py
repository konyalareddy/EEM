import unittest
import numpy as np
import math
import itertools as it
import operator
import functools

from TLD import TLD

class Analytics:

    def __init__(self):
        #required to decode and stuff
        self.tld = TLD()

    def convert_message_bytes_to_int(self, bytes_):
        return int.from_bytes(bytes_, byteorder="little")

    def parse_tld_message(self, message):
        return {
            "tag": message[0],
            "length": message[1],
            "crc": self.convert_message_bytes_to_int(message[2:4]),
            "sequence_number": message[4],
            "payload": message[5:],
        }

    def parse_token_slave_return_message(self, message):
        message = self.parse_tld_message(message)
        payload = message["payload"]
        return {
            "id": self.convert_message_bytes_to_int(payload[0:4]),
            "count": self.convert_message_bytes_to_int(payload[4:6]),
            "remaining": self.convert_message_bytes_to_int(payload[6:8]),
            **message
        }

    def parse_sniffer_done_message(self, message):
        message = self.parse_tld_message(message)
        payload = message["payload"]
        return {
            "rxseq": payload[0],
            "donecode": payload[1],
            **message
        }

    def parse_sniffer_error_message(self, message):
        message = self.parse_tld_message(message)
        payload = message["payload"]
        return {
            "rxseq": payload[0],
            "errorcode": payload[1],
            **message,
        }

    def parse_waveform_bits_message(self, message):
        """
        Parse waveform bits message formatted as `split_to_messages`
        output to a dictionary with struct fields.
        """
        message = self.parse_tld_message(message)
        waveform = message["payload"]
        source_channel = waveform[0]
        byte_count = waveform[1]
        final_byte_bit_count = waveform[2]
        byte_array = waveform[3:]
        bits = "".join("{:08b}".format(b)[::-1] for b in byte_array)

        return {
            "source_channel": source_channel,
            "byte_count": byte_count,
            "final_byte_bit_count": final_byte_bit_count,
            "bytes": byte_array,
            "bits": bits[:-(8 - final_byte_bit_count)],
            **message
        }

    def parse_waveform_delta_message(self, message):
        """
        Parse waveform delta message formatted as `split_to_messages`
        output to a dictionary with struct fields.
        """
        message = self.parse_tld_message(message)
        waveform = message["payload"]

        channel = waveform[0]
        timer_speed = self.convert_message_bytes_to_int(waveform[1:1 + 4])
        timer_width = waveform[5]
        capture_id = waveform[6]
        segment = waveform[7]
        first_symbol = waveform[8]

        delta_count = self.convert_message_bytes_to_int(waveform[9:9 + 2])
        deltas = waveform[11:11 + 4 * delta_count]

        return {
            "source_channel": channel,
            "capture_id": capture_id,
            "segment": segment,
            "timer_width": timer_width,
            "timer_speed": timer_speed,
            "delta_count": delta_count,
            "deltas": [
                self.convert_message_bytes_to_int(deltas[i:i + 4])
                for i in range(0, len(deltas), 4)
            ],
            "symbols": list(
                it.islice(
                    it.cycle([first_symbol, first_symbol^1]),
                    delta_count
                )
            ),
            **message
        }

    def parse_device_firmware_info_message(self, message):
        """
        Parse firmware info message to a dictionary.
        """
        message = self.parse_tld_message(message)
        payload = message["payload"]
        return {
            "device_type": payload[0:4],
            "version": payload[4:8],
            "last_boot": payload[8:12],
            "flash_alignment": payload[12],
            **message,
        }

    def parse_device_info_message(self, message):
        """
        Parse device info message to a dictionary.
        """
        message = self.parse_tld_message(message)
        payload = message["payload"]
        return {
            "mcupart": self.convert_message_bytes_to_int(payload[0:2]),
            "mcuid": payload[2:10],
            "uptime": self.convert_message_bytes_to_int(payload[10:14]),
            "pressure": self.convert_message_bytes_to_int(payload[14:18]),
            "temperature": self.convert_message_bytes_to_int(payload[18:22]),
            "version": payload[22:26],
            "last_boot": payload[26:30],
            "nameplate": payload[30:70],
            **message,
        }

    def parse_measurement_logic_data_message(self, message):
        message = self.parse_tld_message(message)
        payload = message["payload"]
        return {
            "channel": payload[0],
            "size": payload[1],
            "data": payload[2:],
            **message,
        }

    def parse_elevator_service_port_message(self, message):
        message = self.parse_tld_message(message)
        payload = message["payload"]
        return {
            "size": payload[0],
            "data": payload[1:],
            **message,
        }

    def parse_measurement_can_bus_message(self, message):
        message = self.parse_tld_message(message)
        payload = message["payload"]
        def parse_can_msgs():
            count = int(payload[1])
            start = 2
            n = 13
            msgs = [payload[start+i:start+i+n] for i in range(0, len(payload)-start, n)]
            ret = []
            for m in msgs:
                ret.append({
                    "id": m[0:4],
                    "length": m[4],
                    "data": m[5:14],
                })
            return ret

        return {
            "source_channel": payload[0],
            "message_count": payload[1],
            "messages": parse_can_msgs(),
            **message,
        }

    def parse_measurement_barometer(self, message):
        message = self.parse_tld_message(message)
        payload = message["payload"]

        return {
            "pressure": self.convert_message_bytes_to_int(payload[0:4]),
            "temperature": self.convert_message_bytes_to_int(payload[4:8]),
        }

    def parse_waveform_messages(self, message):
        msgs = list(self.tld.split_to_messages(message))
        return [self.parse_waveform_delta_message(m) for m in msgs if
                self.tld.is_waveform_delta_message(m)]

    def parse_waveform_bits_messages(self, msgstring):
        msgs = list(self.tld.split_to_messages(msgstring))
        return [self.parse_waveform_bits_message(m) for m in msgs if
                self.tld.is_waveform_bits_message(m)]

    def _concatenate_message_fields(self, tag, parser, field, msgstring):
        msgs = self.tld.filter_given_messages(tag, msgstring)
        parsed = [parser(m) for m in msgs]
        fields = [p[field] for p in parsed]
        return list(functools.reduce(operator.concat, fields))

    def get_measurement_logic_data_from_messages(self, msgstring):
        return self._concatenate_message_fields(
            'TLD_TAG_MEASUREMENT_LOGIC_DATA',
            self.parse_measurement_logic_data_message,
            'data',
            msgstring
        )

    def get_elevator_service_port_data_from_messages(self, msgstring):
        return self._concatenate_message_fields(
            'TLD_TAG_ELEVATOR_SERVICE_PORT_MSG',
            self.parse_elevator_service_port_message,
            'data',
            msgstring
        )

    def estimate_baudrate(self, deltas, timer_speed=36e6):
        """Estimate baudrate from waveform message deltas and timer speed"""
        return 2 / (deltas + np.roll(deltas, 1)).min() * timer_speed

    def get_binary_content(self, deltas, symbols, baudrate, timer_speed=36e6):
        """Get waveform as binary content based on estimated baudrate"""
        symbol_counts = (deltas * baudrate / timer_speed).round().astype(int)
        return ''.join(count * str(symbol) for symbol, count in zip(symbols, symbol_counts))

    def _get_median_cycle_lengths(self, deltas):
        first = deltas[::2]
        second = deltas[1::2]
        return [int(np.median(first)), int(np.median(second))]

    def get_pwm_frequency(self, delta_message):
        """Get the PWM frequency by dividing the timer speed with the first two deltas"""
        speed = delta_message['timer_speed']
        deltas = delta_message['deltas']
        first, second = self._get_median_cycle_lengths(deltas)
        return speed / (first + second)

    def get_pwm_duty_cycle(self, delta_message):
        """Gets the first duty cycle. The second can be calculated by subtracting
        the first from 100."""
        deltas = delta_message['deltas']
        first, second = self._get_median_cycle_lengths(deltas)
        return (first / (first + second)) * 100

    def get_waveform_bits_from_messages(self, msgstring):
        return self._concatenate_message_fields(
            'TLD_TAG_MEASUREMENT_WAVEFORM_BITS',
            self.parse_waveform_bits_message,
            'bits',
            msgstring
        )

    def get_measurement_can_bus_messages(self, msgstring):
        msgs = self.tld.filter_given_messages('TLD_TAG_MEASUREMENT_CAN_BUS', msgstring)
        return [self.parse_measurement_can_bus_message(m) for m in msgs]

    def get_measurement_can_bus_message_contents(self, msgstring):
        msgs = self.get_measurement_can_bus_messages(msgstring)
        return ['{}:{}'.format(
            # Use the first two bytes as that is the limit of the ID in the
            # CANAdapter.py
            self.tld.to_hexstring(m['id'], delimiter='')[0:2],
            self.tld.to_hexstring(m['data'][0:m['length']], delimiter=''),
        ) for tldmsg in msgs for m in tldmsg['messages']]

    def should_be_about_equal(self, a, b, percentage):
        """Returns true when given values are within some percentage of each other"""
        if not math.isclose(a, b, rel_tol=(percentage / 100)):
            raise ValueError('{} != {} (~ {}%)'.format(a, b, percentage))

    def parse_serial_bits(self, bits, databits=8, parity='n', stopbits=1):
        """Parses an array of bits as serial data
        and returns the value as a hexstring."""
        if parity in ['n', 'N']:
            parity = 0
        elif parity in ['o', 'O', 'e', 'E']:
            parity = 1

        startbits = 1
        chunksize = startbits + databits + parity + stopbits

        # Delete possible prefix 1-bits (start bit is zero)
        while len(bits) > 0 and bits[0] == '1':
            bits.pop(0)

        # delete trailing 1-bits
        while len(bits) > 0 and bits[-1] == '1':
            bits.pop()

        # The stop bit is 1 so add it as it was deleted in the previous step
        bits.append('1')

        # split the bitarray into chunks
        chunks = [bits[i:i+chunksize] for i in range(0, len(bits), chunksize)]

        # Parse the databits from the chunks
        # The data is in least-significant-bit-first format so it needs to be
        # reversed.
        databytes = [int(''.join(reversed(b[startbits:startbits+databits])), 2) for b in chunks]

        # Convert the bytes to hexstring
        return self.tld.to_hexstring(databytes)


class TestAnalytics(unittest.TestCase):

    waveform_delta_test_data = (
        "c0067fc9a1020000512502200002011d004a010000b20300002f01000042010000a00300004101000030010000420100002f010000420100002f0100007a02000068020000420100002f01000042010000680200007a020000a00300004201000030010000b20300002f01000042010000a1030000410100"
        "00300100004101000030010000c0c0067f720c030000512502200001001d00b3030000680200007a0200002f0100007a020000300100007a020000680200007a0200002f01000042010000680200007a020000680200007a02000030010000b20300003001000042010000670200007b0200002f01000042"
        "0100002f0100004201000068020000eb0400002f0100007b020000c0c0061f12300400005125022000000105002f010000420100002f010000ec04000022500000c0"
        "c0067f2666050000512502200102011d004b010000b10300002f01000042010000a00300004101000030010000410100002f010000420100002f0100007a02000067020000420100003001000042010000690200007b020000a0030000420100002f010000b20300003001000041010000a2030000420100"
        "002f0100004201000030010000c0c0067f01ab060000512502200101001d00b3030000680200007b020000300100007c0200002f0100007c020000690200007c02000030010000420100006a0200007c020000690200007c0200002f010000b50300003001000043010000690200007c0200003001000042"
        "01000030010000420100006a020000ee040000300100007c020000c0c0061f0856070000512502200100010500300100004201000030010000ee04000094500000c0"
        "c0067fc60c080000512502200202011d004b010000ea0400002f0100004201000067020000420100002f010000420100002f010000420100002f0100007a02000067020000420100002f010000b3030000670200004101000067020000410100002e010000410100006802000079020000a0030000420100"
        "002f010000420100002f010000c0c0067f2034090000512502200201001d007a0200002f0100004101000068020000410100002f0100007a020000a00300004201000067020000420100002f0100004101000068020000420100002f0100004101000068020000410100002f010000420100002f0100007a"
        "0200002f0100004201000067020000420100002f01000041010000c0c006378e4e0a0000512502200200010b00300100004101000068020000ea040000300100007a0200002f010000410100002f010000eb0400008b500000c0"
        "c0067fe1dbdd0b0000512502200302011d00be0e0000b63a0000a00e0000ae0e0000411d0000ae0e00009c0e0000ae0e00009d0e0000ae0e00009c0e0000541d0000421d0000af0e00009c0e0000fb2b0000411d0000ae0e0000411d0000b40e0000a10e0000b30e0000541d0000621d0000f52b0000b40e"
        "0000a20e0000b30e0000a30e0000c0c0067ff3a60c0000512502200301001d005e1d0000a20e0000b40e00004d1d0000b20e00009e0e0000561d0000ec2b0000b20e0000481d0000b00e0000a00e0000b10e0000401d0000aa0e0000920e0000ac0e0000431d0000ad0e00009c0e0000ad0e00009b0e0000"
        "511d00009b0e0000b20e00004c1d0000b40e0000a20e0000b40e0000c0c0063fb27a0d0000512502200300010d00a30e0000b30e00004d1d0000b33a0000a20e0000601d0000a30e0000b50e0000a30e0000b33a0000ad5f00004100000075000000c0"
    )

    waveform_bits_test_data = (
        "c007153caf35001204a7a665666666a65a5665f90700009899990ac0"
        "c0070ecc6036000b0298556955a5aa9aaa5a5501c0"
        "c0070db38a37000a04a75a555555aaaaaaaa0ac0"
        "c0070dae8538000a01a8aaaaaaaaaaaaaaaa00c0"
        "c0070e13c139000b012855cdac2a2d55d552b532c0"
    )

    def setUp(self):
        self.al = Analytics()

    def _assert_baudrate(self, actual, expected, tolerance=0.005):
        error = np.abs(actual - expected) / expected
        self.assertLessEqual(
            error,
            tolerance,
            f"{actual} != {expected}, error {error:.02%} > tolerance {tolerance:.02%}"
        )

    def test_parse_waveform_delta_message(self):
        waveform_messages = [
            self.al.parse_waveform_delta_message(message)
            for message in self.al.tld.split_to_messages(self.waveform_delta_test_data)
            if self.al.tld.is_waveform_delta_message(message)
        ]
        self.assertEqual(len(waveform_messages), 12)
        for message in waveform_messages:
            self.assertEqual(message["source_channel"], 0)
            self.assertEqual(message["delta_count"], len(message["deltas"]))
            self.assertEqual(len(message["deltas"]), len(message["symbols"]))
            self.assertEqual(set(message["symbols"]), {0x00, 0x01})
            self.assertEqual(message["timer_speed"], 36 * 1000 * 1000)

    def test_parse_waveform_bits_message(self):
        waveform_messages = [
            self.al.parse_waveform_bits_message(message)
            for message in self.al.tld.split_to_messages(self.waveform_bits_test_data)
            if self.al.tld.is_waveform_bits_message(message)
        ]
        self.assertEqual(len(waveform_messages), 5)
        for message in waveform_messages:
            self.assertEqual(message["source_channel"], 0)
            self.assertEqual(message["byte_count"], len(message["bytes"]))
            self.assertEqual(
                len(message["bits"]),
                message["byte_count"] * 8 - (8 - message["final_byte_bit_count"])
            )

    def test_estimate_baudrate(self):
        waveform_messages = [
            self.al.parse_waveform_delta_message(message)
            for message in self.al.tld.split_to_messages(self.waveform_delta_test_data)
            if self.al.tld.is_waveform_delta_message(message)
        ]
        deltas = np.array(
            list(
                it.chain.from_iterable(waveform['deltas'] for waveform in waveform_messages)
            )
        )
        symbols = np.array(
            list(
                it.chain.from_iterable(waveform['symbols'] for waveform in waveform_messages)
            )
        )
        deltas, symbols = (
            np.split(deltas, np.argwhere(deltas > 20000).flatten())[:-1],
            np.split(symbols, np.argwhere(deltas > 20000).flatten())[:-1]
        )
        self._assert_baudrate(self.al.estimate_baudrate(deltas[0], 36e6), 115200)
        self._assert_baudrate(self.al.estimate_baudrate(deltas[1], 36e6), 115200)
        self._assert_baudrate(self.al.estimate_baudrate(deltas[2], 36e6), 115200)
        self._assert_baudrate(self.al.estimate_baudrate(deltas[3], 36e6), 9600)

    def test_parse_measurement_can_bus_message(self):
        data = [
            {'msg': 'C0 0C 0F F4 6B 06 01 01 FE 00 00 00 05 01 5D 68 EF 45 00 00 00 C0 C0 10 08 67 31 06 01 00 00 00 01 00 00 00 C0',
             'out': '''source: 1
count: 1
id: FE 00 00 00
length: 5
data: 01 5D 68 EF 45 00 00 00
''',
             'contents': ['FE:015D68EF45'],
             },
            {'msg': 'C0 0C 1C 7B E5 04 01 02 FE 00 00 00 05 01 5D 68 EF 45 00 00 00 B0 00 00 00 05 FF FF 00 00 AA 00 00 00 C0 C0 10 08 67 31 04 01 00 00 00 01 00 00 00 C0',
             'out': '''source: 1
count: 2
id: FE 00 00 00
length: 5
data: 01 5D 68 EF 45 00 00 00

id: B0 00 00 00
length: 5
data: FF FF 00 00 AA 00 00 00
''',
             'contents': ['FE:015D68EF45', 'B0:FFFF0000AA'],
             },
        ]

        def data_str(data):
            ret = 'source: {}\ncount: {}\n'.format(
                data['source_channel'],
                data['message_count']
            )
            ret += '\n'.join(['id: {}\nlength: {}\ndata: {}\n'.format(
                self.al.tld.to_hexstring(m['id']),
                m['length'],
                self.al.tld.to_hexstring(m['data']),
            ) for m in data['messages']])
            return ret

        import difflib

        for d in data:
            with self.subTest(d):
                msg = list(self.al.tld.filter_given_messages('TLD_TAG_MEASUREMENT_CAN_BUS', d['msg']))
                parsed = self.al.parse_measurement_can_bus_message(msg[0])
                s1 = data_str(parsed).split('\n')
                s2 = d['out'].split('\n')
                diff = list(difflib.unified_diff(s1, s2, fromfile='got', tofile='expected'))
                self.assertEqual('\n'.join(diff), '')

                # Check the contents
                contents = self.al.get_measurement_can_bus_message_contents(d['msg'])
                self.assertEqual(d['contents'], contents)


    def test_parse_device_firmware_info_message(self):
        data = [
            {'msg': 'C0 1A 0D AE 95 00 01 00 00 00 88 01 00 02 01 00 00 00 02 C0 C0 10 08 67 31 00 01 00 00 00 01 00 00 C0',
             'version': '88 01 00 02', 'flash_alignment': 2},
            {'msg': 'C0 1A 0D C9 53 00 01 00 00 00 8A 01 00 02 01 00 00 00 02 C0 C0 10 08 67 31 00 01 00 00 00 01 00 00 00 C0',
             'version': '8A 01 00 02', 'flash_alignment': 2},
        ]
        for d in data:
            with self.subTest(d):
                msg = list(self.al.tld.filter_given_messages('TLD_TAG_DEVICE_FIRMWARE_INFO', d['msg']))
                parsed = self.al.parse_device_firmware_info_message(msg[0])
                self.assertEqual(d['version'], self.al.tld.to_hexstring(parsed['version']))
                self.assertEqual(d['flash_alignment'], parsed['flash_alignment'])

    def test_should_be_about_equal(self):
        data = [
            {'a': 10, 'b': 10, 'perc': 1, 'equal': True},
            {'a': 9, 'b': 10, 'perc': 10, 'equal': True},
            {'a': 9, 'b': 10, 'perc': 5, 'equal': False},
            {'a': 50, 'b': 68, 'perc': 5, 'equal': False},
            {'a': 50, 'b': 32, 'perc': 5, 'equal': False},
        ]
        for d in data:
            with self.subTest(d):
                if not d['equal']:
                    with self.assertRaises(ValueError):
                        self.al.should_be_about_equal(d['a'], d['b'], d['perc'])
                else:
                    self.al.should_be_about_equal(d['a'], d['b'], d['perc'])

    def test_get_elevator_service_port_data_from_messages(self):
        data = [
            # test1234 split in two messages
            {'in': 'C0 12 07 47 25 02 06 74 65 73 74 31 32 C0 C0 12 03 71 48 03 02 33 34 C0 C0 10 08 BB AA 02 01 00 00 00 02 00 00 00 C0',
             'out': '74 65 73 74 31 32 33 34',
             }
        ]
        for d in data:
            with self.subTest(d):
                out = self.al.get_elevator_service_port_data_from_messages(d['in'])
                out = self.al.tld.to_hexstring(out)
                self.assertEqual(out, d['out'])

    def test_parse_serial_bits(self):
        data = [
            {'in': '1010000110100100011010110001101111111111111',
             'out': '61 62 63'},
            {'in': '1010001100100100110010110011001000101100101010110010011011001011101100100001110010100111001000001100111111111111111111111111',
             'out': '31 32 33 34 35 36 37 38 39 30'},
        ]

        for d in data:
            with self.subTest(d):
                splitdata = list(d['in'])
                out = self.al.parse_serial_bits(splitdata)
                self.assertEqual(out, d['out'])


if __name__ == '__main__':
    unittest.main()
