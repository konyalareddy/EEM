"""A library for *documentation format* demonstration purposes.

This documentation is created using reStructuredText__. Here is a link
to the only \`Keyword\`.

__ http://docutils.sourceforge.net
"""

from robot.api.deco import keyword, library
from robot.libraries.BuiltIn import BuiltIn
from robot.api import logger 


import os.path
import time
from datetime import datetime, timedelta


def ask_question(self, question="Are you ready?"):

    question = "{} (Enter): ".format(question)
    BuiltIn().log_to_console(question)
    input()
        

try:
    import RPi.GPIO as GPIO
except:
    print("Cannot use RPI library on this system")



@library(scope='GLOBAL', auto_keywords=True)
class SlaveControls():

    #Input readins, aka Buttons
    RELAY_PINS = [2, 3]

    #Output pins, aka LEDs
    POWER_CYCLE_PINS = [27, 22, 23, 24]

    # The relays that select the CAN bus sniffer channel are the last two
    # power pins
    CAN_SELECT_PINS = POWER_CYCLE_PINS[2:]

    PWM_PIN = 18

    SERVICE_PORT_CTL_PIN = 5

    def __init__(self):

        self.relay_record = {}

        try:

            GPIO.setmode(GPIO.BCM)

            GPIO.setwarnings(False)

            logger.info("Starting RPI gpio {}")

            GPIO.setup(self.RELAY_PINS, GPIO.IN)
            
            GPIO.setup(self.POWER_CYCLE_PINS, GPIO.OUT)

            GPIO.setup(self.SERVICE_PORT_CTL_PIN, GPIO.OUT)

            self.make_sure_all_powered()
        except:
            logger.error("Cannot use RPI library on this system")

    def __del__(self):
        self.make_sure_all_powered()

    def calibrate_relay(self, idx):
        """Instructs the class that relay of idx should now be ON. Other relay
        should be OFF.

        This function checks if the relays have been installed differently
        than expected.
        """

        idx = int(idx)

        # Get the state so that: relay ON == relay closed == False == 0
        states = [self.get_relay_state(i)
                  for i in range(len(self.RELAY_PINS))]

        print(states)
        print(self.RELAY_PINS)

        # if the expected idx is ON
        if states[idx] == 0:
            logger.info("Remote call relays are installed in correct order.")
        else:
            # As there are only two relays swap their places to interpret
            # values differently
            self.RELAY_PINS.reverse()
            logger.info("Remote call relays are installed in reverse.")

        print(self.RELAY_PINS)

    def start_recording_relay_states(self, idx=0, state_changes=-1):
        """Start recording state changes in the given relay.
        Stop if the given number of state changes is reached."""
        idx = int(idx)
        state_changes = int(state_changes)
        channel = self.RELAY_PINS[idx]
        if channel in self.relay_record and self.relay_record[channel]['running']:
            return

        self.relay_record[channel] = {
            'initial_state': self.get_relay_state(idx),
            'changes': [datetime.now()],
            'running': True,
            'state_changes': state_changes,
        }

        def _relay_change_cb(channel):
            self.relay_record[channel]['changes'].append(datetime.now())
            if self.relay_record[channel]['state_changes'] > 0:
                self.relay_record[channel]['state_changes'] -= 1
            if self.relay_record[channel]['state_changes'] == 0:
                self.stop_recording_relay_states(idx)

        GPIO.add_event_detect(channel, GPIO.BOTH, callback=_relay_change_cb)

    def get_relay_state_record(self, idx):
        """Return a report of the measured relay states for the given relay index.
        The returned is a list of cells fof the following format:
        (relay state, length in timedelta)"""
        idx = int(idx)
        channel = self.RELAY_PINS[idx]
        if channel not in self.relay_record:
            return []

        ret = []
        changes = self.relay_record[channel]['changes']
        pos = changes[0]
        state = self.relay_record[channel]['initial_state']
        for c in changes[1:]:
            ret.append((state, c - pos))
            pos = c
            state = 1 if state == 0 else 0

        return ret

    def stop_recording_relay_states(self, idx):
        """Stops recording the states of given relay denoted by the idx."""
        idx = int(idx)
        channel = self.RELAY_PINS[idx]

        if not self.relay_record[channel]['running']:
            return

        self.relay_record[channel]['running'] = False

        GPIO.remove_event_detect(channel)

    def wait_until_stopped_recording_relay_states(self, idx=0, timeout_s=5):
        """Block until given number of relay states have been recorded,
        or timeout is reached."""
        idx = int(idx)
        timeout_s=int(timeout_s)
        channel = self.RELAY_PINS[idx]

        for x in range(timeout_s):
            if not self.relay_record[channel]['running']:
                break
            time.sleep(1)

        self.stop_recording_relay_states(idx)
        return self.get_relay_state_record(idx)

    def relay_state_record_has_state_of_length(self, record, state, milliseconds,
                                               precision_percent=5):
        """Evaluates the relay state record and verifies that it has at least
        one state with given length in milliseconds.
        The precision is 5% by default"""
        state = int(state)
        milliseconds = int(milliseconds)
        precision_percent = int(precision_percent)

        precision = milliseconds * (precision_percent / 100)
        minimum = timedelta(milliseconds=milliseconds - precision)
        maximum = timedelta(milliseconds=milliseconds + precision)

        for r in record:
            if r[0] == state and r[1] >= minimum and r[1] <= maximum:
                return

        raise NameError('State {} of length {} not found in record: {}'.format(
            state, milliseconds, record
        ))

    def get_relay_state(self, idx=0):

        self.result = True

        try:
            self.result = GPIO.input(self.RELAY_PINS[idx])
        except:
            logger.info("Cannot use RPI library on this system")

        logger.info("Rel idx:{}, val:{}".format(
            idx, self.result))

        return self.result

    def make_sure_all_powered(self):

        logger.info("Making sure all devices are powered")

        try:
            #all connections are in NC (Normally closed) when GPIO is low
            for p in self.POWER_CYCLE_PINS:
                GPIO.output(p, GPIO.LOW)

        except:
            logger.error("Cannot use RPI library on this system")

    def power_cycle(self, channel="1"):

        channel = int(channel)

        assert(channel > 0 and channel < 5)
        #Only one device, main powercycle is available
        logger.info("Powercycle of {}".format(channel))

        p = self.POWER_CYCLE_PINS[channel - 1]

        try:

            #RELAYS are Normally closed, powercut with supply
            GPIO.output(p, GPIO.HIGH)
            time.sleep(1)
            GPIO.output(p, GPIO.LOW)
            time.sleep(1)
        except:
            logger.error("Cannot use RPI library on this system")
            ask_question("Please powercycle manually channel {}".format(channel))

    def select_can(self, sniffer_port="1"):
        """Select into which sniffer port the CAN bus is connected to.

        Hardware-wise, the CAN+ and CAN- are connected to the Relay Shield
        (https://wiki.seeedstudio.com/Relay_Shield_v3/) Relays 3 and 4. On the
        Raspberry Pi side, they have the same GPIO-pins as the power relays
        for both Anylift and YABB330 Stidis.

        As this method uses the same relays as powering the stidis, this
        should only be used in setups without those stidis. I.e. Module test
        setups.

        Raspberry Pi connections:
        https://confluence.kone.cbyte.fi/pages/viewpage.action?spaceKey=YABB330&title=RPI+electrical+connections

        YABB330 module testing setups:
        https://confluence.kone.cbyte.fi/display/YABB330/YABB330+module+testing#YABB330moduletesting-VariantB
        """

        ports = ['0', '1']
        port = sniffer_port.upper()
        if not port in ports:
            raise OSError('Unknown CAN sniffer port given: {}'.format(port))

        value = GPIO.HIGH if port == '0' else GPIO.LOW

        for p in self.CAN_SELECT_PINS:
            print('Setting gpio {} to value {}'.format(p, value))
            GPIO.output(p, value)

    def _setup_pwm(self, enable, frequency=1000, cycle=50, duration=1):
        pwmchip = '/sys/class/pwm/pwmchip0'
        if not os.path.exists(pwmchip):
            raise OSError('Hardware PWM is not enabled. Add "dtoverlay=pwm,pin=18,func=2" to /boot/config.txt')

        def write_pwm_file(path, content):
            with open(os.path.join(pwmchip, path), "w+") as f:
                print(content, file=f)

        pwmdevice = 'pwm0'
        pwm = os.path.join(pwmchip, pwmdevice)
        if enable:
            if not os.path.exists(pwm):
                write_pwm_file('export', '0')

                # Hard-coded sleep to wait for udev to set proper permissions
                time.sleep(1)

            period_ns = int((1 / frequency) * 1000000000)
            duty_cycle = int(period_ns * (cycle / 100))

            print('period {}'.format(period_ns))
            print('duty {}'.format(duty_cycle))

            # Set period first to a high value and then set the duty cycle to
            # zero. If at any point the duty_cycle >= period, writing to these
            # files fails with EINVAL.
            write_pwm_file(os.path.join(pwmdevice, 'period'), '900000000')
            write_pwm_file(os.path.join(pwmdevice, 'duty_cycle'), '0')

            write_pwm_file(os.path.join(pwmdevice, 'period'), str(period_ns))
            write_pwm_file(os.path.join(pwmdevice, 'duty_cycle'), str(duty_cycle))

            write_pwm_file(os.path.join(pwmdevice, 'enable'), '1')
            time.sleep(duration)
            write_pwm_file(os.path.join(pwmdevice, 'enable'), '0')
        else:
            if os.path.exists(pwm):
                write_pwm_file(os.path.join(pwmdevice, 'enable'), '0')
                write_pwm_file('unexport', '0')

    def set_pwm(self, freq, duty, dur):
        print("freq:{} - duty:{} - dur:{}".format(freq, duty, dur))

        enable = True
        if freq == 0:
            enable = False
        self._setup_pwm(enable, freq, duty, dur)

    def select_service_port(self, port="service_rs232"):
        logger.info("Selecting service port: {}".format(port))

        try:
            if port.find("rs232") >= 0:
                GPIO.output(self.SERVICE_PORT_CTL_PIN, GPIO.LOW)
            elif port.find("rs422") >= 0:
                GPIO.output(self.SERVICE_PORT_CTL_PIN, GPIO.HIGH)
            else:
                raise NameError("Port not known")

        except:
            logger.error("Cannot use RPI library on this system")


import unittest
import logging

class TestSlaveControls(unittest.TestCase):

    def test_start(self):

        logging.basicConfig(format='Date-Time : %(asctime)s : Line No. : %(lineno)d - %(message)s', \
                    level = logging.DEBUG)

        self.sc = SlaveControls()
        
        res = self.sc.relay(0)

        print(res)

        #there should be a string result
        self.assertTrue(res)

        res = self.sc.relay(1)

        print(res)
        #there should be a string result
        self.assertTrue(res)

        #powercycle
        self.sc.power_cycle(1)
        self.sc.power_cycle(2)
        self.sc.power_cycle(3)
        self.sc.power_cycle(4)

        #when descructor is called there should also be all devices ON

if __name__ == '__main__':
    unittest.main()




