from halfduplex import HalfDuplex
from tld import TLD

import argparse
import queue
import os, math
import sys
import logging
import time

'''
•	Refactor fwupdater.py to YABB330_OTAP.py and corresponding base class with same name. This is because RobotFramework “requires” class=filename to convert into keyword.
•	Move it into the library folder for integration test: https://scm.kone.com/kone/projects/maintenance_development/repositories/yabb330_integration_testing/tree/dev?path=robot%2Flibs
•	Print should turn into a logging.debug or logging.info example logging.info("Step B")
•	Print only a simple progress such as 80% done, 90% done etc… Success at the end
•	Exit with error code such as exit(1) or exit(2), exit (0) on success

'''

# TODO: Extend the TLD class??
class TLD_OTAP:
    OTAP_TAGS = { \
        "TLD_TAG_OTAP_START_REQ":19, \
        "TLD_TAG_OTAP_START_RESP":20, \
        "TLD_TAG_OTAP_FRAME":21, \
        "TLD_TAG_OTAP_FRAME_ACK":22, \
        "TLD_TAG_OTAP_FRAME_REQ":23, \
        "TLD_TAG_OTAP_ERROR":24, \
        "TLD_TAG_OTAP_END":25, \
        "TLD_TAG_DEVICE_FIRMWARE_INFO":26, \
        "TLD_TAG_DEVICE_INFO_REQ":28, \
        "TLD_TAG_SNIFFER_ERROR":30, \
    }
    
    TLD_TAG_OTAP_START_REQ = OTAP_TAGS["TLD_TAG_OTAP_START_REQ"]
    TLD_TAG_OTAP_START_RESP = OTAP_TAGS["TLD_TAG_OTAP_START_RESP"]
    TLD_TAG_OTAP_FRAME = OTAP_TAGS["TLD_TAG_OTAP_FRAME"]
    TLD_TAG_OTAP_FRAME_ACK = OTAP_TAGS["TLD_TAG_OTAP_FRAME_ACK"]
    TLD_TAG_OTAP_FRAME_REQ = OTAP_TAGS["TLD_TAG_OTAP_FRAME_REQ"]
    TLD_TAG_OTAP_ERROR = OTAP_TAGS["TLD_TAG_OTAP_ERROR"]
    TLD_TAG_OTAP_END = OTAP_TAGS["TLD_TAG_OTAP_END"]
    TLD_TAG_DEVICE_FIRMWARE_INFO = OTAP_TAGS["TLD_TAG_DEVICE_FIRMWARE_INFO"]
    TLD_TAG_DEVICE_INFO_REQ = OTAP_TAGS["TLD_TAG_DEVICE_INFO_REQ"]
    TLD_TAG_SNIFFER_ERROR = OTAP_TAGS["TLD_TAG_SNIFFER_ERROR"]
    
    FRAME_HEADER_SIZE = 9
    FRAME_ALIGNMENT = 4
    # must align with the internal flash write requirements, which is 4 bytes
    FRAME_PAYLOAD_SIZE = TLD.TLD_MAX_PAYLOAD_SIZE - FRAME_HEADER_SIZE - ((TLD.TLD_MAX_PAYLOAD_SIZE - FRAME_HEADER_SIZE) % FRAME_ALIGNMENT) # = 116 # = TLD.TLD_MAX_PAYLOAD_SIZE - FRAME_HEADER_SIZE - 1
    
    def get_otap_start_req(updateid, framecount):
        return TLD.get_tld_msg(TLD_OTAP.TLD_TAG_OTAP_START_REQ, ( list(updateid.to_bytes(4, byteorder='little')) + [0x00] + list(framecount.to_bytes(4, byteorder='little'))), sequence=252)
        
    def get_otap_frame(updateid, frameid, frame, framelen=-1):
        length = [framelen]
        if framelen < 0:
            length = list(len(frame).to_bytes(1, byteorder='little'))
        # length should be under 255, but this forces it...
        payload = (list(updateid.to_bytes(4, byteorder='little')) + list(frameid.to_bytes(4, byteorder='little')) + length + list(frame))
        logging.debug("FWUDPATER DEBUG: frame payload " + str(payload))
        return TLD.get_tld_msg(TLD_OTAP.TLD_TAG_OTAP_FRAME, payload, sequence=frameid % 0xFF)
        
    def get_otap_end(updateid, cancel=False):
        msg = list(updateid.to_bytes(4, byteorder='little'))
        if cancel:
            msg.append(0xFF)
        else:
            msg.append(1)
        return TLD.get_tld_msg(TLD_OTAP.TLD_TAG_OTAP_END, msg, sequence=251)

    def get_device_info_req():
        return TLD.get_tld_msg(TLD_OTAP.TLD_TAG_DEVICE_INFO_REQ, [2, 0, 0, 0], sequence=250)
    
    def parse_otap_tld(msg):
        if msg[0] == TLD_OTAP.TLD_TAG_OTAP_START_RESP:
            return ("TLD_TAG_OTAP_START_RESP", TLD_OTAP.parse_otap_start_resp(msg))
        
        if msg[0] == TLD_OTAP.TLD_TAG_OTAP_FRAME_ACK:
            return ("TLD_TAG_OTAP_FRAME_ACK", TLD_OTAP.parse_otap_frame_ack(msg))
        
        if msg[0] == TLD_OTAP.TLD_TAG_OTAP_FRAME_REQ:
            return ("TLD_TAG_OTAP_FRAME_REQ", TLD_OTAP.parse_otap_frame_req(msg))
            
        if msg[0] == TLD_OTAP.TLD_TAG_OTAP_ERROR:
            return ("TLD_TAG_OTAP_ERROR", TLD_OTAP.parse_otap_error(msg))
            
        if msg[0] == TLD_OTAP.TLD_TAG_OTAP_END:
            return ("TLD_TAG_OTAP_END", TLD_OTAP.parse_otap_end(msg))
            
        if msg[0] == TLD_OTAP.TLD_TAG_DEVICE_FIRMWARE_INFO:
            return ("TLD_TAG_DEVICE_FIRMWARE_INFO", TLD_OTAP.parse_device_firmware_info(msg))
        if msg[0] == TLD_OTAP.TLD_TAG_SNIFFER_ERROR:
            return ("TLD_TAG_SNIFFER_ERROR", TLD_OTAP.parse_sniffer_error(msg))

        return None
            
    def parse_otap_start_resp(msg):
        # return updateid
        return {"updateid":int.from_bytes(msg[TLD.TLD_HEADER:TLD.TLD_HEADER+4], byteorder='little'), \
        "framealignment":int(msg[TLD.TLD_HEADER+4]),\
        "rxbuffersize":int(msg[TLD.TLD_HEADER+5]),\
        "accepted":int(msg[TLD.TLD_HEADER+6]),\
        }
        
    def parse_otap_frame_ack(msg):
        id = int.from_bytes(msg[TLD.TLD_HEADER:TLD.TLD_HEADER+4], byteorder='little')
        frameid = int.from_bytes(msg[TLD.TLD_HEADER+4:TLD.TLD_HEADER+8], byteorder='little')
        '''cnt = msg[TLD.TLD_HEADER+4]  #int.from_bytes(msg[8], byteorder='little')
        frameids = []
        for i in range(cnt):
            frameids.append( int.from_bytes(msg[(TLD.TLD_HEADER+5)+(4*i):(TLD.TLD_HEADER+9)+(4*i)], byteorder='little') )
        
        logging.debug("FWUDPATER DEBUG: frame ack, id: " + str(id) + " cnt: " + str(cnt) + " frameids" + str(frameids))
        
        return {"updateid":id, "framecount":cnt, "frameids":frameids }'''
        return {"updateid":id, "frameid":frameid }
        
    def parse_otap_frame_req(msg):
        # hack, it is the same structure
        return TLD_OTAP.parse_otap_frame_ack(msg)
    
    def parse_otap_error(msg):
        id = int.from_bytes(msg[TLD.TLD_HEADER:TLD.TLD_HEADER+4], byteorder='little')
        error  = msg[TLD.TLD_HEADER+4]  #int.from_bytes(msg[8], byteorder='little')
        bl_error = int.from_bytes(msg[TLD.TLD_HEADER+5:TLD.TLD_HEADER+9], byteorder='little')
        
        return {"updateid":id, "error":error, "bl_error":bl_error} 
    
    def parse_otap_end(msg):
        return {"updateid":int.from_bytes(msg[TLD.TLD_HEADER:TLD.TLD_HEADER+4], byteorder='little')}
        
    def parse_device_firmware_info(msg):
        return {"devicetype":int.from_bytes(msg[TLD.TLD_HEADER:TLD.TLD_HEADER+4], byteorder='little'), \
                "fwversion": ' '.join(['{:02X}'.format(c) for c in msg[TLD.TLD_HEADER+4:TLD.TLD_HEADER+8]]), \
                "lastbootreason":int.from_bytes(msg[TLD.TLD_HEADER+8:TLD.TLD_HEADER+12], byteorder='little'), \
                "flashalignment":int(msg[TLD.TLD_HEADER+8]) \
        }

    def parse_sniffer_error(msg):
        return {
            "sequence": msg[TLD.TLD_HEADER],
            "error": msg[TLD.TLD_HEADER+1],
        }

class OTAPException(Exception):
    pass

class YABB330_OTAP:

    # timeout is in seconds..
    def wait_for_otap_tld(self, rxq, timeout=None):
        resp = None
        # wait response
        while(not resp):
            try:
                resp = rxq.get(block=True, timeout=timeout)
            except queue.Empty:
                logging.warning("FW UPDATER: timeout in response")
                return None
            
            logging.debug("FW UPDATER DEBUG: got TLD " + str(resp))
            
            resp = TLD_OTAP.parse_otap_tld(resp[0])
            
            if not resp:
                logging.warning("FW UPDATER: Non OTAP packet received, ignoring")

        return resp

    def update(self, file, comport, bps, updateid=1):
        
        # read as binary
        try: 
            # If the object is already file-like
            if hasattr(file, 'read'):
                fw = file
            else:
                fw = open(file, 'rb')
        except:
            logging.error("FW UPDATER: Error at trying to open the firmware file " + file)
            raise OTAPException("Unable to open file " + file)
        
        txq = queue.Queue()
        rxq = queue.Queue()
        
        try:
            hd = HalfDuplex(txq, rxq, comport, bps, messages=3, tokentimeout=250, debug=False)
            hd.start()
        except:
            logging.error("FW UPDATER: Error at trying to open COM " + str(comport))
            raise OTAPException("Unable to open COM " + str(comport))
        
        # parse fw file
        #fsize = os.path.getsize(args.file)
        
        #frame_count = math.ceil(fsize / TLD.TLD_MAX_PAYLOAD_SIZE)
        frames = []
        # Read (tld max payload size - frame message header size) amount of bytes for each frame
        data = fw.read(TLD_OTAP.FRAME_PAYLOAD_SIZE)
        while data:
            frames.append(data)
            data = fw.read(TLD_OTAP.FRAME_PAYLOAD_SIZE)

        framecount = len(frames)
        
        # check last frame that it has 4 aligned number of bytes
        # in current version, the padding is done by YABB if necessary
        '''if len(frames[-1]) % TLD_OTAP.FRAME_ALIGNMENT != 0 and len(frames[-1]) < TLD_OTAP.FRAME_PAYLOAD_SIZE:
            logging.info("FW UPDATER: Padded final frame with " + str(TLD_OTAP.FRAME_ALIGNMENT - len(frames[-1]) % TLD_OTAP.FRAME_ALIGNMENT) + " of 0xFF byte to ensure even number of bytes on frame")
            frames[-1] += b'\xff' * (TLD_OTAP.FRAME_ALIGNMENT - len(frames[-1]) % TLD_OTAP.FRAME_ALIGNMENT)
        '''   
        logging.info("FW UPDATER: About to send " + str(framecount) + " frames to the YABB")
        logging.info("FW UPDATER: Sending OTAP request")
        print("Starting YABB330 update...")
        
        proceed = False
        sendreq = True
        ack_interval = 0
        while not proceed:
            # start OTAP
            if sendreq:
                txq.put_nowait( TLD_OTAP.get_otap_start_req(updateid, framecount) )
                sendreq = False
            
            logging.info("FW UPDATER: Waiting for YABB OTAP START response")
            
            resp = self.wait_for_otap_tld(rxq)
            
            if(resp[0] == "TLD_TAG_OTAP_START_RESP"):
                if resp[1]["accepted"] == 0x00:
                    # rejected
                    logging.info("FW UPDATER: YABB OTAP response rejected.. on-going OTAP, send cancelling END to enforce and retry")
                    print("Cancelling previous on-going YABB330 update...")
                    txq.put_nowait( TLD_OTAP.get_otap_end(updateid, cancel=True) )
                    logging.info("FW UPDATER: Waiting for OTAP ERROR CANCEL")
                    resp = self.wait_for_otap_tld(rxq)
                    
                    if(resp[0] == "TLD_TAG_OTAP_ERROR" and resp[1]["error"] != 0x00):
                        logging.info("FW UPDATER: YABB responded with OTAP error: " + str(resp[1]["error"]))
                        logging.info("FW UPDATER: Aborting...")
                        raise OTAPException("YABB330 send OTAP error " + str(resp[1]["error"]) + " to OTAP start request")
        
                    elif(resp[0] == "TLD_TAG_OTAP_ERROR" and resp[1]["error"] == 0x00): 
                        print("Cancel done. Retrying update start in 10 seconds...")
                        logging.info("FW UDPATER: Cancel received.. waiting for 10 seconds and retrying start..")
                        time.sleep(10)
                        sendreq = True
                        continue
                        
                    else:
                        logging.info("FW UPDATER: Unknown packet received while waiting for cancel.. ignoring")
                        
                elif resp[1]["accepted"] == 0x01:
                    logging.info("FW UPDATER: YABB OTAP response accepted.. continuing with frames")
                    ack_interval = int(resp[1]["rxbuffersize"])
                    proceed = True
                    break
            
            elif(resp[0] == "TLD_TAG_OTAP_ERROR"):
                logging.info("FW UPDATER: YABB responded with OTAP error: " + str(resp[1]["error"]))
                logging.info("FW UPDATER: Aborting...")
                raise OTAPException("YABB330 send OTAP error " + str(resp[1]["error"]) + " to OTAP start request")
        
            elif(resp[0] == "TLD_TAG_DEVICE_FIRMWARE_INFO"):
                logging.info("FW UDPATER: YABB firmware info - YABB rebooted: " + str(resp[1]["lastbootreason"]))
                print("YABB330 rebooted - expected after cancelling")
                
            else:
                logging.info("FW UPDATER: Unknown packet received while waiting for OTAP START RESP.. ignoring")
        
        # give few seconds of time for  YABB to prepare itself
        time.sleep(10)
        print("Update started")
        
        # send FW pieces
        idx = 0
        end_sent = False
        # proceed is used to implement send one, wait one ack, send next one kind of handshaking for now
        proceed = True
        next_transaction = True
        #for idx in range(framecount):
        while True:
            # 1. make transaction
            # 2. wait for ACK or REQ
            # 3. with ACK, move to next, with REQ, restart from that point
            # 4. if timeout, restart transaction
            if next_transaction and idx < framecount:
                transaction_end_id = idx + ack_interval - 1
                if transaction_end_id >= framecount:
                    transaction_end_id = framecount - 1
                next_transaction = False
                logging.info("FW UPDATER: Transaction from " + str(idx) + " to " + str(transaction_end_id))
            while idx <= transaction_end_id:
                print("Progress: " + str( round((idx+1)/framecount * 100)) + "%", end='\r')
                logging.info("FW UPDATER: Sending frame #" + str(idx) + " of " + str(framecount) + " frames")
                txq.put_nowait( TLD_OTAP.get_otap_frame(updateid, idx, frames[idx]))
                idx = idx + 1
                logging.info("FW UPDATER: Transaction sent")
                if idx == framecount:
                    logging.info("FW UPDATER: Sending end to YABB to indicate all frames sent. YABB can still request frames.")
                    txq.put_nowait( TLD_OTAP.get_otap_end(1) )
                    break
                    
            logging.info("FW UPDATER: waiting for response")
            resp = self.wait_for_otap_tld(rxq, 10)
            
            if not resp:
                if not end_sent:
                    logging.info("FW UPDATER: Timeout. Resending previous transaction")
                    idx = idx - ack_interval
                    continue                  
            elif(resp[0] == "TLD_TAG_OTAP_FRAME_ACK"):
                logging.info("FW UPDATER: Frame acknowledged up to id: #" + str(resp[1]["frameid"]))
                if resp[1]["frameid"] == transaction_end_id:
                    if resp[1]["frameid"] == (framecount - 1):
                        logging.info("FW UPDATER: Last frame acknowledged waiting for end")
                        pass
                    else:
                        logging.info("FW UPDATER: Frame acknowledged up to most recent transaction, moving to next one")
                        next_transaction = True
                continue
            
                
            elif(resp[0] == "TLD_TAG_OTAP_FRAME_REQ"):
                frameid = int(resp[1]["frameid"])
                logging.info("FW UPDATER: YABB requesting frame #" + str(frameid))
                logging.info("FW UPDATER: Reseding frame #" + str(frameid))
                # continue from the requested ID
                idx = frameid
                continue
                # let send happen via normal operation to sync again the transmission
                #txq.put_nowait( TLD_OTAP.get_otap_frame(updateid, frameid, frames[frameid]) )
            
            elif(resp[0] == "TLD_TAG_OTAP_ERROR"):
                logging.info("FW UPDATER: YABB responded with OTAP error: " + str(resp[1]["error"]) + " and BL error " + str(resp[1]["bl_error"]) )
                logging.info("FW UPDATER: Aborting...")
                hd.stop()
                hd.join()
                raise OTAPException("YABB330 send an OTAP error " + str(resp[1]["error"]) + " and BL error " + str(resp[1]["bl_error"]))
                
            # TODO: maybe need a tag for indicating that the frames did end
            elif(resp[0] == "TLD_TAG_OTAP_END"):
                logging.info("FW UPDATER: File successfully transferred, YABB330 shall be rebooting and taking image into use")
                break
                
            else:
                logging.info("FW UPDATER: Unknown packet.. aborting!")
                hd.stop()
                hd.join()
                raise OTAPException("Received unknown packet")

        hd.stop()
        hd.join()
        print("")
        print("Done")
        #sys.exit()

    def testrun(self, otapfile, comport, *ops):
        """Run test operations as a variadic number of string arguments.

Tests the OTAP functionality. An example run could be:

YABB330_OTAP.testrun("filename.otap", "/dev/ttyXYZ", "start()",
        "expect(tldid='start', fields={'accepted': 1})")

Here the OTAP_START is sent and it is expected that START_RESP is sent back
with 'accepted' field as 1.
        """
        import inspect
        import copy
        import ast

        print(otapfile)
        print(comport)
        print(ops)

        defargs = {}
        optable = {}
        self.otapdata = []
        self.otapframes = []

        txq = queue.Queue()
        rxq = queue.Queue()

        # Domain specific language preparation

        def reslice(chunksize=-1):
            if chunksize < 0:
                chunksize = defargs['chunksize']
            self.otapframes = [self.otapdata[i:i+chunksize] for i in
                               range(0, len(self.otapdata), chunksize)]
            defargs['chunksize'] = chunksize
            defargs['framecount'] = len(self.otapframes)
            print("Reslicing the data to {} of {} byte chunks".format(
                defargs['framecount'],
                defargs['chunksize'],
            ))

        def resize(length, chunksize=-1):
            print("Resizing data of length {} to length {}".format(len(self.otapdata), length))
            if length > len(self.otapdata):
                raise OTAPException('Can\'t resize data to larger than {} bytes'.format(len(self.otapdata)))
            self.otapdata = self.otapdata[:length]
            reslice(chunksize)

        def opcreate(name, func):
            optable[name] = {
                'func': func,
                'name': name,
                'args': inspect.getargspec(func).args,
            }

        def opalias(original, alias):
            optable[alias] = copy.deepcopy(optable[original])

        def receive(timeout=5):
            return self.wait_for_otap_tld(rxq, timeout)

        def print_receive(timeout):
            msg = receive(timeout)
            if msg is None:
                raise OTAPException("Expected a response, but got nothing")
            print('Received message:')
            print(msg)

        def receive_many(timeout, count):
            if count < 0:
                count = defargs['framecount']
            for i in range(count):
                print_receive(timeout)

        def sleep(sleeptime):
            print('Sleeping for {} seconds'.format(sleeptime))
            time.sleep(sleeptime)

        def _tld_shorthand(tldid):
            shorthand = {
                'start': 'TLD_TAG_OTAP_START_RESP',
                'ack': 'TLD_TAG_OTAP_FRAME_ACK',
                'req': 'TLD_TAG_OTAP_FRAME_REQ',
                'error': 'TLD_TAG_OTAP_ERROR',
                'sniffer_error': 'TLD_TAG_SNIFFER_ERROR',
                'end': 'TLD_TAG_OTAP_END',
                'firmware_info': 'TLD_TAG_DEVICE_FIRMWARE_INFO',
                'device_info': 'TLD_TAG_DEVICE_INFO',
            }
            if tldid in shorthand:
                tldid = shorthand[tldid]
            return tldid

        def _expect_fields(tldid, msgfields, fields):
            for key in fields:
                if key not in msgfields:
                    raise OTAPException('Expected TLD "{}" to contain field "{}"'.format(
                        tldid, key
                    ))
                if fields[key] != msgfields[key]:
                    raise OTAPException('Expected TLD "{}" field "{}" to contain value "{}" but got "{}"'.format(
                        tldid, key, fields[key], msgfields[key]
                    ))

        def expect(tldid, timeout, fields={}):
            msg = receive(timeout)
            print(msg)
            if not msg:
                if not tldid:
                    return
                raise OTAPException('Expected {} response but got nothing'.format(tldid))

            if not tldid:
                raise OTAPException('Expected no response but got: {}'.format(msg))

            tldid = _tld_shorthand(tldid)

            msgid = msg[0]
            msgfields = msg[1]
            if msgid != tldid:
                raise OTAPException('Expected TLD {} but got {}'.format(tldid, msg[0]))

            _expect_fields(tldid, msgfields, fields)

        def expect_many(group, timeout):
            """Expects a group of TLDs to be received. The individual TLDs
            can arrive in any order.

            The group argument is a dictionary whose keys are the tldids. The
            key is the same as the tldid in the expect function. The value is
            a dictionary that can have the following fields:
            - "count": An integer or a string of the format e.g. "1-5" to
              provide a lower and upper limit of the number of TLDs.
            - "fields": The same as the fields for the expect function.
            """

            def parse_count(count):
                if count.isdigit():
                    return (int(count), int(count))

                return (int(s) for s in count.split('-') if s.isdigit())

            mintlds, maxtlds = 0, 0

            # Remove possible shorthands from the given group
            group = {_tld_shorthand(k): v for (k, v) in group.items()}

            # Calculate number of messages that need to be received
            for key in group:
                mininc, maxinc = 1, 1
                if 'count' in group[key]:
                    mininc, maxinc = parse_count(group[key]['count'])
                mintlds += mininc
                maxtlds += maxinc
                group[key]['limits'] = [mininc, maxinc]

            print('Expecting to receive at least {} and up to {} TLDs'.format(
                mintlds, maxtlds
            ))

            # Receive at least the minimum number of tlds
            msgs = []
            for i in range(maxtlds):
                msg = receive(timeout)
                print(msg)
                if msg is None:
                    break
                msgs.append(msg)

            if len(msgs) < mintlds:
                raise OTAPException('Expected to receive {} TLDs, but got only {}'.format(
                    mintlds, len(msgs)
                ))

            # Count the numbers of found tlds and check the fields
            for msg in msgs:
                msgid = msg[0]
                msgfields = msg[1]

                if msgid not in group:
                    raise OTAPException('Unexpectedly received TLD {}'.format(msgid))

                found = group[msgid].get('found', 0)
                found += 1
                group[msgid]['found'] = found

                _expect_fields(msgid, msgfields, group[msgid].get('fields', {}))

            # verify that enough TLDs have been received
            for key in group:
                found = group[key].get('found', 0)
                limits = group[key]['limits']
                if found < limits[0] or found > limits[1]:
                    limit = limits[0]
                    if limits[0] != limits[1]:
                        limit = "from {} to {}".format(limits[0], limits[1])
                    raise OTAPException('Expected to receive {} TLDs of id {} but received {} TLDs'.format(
                        limit, key, found
                    ))
                # Log the situation where a TLD has arrived and it's expected
                # to have minimum of zero instances.
                if found > 0 and limits[0] == 0:
                    logging.warning("Received {} TLD(s) {} that are only potential (expected 0-{})".format(
                        found, key, limits[1]
                    ))

        def send_single_frame(updateid, frameid, framelen):
            idx = frameid
            if frameid < 0:
                idx = defargs['frameid']
            if framelen < 0:
                framelen = len(self.otapframes[idx])

            msg = TLD_OTAP.get_otap_frame(updateid, idx,
                                          self.otapframes[idx], framelen)
            print('Sending frame {}'.format(idx))
            print(msg)
            txq.put_nowait(msg)
            if frameid < 0:
                idx += 1
                defargs['frameid'] = idx

        def send_many_frames(count=-1, updateid=1):
            if count < 0:
                count = defargs['framecount']

            for i in range(count):
                send_single_frame(updateid, -1, -1)

        def set_frameid(frameid):
            defargs['frameid'] = frameid

        def send_frame_batches(batchsize=64, batchcount=10):
            # The batchsize for the firmware is 8 frames and therefore this
            # should adhere to that
            if batchsize % 8 != 0:
                raise OTAPException('The batchsize ({}) should be multiple of 8'.format(batchsize))
            if batchcount < 0:
                batchcount = (defargs['framecount'] // batchsize) + 1

            print('Number of batches: {}'.format(batchcount))

            for batch in range(batchcount):
                left = defargs['framecount'] - defargs['frameid']
                print('FRAMES LEFT: {}'.format(left))
                if batchsize > left:
                    batchsize = left
                if batchsize == 0:
                    print('Sent all frames!')
                    break

                send_many_frames(batchsize)
                receive_many(2, batchsize // 8)

        def prepare_op(name, kwargs):
            print(name)
            print(kwargs)
            op = optable[name]
            args = {}
            print(op)
            for argname in op['args']:
                if argname in kwargs:
                    args[argname] = kwargs[argname]
                elif argname in defargs:
                    args[argname] = defargs[argname]
                else:
                    raise OTAPException('Argument "{}" not given for op "{}"'.format(
                        argname, name
                    ))

            return {
                'op': op,
                'args': args,
            }

        def run_prepared_op(op):
            print('Calling {}({})'.format(op['op']['name'], op['args']))
            op['op']['func'](**op['args'])

        def send_tld(create):
            def _ret(**kwargs):
                msg = create(**kwargs)
                print("Send the following message")
                print(msg)
                txq.put_nowait(msg)
            return _ret

        for func in [TLD_OTAP.get_otap_start_req, TLD_OTAP.get_otap_frame,
                     TLD_OTAP.get_otap_end, TLD_OTAP.get_device_info_req]:
            optable[func.__name__] = {
                'func': send_tld(func),
                'name': func.__name__,
                'args': inspect.getargspec(func).args,
            }

        opalias('get_otap_start_req', 'start')
        opalias('get_otap_end', 'end')
        opalias('get_device_info_req', 'info_req')

        opcreate('reslice', reslice)
        opcreate('resize', resize)
        opcreate('recv', print_receive)
        opcreate('recv_many', receive_many)
        opcreate('expect', expect)
        opcreate('expect_many', expect_many)
        opcreate('sleep', sleep)
        opcreate('single', send_single_frame)
        opcreate('send_many', send_many_frames)
        opcreate('set_frameid', set_frameid)
        opcreate('send_batches', send_frame_batches)

        # the main functionality
        defargs['chunksize'] = TLD_OTAP.FRAME_PAYLOAD_SIZE
        defargs['updateid'] = 1
        defargs['frameid'] = 0
        defargs['frame'] = []
        defargs['framecount'] = 0
        defargs['framelen'] = -1
        defargs['cancel'] = False
        defargs['timeout'] = 5
        defargs['sleeptime'] = 10

        opargs = []

        # read as binary
        try:
            # If the object is already file-like
            if hasattr(otapfile, 'read'):
                fw = otapfile
            else:
                fw = open(otapfile, 'rb')
        except:
            raise OTAPException("Unable to open file " + otapfile)

        # Read all data
        self.otapdata = fw.read()
        reslice(TLD_OTAP.FRAME_PAYLOAD_SIZE)

        # parse given operation strings in the same syntax as python function calls
        for op in ops:
            call = ast.parse(op).body[0].value
            name = call.func.id
            kwargs = {arg.arg: ast.literal_eval(arg.value) for arg in call.keywords}
            opargs.append(prepare_op(name, kwargs))
        print(opargs)

        # Initialize the serial communication
        try:
            hd = HalfDuplex(txq, rxq, comport, 115200, messages=3, tokentimeout=250, debug=False)
            hd.start()
        except:
            logging.error("FW UPDATER: Error at trying to open COM " + str(comport))
            raise OTAPException("Unable to open COM " + str(comport))

        # Run the given operations
        try:
            for op in opargs:
                run_prepared_op(op)
        finally:
            hd.stop()
            hd.join()


if __name__== "__main__":
    #global runflag
    parser = argparse.ArgumentParser(description='FWUpdater')
    parser.add_argument("-c", "--comport", help="serial port to use")
    parser.add_argument("-b", "--bps", type=int, default=115200, help="serial speed bits-per-second")
    parser.add_argument("-f", "--file",  help="FW file name")
    parser.add_argument("-i", "--id", type=int, default=1, help="Update ID used for the procedure")
    parser.add_argument('-l', '--log', help="Display log data", action='store_true')
    args = parser.parse_args()
    
    yaotap = YABB330_OTAP()
    
    if args.log:
        #logging.basicConfig(level=logging.INFO)
        logging.basicConfig(level=logging.DEBUG)

    try:
        yaotap.update(args.file, args.comport, args.bps, args.id)
    except OTAPException as e:
        sys.exit(str(e))
    
