import collections
from time import gmtime, strftime
import time
import serialdecoder
import math



class TLD:
    """TLD class for handling TLD messages"""

    TLD_TAGS = { \
        "TLD_TAG_GENERIC":0, \
        "TLD_TAG_AUX_TEXT":1, \
        "TLD_TAG_MEASUREMENT_GENERIC":2, \
        "TLD_TAG_MEASUREMENT_BAROMETER":3, \
        "TLD_TAG_MEASUREMENT_RSSI":4, \
        "TLD_TAG_MEASUREMENT_WAVEFORM":5, \
        "TLD_TAG_MEASUREMENT_WAVEFORM_DELTA":6, \
        "TLD_TAG_MEASUREMENT_WAVEFORM_BITS":7, \
        "TLD_TAG_MEASUREMENT_LOGIC_DATA":8, \
        "TLD_TAG_SNIFFER_CMD_CONFIG":9, \
        "TLD_TAG_SNIFFER_ELEVATOR_LANDING_CALL_CMD":10, \
        "TLD_TAG_SNIFFER_MSG_ELEVATOR_SERVICE":11, \
        "TLD_TAG_MEASUREMENT_CAN_BUS":12, \
        "TLD_TAG_SNIFFER_LEDS":13, \
        "TLD_TAG_DEVICE_INFO":14, \
        "TLD_TAG_TOKEN_MASTER_GRANT":15, \
        "TLD_TAG_TOKEN_SLAVE_RETURN":16, \
        "TLD_TAG_ELEVATOR_SERVICE_PORT_CMD":17, \
        "TLD_TAG_ELEVATOR_SERVICE_PORT_MSG":18,\
        "TLD_TAG_DEVICE_INFO_REQ":28, \
        "TLD_TAG_SNIFFER_CAN_TIMINGS":29, \
        "TLD_TAG_ELEVATOR_CONTROLLER_STATUS_QUERY":31, \
        "TLD_TAG_ELEVATOR_CONTROLLER_STATUS_RESPONSE":32, \
    }
    
    TLD_TAGS_BYTES = {v:k for k,v in TLD_TAGS.items()}
    
    TLD_TAG_COMMANDS = [ \
        "TLD_TAG_SNIFFER_CMD_CONFIG", \
        "TLD_TAG_SNIFFER_ELEVATOR_LANDING_CALL_CMD", \
        "TLD_TAG_TOKEN_MASTER_GRANT", \
        "TLD_TAG_ELEVATOR_SERVICE_PORT_CMD", \
        "TLD_TAG_DEVICE_INFO_REQ", \
        "TLD_TAG_SNIFFER_CAN_TIMINGS", \
        "TLD_TAG_SNIFFER_LEDS", \
        "TLD_TAG_ELEVATOR_CONTROLLER_STATUS_QUERY", \
    ]
        
    TLD_TAG_GENERIC = TLD_TAGS["TLD_TAG_GENERIC"]
    TLD_TAG_AUX_TEXT = TLD_TAGS["TLD_TAG_AUX_TEXT"]
    TLD_TAG_MEASUREMENT_GENERIC = TLD_TAGS["TLD_TAG_MEASUREMENT_GENERIC"]
    TLD_TAG_MEASUREMENT_BAROMETER = TLD_TAGS["TLD_TAG_MEASUREMENT_BAROMETER"]
    TLD_TAG_MEASUREMENT_RSSI = TLD_TAGS["TLD_TAG_MEASUREMENT_RSSI"]
    TLD_TAG_MEASUREMENT_WAVEFORM = TLD_TAGS["TLD_TAG_MEASUREMENT_WAVEFORM"]
    TLD_TAG_MEASUREMENT_WAVEFORM_DELTA = TLD_TAGS["TLD_TAG_MEASUREMENT_WAVEFORM_DELTA"]
    TLD_TAG_MEASUREMENT_WAVEFORM_BITS = TLD_TAGS["TLD_TAG_MEASUREMENT_WAVEFORM_BITS"]
    TLD_TAG_MEASUREMENT_LOGIC_DATA = TLD_TAGS["TLD_TAG_MEASUREMENT_LOGIC_DATA"]

    TLD_TAG_SNIFFER_CMD_CONFIG = TLD_TAGS["TLD_TAG_SNIFFER_CMD_CONFIG"]
    TLD_TAG_SNIFFER_ELEVATOR_LANDING_CALL_CMD = TLD_TAGS["TLD_TAG_SNIFFER_ELEVATOR_LANDING_CALL_CMD"]
    TLD_TAG_SNIFFER_MSG_ELEVATOR_SERVICE = TLD_TAGS["TLD_TAG_SNIFFER_MSG_ELEVATOR_SERVICE"]

    TLD_TAG_SNIFFER_LEDS = TLD_TAGS["TLD_TAG_SNIFFER_LEDS"]
    #TLD_TAG_RADIO_CMD_CONFIG_CLIENT = TLD_TAGS["TLD_TAG_RADIO_CMD_CONFIG_CLIENT"]
    #TLD_TAG_RADIO_CMD_CONFIG_SERVER = TLD_TAGS["TLD_TAG_RADIO_CMD_CONFIG_SERVER"]
    
    TLD_TAG_TOKEN_MASTER_GRANT = TLD_TAGS["TLD_TAG_TOKEN_MASTER_GRANT"]
    TLD_TAG_TOKEN_SLAVE_RETURN = TLD_TAGS["TLD_TAG_TOKEN_SLAVE_RETURN"]
    
    TLD_TAG_ELEVATOR_SERVICE_PORT_CMD = TLD_TAGS["TLD_TAG_ELEVATOR_SERVICE_PORT_CMD"]
    TLD_TAG_ELEVATOR_SERVICE_PORT_MSG = TLD_TAGS["TLD_TAG_ELEVATOR_SERVICE_PORT_MSG"]
    
    TLD_TAG_DEVICE_INFO_REQ = TLD_TAGS["TLD_TAG_DEVICE_INFO_REQ"]
    TLD_TAG_SNIFFER_CAN_TIMINGS = TLD_TAGS["TLD_TAG_SNIFFER_CAN_TIMINGS"]
    
    TLD_TAG_ELEVATOR_CONTROLLER_STATUS_QUERY = TLD_TAGS["TLD_TAG_ELEVATOR_CONTROLLER_STATUS_QUERY"]
    
    TLD_TAG_ELEVATOR_CONTROLLER_STATUS_RESPONSE = TLD_TAGS["TLD_TAG_ELEVATOR_CONTROLLER_STATUS_RESPONSE"]
    
    '''TLD_TAG_COMMANDS_DEFAULT_PAYLOAD = { \
        "TLD_TAG_SNIFFER_CMD_CONFIG":[0x01, 0x00], \
        "TLD_TAG_SNIFFER_CMD_ELEVATOR_SERVICE":[0x03, 0x02, 0x01], \
        "TLD_TAG_RADIO_CMD_CONFIG":[0x03], \
        "TLD_TAG_RADIO_CMD_CONFIG_CLIENT":[0x02], \
        "TLD_TAG_RADIO_CMD_CONFIG_SERVER":[0x01], \
    }'''
    
    TLD_TAG_COMMANDS_SNIFFER_CMD_CONFIG_PAYLOADS = { \
        "No activity":[0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00], \
        "Unknown bus - ch1 N and ch2 N + no service port + sensors":[0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01], \
        "Unknown bus - ch1 P and ch2 P + no service port + sensors":[0x01, 0x01, 0x00, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x01, 0x01, 0x00, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01], \
        "Unknown bus - ch1 P and ch2 P inverted high gain + no service port + sensors":[0x01, 0x01, 0x00, 0x00, 0x00, 0x00, 0x02, 0x01, 0x10, 0x01, 0x01, 0x00, 0x00, 0x00, 0x00, 0x02, 0x01, 0x10, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01], \
        "Unknown bus as bits - ch1 N and ch2 N high gain + no service port + sensors":[0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x02, 0x00, 0x10, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x02, 0x00, 0x10, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01], \
        "Unknown bus as bits - ch1 N and ch2 N inverted high gain + no service port + sensors":[0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x02, 0x01, 0x10, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x02, 0x01, 0x10, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01], \
        "Unknown bus as bits - ch1 P and ch2 P inverted high gain + no service port + sensors":[0x04, 0x01, 0x00, 0x00, 0x00, 0x00, 0x02, 0x01, 0x10, 0x04, 0x01, 0x00, 0x00, 0x00, 0x00, 0x02, 0x01, 0x10, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01], \
        "UART - ch1 N and ch2 N + no service port + sensors":[0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01], \
        "UART - ch1 N and ch2 N inverted high gain + no service port + sensors":[0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x02, 0x01, 0x10, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x02, 0x01, 0x10, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01], \
        "UART - ch1 P and ch2 P inverted high gain + no service port + sensors":[0x02, 0x01, 0x00, 0x00, 0x00, 0x00, 0x02, 0x01, 0x10, 0x02, 0x01, 0x00, 0x00, 0x00, 0x00, 0x02, 0x01, 0x10, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01], \
        "CAN -ch1 N and ch2 N + no service port + sensors":[0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01], \
        "CAN -ch1 P and ch2 P and 100kbit and high gain and inverted + no service port + sensors":[0x03, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x10, 0x03, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x10, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01], \
        "CAN -ch1 P and ch2 P and 1mbit and high gain and inverted + no service port + sensors":[0x03, 0x01, 0x40, 0x42, 0x0F, 0x00, 0x00, 0x01, 0x10, 0x03, 0x01, 0x40, 0x42, 0x0F, 0x00, 0x00, 0x01, 0x10, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01], \
        "Service port UART 8N1 + sensors":[0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x01], \
        "Service port RS232 8N1 + sensors":[0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x01], \
        "Service port RS422 8N1 + sensors":[0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x01], \
    }
    
    
    TLD_TAG_COMMANDS_SNIFFER_ELEVATOR_LANDING_CALL_CMD = { \
        "Both relays OFF":[0x00, 0x00], \
        "Both relays ON":[0xFF, 0xFF], \
        "Both relays toggle for 2s":[0xC8, 0xC8], \
    }
    
    
    '''TLD_TAG_COMMANDS_RADIO_CMD_CONFIG = { \
        "Default":[0x02], \
    }
    
    TLD_TAG_COMMANDS_RADIO_CMD_CONFIG_CLIENT = { \
        "Default":[0x03], \
    }
    
    TLD_TAG_COMMANDS_RADIO_CMD_CONFIG_SERVER = { \
        "Default":[0x04], \
    }'''
    
    TLD_TAG_COMMANDS_TOKEN_MASTER_GRANT = { \
        "10 messages, no timeout":[0x01, 0x00, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x00], \
        "10 messages, 1s timeout":[0x01, 0x00, 0x00, 0x00, 0x0A, 0x00, 0xE8, 0x03], \
        "10 messages, 10s timeout":[0x01, 0x00, 0x00, 0x00, 0x0A, 0x00, 0x10, 0x27], \
        "10000 messages, no timeout":[0x01, 0x00, 0x00, 0x00, 0x10, 0x27, 0x00, 0x00], \
    }
    
    TLD_TAG_COMMANDS_ELEVATOR_SERVICE_PORT_CMD = { \
        "Default U, Syntax: data_length (hex), data (hex separate by commas)":[0x01, 0x55], \
    }
    
    TLD_TAG_COMMANDS_DEVICE_INFO_REQ = { \
        "Default all information":[0x00, 0x00, 0x00, 0x00], \
    }
    
    TLD_TAG_COMMANDS_SNIFFER_CAN_TIMINGS = { \
        "Ch, br4, prop2, ph1_2, ph2_2, sj2":[0xFF, 0x00, 0x00, 0x00, 0x00, 0x01, 0x01, 0x02, 0x02, 0x03, 0x03, 0x04, 0x04], \
    }
    
    TLD_TAG_COMMANDS_SNIFFER_LEDS = { \
        "All sig strength off":[0x00], \
        "All sig strength on":[0x1F], \
    }
    
    TLD_TAG_COMMANDS_ELEVATOR_CONTROLLER_STATUS_QUERY = { \
        "Default 1000ms 3 U's":[0xE8, 0x03, 0x00, 0x03, 0x55, 0x55, 0x55], \
    }
    
    TLD_TAG_COMMANDS_CMD_SPECIFIC_PAYLOAD = [ \
        TLD_TAG_COMMANDS_SNIFFER_CMD_CONFIG_PAYLOADS, \
        TLD_TAG_COMMANDS_SNIFFER_ELEVATOR_LANDING_CALL_CMD, \
        TLD_TAG_COMMANDS_TOKEN_MASTER_GRANT, \
        TLD_TAG_COMMANDS_ELEVATOR_SERVICE_PORT_CMD , \
        TLD_TAG_COMMANDS_DEVICE_INFO_REQ, \
        TLD_TAG_COMMANDS_SNIFFER_CAN_TIMINGS, \
        TLD_TAG_COMMANDS_SNIFFER_LEDS, \
        TLD_TAG_COMMANDS_ELEVATOR_CONTROLLER_STATUS_QUERY, \
    ]
    
    TLD_SIZE = 96 
    TLD_HEADER = 5
    TLD_HEADER_SIZE = TLD_HEADER
    TLD_PAYLOAD_SIZE_IDX = 1
    #TLD_MAX_PAYLOAD_SIZE = 128
    #TLD_MAX_PAYLOAD_SIZE = 48
    TLD_MAX_PAYLOAD_SIZE = TLD_SIZE - TLD_HEADER_SIZE
    TLD_HEADER_CRC_IDX = 2
    TLD_HEADER_SEQUENCE_IDX = 4
    
    #WAVEFORM_CAPTURES_IN_MSG = 18
    WAVEFORM_CAPTURES_IN_MSG = 9
    WAVEFORM_HEADER = TLD_HEADER+(1+4+1+1+1+1+2)
    WAVEFORM_CAPS_IN_B = 4
    # wtimer clockspeeds are half of the hf clock speed
    WAVEFORM_CLOCK_SPEED = 36
    WAVEFORM_CLOCK_PRESCALER = 1
    
    def get_tag_byte(tag):
        return TLD.TLD_TAGS[tag]
        
    def get_tag_name(byte):
        return TLD.TLD_TAGS_BYTES[byte]
    
    def measurement_barometer(msg):
        return int.from_bytes(msg[TLD.TLD_HEADER:TLD.TLD_HEADER+4], byteorder='little')
        
    def measurement_barometer_parsed(msg):
        value = TLD.measurement_barometer(msg)
        data = msg[TLD.TLD_HEADER:TLD.TLD_HEADER+4]
        ret_ascii = "Barometer Measurement (Ascii): " + str(value) + " hPa"
        ret_hex = "Barometer Measurement (HEX): " # + str(msg[TLD.TLD_HEADER:TLD.TLD_HEADER+4])
        for d in data:
            ret_hex += "{0:#0{1}x}".format(d,4) + ", "
        return {"hex":ret_hex[:-2], "ascii":ret_ascii}
        
    def measurement_rssi(msg):
        return int.from_bytes(msg[TLD.TLD_HEADER:TLD.TLD_HEADER+4], byteorder='little')
    
    def measurement_waveform_graph_friendly(msg):
        """ *DEPRECATED* Transforms timer capture data into data that can be easily plotted with pyqtgraph """
        
        CAPTURES_IN_MSG = TLD.WAVEFORM_CAPTURES_IN_MSG
        HEADER = TLD.WAVEFORM_HEADER
        CAPS_IN_B = TLD.WAVEFORM_CAPS_IN_B
        TIMER_WIDTH_IN_BITS = int.from_bytes(msg[TLD.TLD_HEADER+1 : TLD.TLD_HEADER+2], byteorder='little') #16
        #print("Timer width: " + str(TIMER_WIDTH_IN_BITS))
        ret_ts = []
        ret_pins = []
        init = False
        timestamps = msg[HEADER:(HEADER+(CAPS_IN_B*CAPTURES_IN_MSG))]
        pins = msg[(HEADER+(CAPS_IN_B*CAPTURES_IN_MSG)):]
        
  
        #print("TS: " + str(timestamps))
        #print("Pins: " + str(pins))
        i = 0
        for n in range(CAPTURES_IN_MSG):
            ts = int.from_bytes(timestamps[n+i:n+i+CAPS_IN_B], byteorder='little')
            i += CAPS_IN_B-1
            
            if not init:
                # add an initial state that was not captured
                t = ts - 1000
                if t < 0:
                    t = 0
                ret_ts.append(t)
                p = 0
                if pins[n] == 0:
                    # the pin state should be the opposite of the 1st captured state
                    p = 1
                ret_pins.append(p)
                init = True

            if ret_ts[-1] > ts:
                # the timestamp is smaller than previous -> roll over
                ts += 2**TIMER_WIDTH_IN_BITS
            if pins[n] == ret_pins[-1]:
                # just store as is
                ret_pins.append(pins[n])
                ret_ts.append(ts)
            else:
                # we need to create waveform, so we will need to add
                # time stamp-1 on previous pin state of this timestamps
                #
                # re add last pin state
                ret_pins.append(ret_pins[-1])
                # add ts - 1
                ret_ts.append(ts-1)
                # add real values
                ret_pins.append(pins[n])
                ret_ts.append(ts)
        #print("RET_TS: " + str(ret_ts))
        #print("RET_Pins: " + str(ret_pins))
        
        # normalize timestamps
        temp = []
        ts1 = ret_ts[0] - 1000
        if ts1 > 0:
            for t in ret_ts:
                temp.append(t-ts1)
            ret_ts = temp
       
        return (ret_ts, ret_pins, TIMER_WIDTH_IN_BITS)
  
    
    def waveform_analysis(msg):
        """ *DEPRECATED* Analyses a timer capture data for baudrate and bits string """
    
        CAPTURES_IN_MSG = TLD.WAVEFORM_CAPTURES_IN_MSG
        HEADER = TLD.WAVEFORM_HEADER
        CAPS_IN_B = TLD.WAVEFORM_CAPS_IN_B
        
        TIMER_WIDTH_IN_BITS = int.from_bytes(msg[TLD.TLD_HEADER+1 : TLD.TLD_HEADER+2], byteorder='little')
        timestamps = msg[HEADER:(HEADER+(CAPS_IN_B*CAPTURES_IN_MSG))]
        ts = []
        pins = msg[(HEADER+(CAPS_IN_B*CAPTURES_IN_MSG)):]
        
        i = 0
        for n in range(CAPTURES_IN_MSG): 
            t = int.from_bytes(timestamps[n+i:n+i+CAPS_IN_B], byteorder='little')
            if len(ts) > 0 and ts[-1] > t:
                # the timestamp is smaller than previous -> roll over
                # increase by adding the max of the timer
                t += 2**TIMER_WIDTH_IN_BITS
            ts.append(t)
            i += CAPS_IN_B-1
        
        # normalize timestamps
        temp = []
        ts1 = ts[0] - 1000
        if ts1 > 0:
            for t in ts:
                temp.append(t-ts1)
            ts = temp
        #print("Timestamps len: " + str(len(ts)) + " - " + str(ts))
        #print("Pins len: " + str(len(pins)) + " - " + str(pins))
        # find smallest gap
        s = len(ts)
        i = 0
        smallest_gap = 2**32
        while( i < s-1 ):
            gap = ts[i+1] - ts[i]
            if gap > 1 and gap < smallest_gap:
                smallest_gap = gap
            i += 1 

        
        bits = 0
        bits_str = ""
        i = 0
        while( i < s-1 ):
            gap = ts[i+1] - ts[i]
            bits_in_gap = round(gap / smallest_gap)
            if pins[i] == 1:
                # truncate very long single bit repetitions
                # 20 is rather good estimation, as very few protocols use over 20 bit static
                # indications except for idle, which we can easily find with help of this truncation
                if bits_in_gap > 20:
                    # keep 10 ones/zeros around the truncation, report correct truncated amount
                    bits_str += "11111..[" + str(bits_in_gap-10) + "]..11111"
                else:
                    bits_str += "1"*bits_in_gap
            else:
                # truncate very long single bit repetitions
                if bits_in_gap > 20:
                    # keep 10 ones/zeros around the truncation, report correct truncated amount
                    bits_str += "00000..[" + str(bits_in_gap-10) + "]..00000"
                else:
                    bits_str += "0"*bits_in_gap
            i += 1
        
        # The HFPERCLK is 20 Mhz for some reason (could be 50 MHz as well with different
        # config
        clock_tick_speed = (1/(TLD.WAVEFORM_CLOCK_SPEED*1000*1000))*TLD.WAVEFORM_CLOCK_PRESCALER
        # one bit takes gap*tick amount of seconds
        bit = smallest_gap * clock_tick_speed
        # baudrate is 1/baud
        baudrate = 1 / bit
        
        return (smallest_gap, baudrate, bits, bits_str)
    
    
    def measurement_waveform_delta_graph_friendly(msg, previous_delta=0, previous_pin=0):
        """ Transforms timer capture delta data into data that can be easily plotted with pyqtgraph and analysis the baudrate and data to bits string. Combines segmented TLD messages into one capture. """
    
        CHANNEL_OFFSET = 0
        TIMER_SPEED_OFFSET = CHANNEL_OFFSET+1
        TIMER_WIDTH_OFFSET = TIMER_SPEED_OFFSET+4
        CAPTURE_ID_OFFSET = TIMER_WIDTH_OFFSET+1
        SEGMENT_OFFSET = CAPTURE_ID_OFFSET+1
        FIRST_STATE_OFFSET = SEGMENT_OFFSET+1
        DELTA_COUNT_OFFSET = FIRST_STATE_OFFSET+1
        DELTAS_OFFSET = DELTA_COUNT_OFFSET+2
    
        HEADER = TLD.WAVEFORM_HEADER
        CAPTURE_IN_BYTES = TLD.WAVEFORM_CAPS_IN_B
        corrupted = False
        continues = False
        payload_size = msg[TLD.TLD_PAYLOAD_SIZE_IDX]
        
        if payload_size != len(msg[TLD.TLD_HEADER:]):
            print("TLD - WAVEFORM DELTAS: payload size does not match, size " + str(payload_size) + " len " + str(len(msg[HEADER:])))
            return None

        WAVEFORM_CLOCK_SPEED = int.from_bytes(msg[TLD.TLD_HEADER+TIMER_SPEED_OFFSET : TLD.TLD_HEADER+TIMER_SPEED_OFFSET+4], byteorder='little')

        TIMER_WIDTH_IN_BITS = int.from_bytes(msg[TLD.TLD_HEADER+TIMER_WIDTH_OFFSET : TLD.TLD_HEADER+TIMER_WIDTH_OFFSET+1], byteorder='little')

        MESSAGES_INCOMING = int.from_bytes(msg[TLD.TLD_HEADER+SEGMENT_OFFSET : TLD.TLD_HEADER+SEGMENT_OFFSET+1], byteorder='little')
        print("TLD - WAVEFORM DELTAS: incoming msg " + str(MESSAGES_INCOMING+1))
        if MESSAGES_INCOMING > 0:
            continues = True

        CAPTURES_IN_MSG = int.from_bytes(msg[TLD.TLD_HEADER+DELTA_COUNT_OFFSET : TLD.TLD_HEADER+DELTA_COUNT_OFFSET+2], byteorder='little')
        print("TLD - WAVEFORM DELTAS: captures " + str(CAPTURES_IN_MSG))

        first_state = int.from_bytes(msg[TLD.TLD_HEADER+FIRST_STATE_OFFSET : TLD.TLD_HEADER+FIRST_STATE_OFFSET+1], byteorder='little')
        deltas = msg[HEADER:(HEADER+(CAPTURE_IN_BYTES*CAPTURES_IN_MSG))]
        #pins = msg[(HEADER+(CAPTURE_IN_BYTES*CAPTURES_IN_MSG)):]
        # to use previous code with new message format, generate pins from the first state
        pins = []
        for i in range(CAPTURES_IN_MSG):
            if (i + 1) % 2  == 0:
                pins.append(first_state^1)
            else:
                pins.append(first_state)
            

        if (len(deltas)/CAPTURE_IN_BYTES) != len(pins):
            print("TLD - WAVEFORM DELTAS: amount of timestamps and pin statuses do not match - deltas " + str(len(deltas)) + " pins " + str(len(pins)) )
            return None

        
        for idx, p in enumerate(pins):
            # if we found two or more consequetive '1' or '0', the capture has corrupted
            if idx > 0:
                if p == pins[idx-1]:
                    corrupted = True
        
        # transform deltas from bytes to words
        ts = []
        i = 0
        for n in range(CAPTURES_IN_MSG): 
            t = int.from_bytes(deltas[n+i:n+i+CAPTURE_IN_BYTES], byteorder='little')
            ts.append(t)
            i += CAPTURE_IN_BYTES-1
        
        deltas = ts
        
        # construct the graph, continue from previous, if such existed
        graph_x = [previous_delta]
        graph_y = [previous_pin]
        graph_idx = 0
        pins_idx = 0
        if previous_delta == 0:
            # starting a new capture, add idle padding and start from time 0 with idle state of 100
            #graph_x = [0, deltas[0]-1, deltas[0]]
            graph_x = [0, 99, 100]
            graph_y = [~pins[0] & 0x1, ~pins[0] & 0x1, pins[0]]
            graph_idx = 2
        pins_idx = 0
        for d in deltas:
            # set the next draw point on 
            y_point_1 = graph_x[graph_idx] + d
            y_point_2 = y_point_1 - 1
            graph_x.append(y_point_2)
            graph_x.append(y_point_1)
            graph_y.append(pins[pins_idx])
            graph_y.append((~pins[pins_idx] & 0x1))
            graph_idx += 2
            pins_idx += 1
            
        if not continues:
            # add extension to the last one
            graph_x.append(graph_x[-1]+1000)
            graph_y.append(graph_y[-1])
        
        # calculate baudrate
        smallest_gap = min(deltas)
        
        # The HFPERCLK is 20 Mhz for some reason (could be 50 MHz as well with different
        # config
        clock_tick_speed = (1/(TLD.WAVEFORM_CLOCK_SPEED*1000*1000))*TLD.WAVEFORM_CLOCK_PRESCALER
        # one bit takes gap*tick amount of seconds
        bit = smallest_gap * clock_tick_speed
        # baudrate is 1/baud
        baudrate = 1 / bit
        
        bits_str = ""
        # For now, remove padding in front - it does not work correctly, 
        # if the idle level is recorded due e.g. opening the device in other end
        #if previous_delta == 0:
            # a new capture
            # make the bitstring analysis, start by padding with presumed idle level
            # this is safe assumption, as the capture will not have a delta, unless
            # there's a change to this level
        #    bits_str = str(~pins[0] & 0x1)*3
        
        i = 0
        for d in deltas:
            bits_in_delta = d / smallest_gap
            # this adds tolerance for rounding, as states are not always held the whole bit length
            # and in long single bit sequences this might cause misinterpretation if only floored/rounded
            if (bits_in_delta - math.floor(bits_in_delta)) > 0.6:
                # e.g. 3.7 - 3 = 0.7 -> close to 4 round
                # 3.6 - 3 = 0.6
                bits_in_delta = round(bits_in_delta)
            else:
                bits_in_delta = math.floor(bits_in_delta)
            #bits_in_delta = math.floor(d / smallest_gap)
            if pins[i] == 1:
                # truncate very long single bit repetitions
                # 20 is rather good estimation, as very few protocols use over 20 bit static
                # indications except for idle, which we can easily find with help of this truncation
                if bits_in_delta > 20:
                    # keep 10 ones/zeros around the truncation, report correct truncated amount
                    bits_str += "11111..[" + str(bits_in_delta-10) + "]..11111"
                else:
                    bits_str += "1"*bits_in_delta
            else:
                # truncate very long single bit repetitions
                if bits_in_delta > 20:
                    # keep 10 ones/zeros around the truncation, report correct truncated amount
                    bits_str += "00000..[" + str(bits_in_delta-10) + "]..00000"
                else:
                    bits_str += "0"*bits_in_delta
            i += 1
        if not continues:
            # add padding to the end with inversion of the last bit
            # this is safe assumption, as there won't be record of the last
            # bits, unless there's level change
            # if it happens so that the final payload bit is same as stop bit
            # they will just have duration of 2 bit durations
            bits_str += str(~pins[-1] & 0x1)*3

        return (TIMER_WIDTH_IN_BITS, CAPTURES_IN_MSG, (graph_x, graph_y), baudrate, bits_str, continues, corrupted )
    
    
    def measurement_logic_data_parsed(msg):
        #count = msg[TLD.TLD_PAYLOAD_SIZE_IDX]
        #data = msg[TLD.TLD_HEADER:]
        count = msg[TLD.TLD_HEADER+1]
        data = msg[TLD.TLD_HEADER+2:]
        ret_hex = "Logic Data (HEX): "
        ret_ascii = "Logic Data (Ascii) Channel " + str(msg[TLD.TLD_HEADER] + 1) + " :"
        for d in data:
            ret_hex += "{0:#0{1}x}".format(d,4) + ", "
            ret_ascii += " '" + chr(d) + "'"
        # TODO: once the actual TLD structure is determined, update this
        return {"hex":ret_hex[:-2], "ascii":ret_ascii}
    
    def measurement_waveform_bits_parsing(msg):
        ch = msg[TLD.TLD_HEADER]
        cnt = msg[TLD.TLD_HEADER+1]
        final_byte_bit_cnt = int(msg[TLD.TLD_HEADER+2])
        data = msg[TLD.TLD_HEADER+3:]
        bits = TLD.waveform_bits_to_str(data, final_byte_bit_cnt)
        return {"hex":"Waveform bits (hex): NA", "ascii":("Waveform bits (Ascii) Channel " + str(ch+1) + ": " + bits)}

    def waveform_bits_to_str(byte_array, final_byte_bit_cnt):
        # this is the "Python" way to interpret waveform bits data
        bits = ""
        for b in byte_array:
            # translate to binary, and then revererse the string
            bits += '{:08b}'.format(b)[::-1]
        # remove the don't care bits from the end
        return bits[:-(8 - final_byte_bit_cnt)]        

        
    def waveform_bits_to_str_example(byte_array, final_byte_bit_cnt):
        # this is the "generic" way to interpret waveform bits data
        bits = ""
        cnt = 8 * len(byte_array) - (8 - final_byte_bit_cnt)
        for b in byte_array:
            for i in range(0, 8):
                bits += str( b & 0x01 )
                b >>= 1
                cnt -= 1
                if cnt == 0:
                    # this should only happen on the very last byte and last significant bit
                    return bits
        
        return bits

    def get_tld_msg(tag, payload, sequence=0):
        """ returns a valid TLD message as array of integers with given tag and payload """
        
        crc = TLD.CRC_calc(payload)
        return ([tag, len(payload), crc & 0xFF, (crc >> 8) & 0xFF, sequence] + payload)
    
    
    def check_CRC(msg):
        data = msg[TLD.TLD_HEADER:]
        crc = TLD.CRC_calc(data)
        msg_crc = int.from_bytes(msg[TLD.TLD_HEADER_CRC_IDX:TLD.TLD_HEADER_CRC_IDX+2], byteorder='little' )
        #print( "CRC: " + str(crc) + " MSG CRC: " + str(msg_crc))
        if( crc != msg_crc ):
            return False
        return True
    
    @staticmethod
    def CRC_calc(body):
        crc = 0;
        for data in body:
            crc  = (crc >> 8) | (crc << 8);
            crc ^= data & 0xff;
            crc ^= (crc & 0xff) >> 4;
            crc ^= crc << 12;
            crc ^= (crc & 0xff) << 5;
            crc  = crc & 0xffff
        return crc    
        
        
        
        
  
