import serial
import queue
import threading
from tldsl import TLD_SL
from tld import TLD
import time
import sys

class HalfDuplex (threading.Thread):

    def __init__(self, txq, rxq, com, baudrate, messages=10, tokentimeout=10000, debug=True):
        threading.Thread.__init__(self)
        self.txq = txq
        self.rxq = rxq
        self.com = com
        self.baudrate = baudrate
        self.ser = None
        self.runflag = True
        self.messages = messages
        self.tokentimeout = tokentimeout
        self.debug_on = debug
        self.error_rate = 0
        self.tx_count = 0
        self.error_count = 0
        self.timeout = False

    def debug(self, s):
        if self.debug_on:
            print(s)
        
    def stop(self):
        self.runflag = False
        
    def run(self):
        # send stuff from txq
        # grant token
        # put stuff in rxq until release 
        
        #self.ser = serial.Serial(self.com, self.baudrate, timeout=(self.tokentimeout*10)/1000)
        self.ser = serial.Serial(self.com, self.baudrate, timeout=(self.tokentimeout*3)/1000)
        self.debug("HALFD: serial coms open in port " + str(self.com))
        
        while self.runflag:
        
            self.debug("HALFD: Sending..")
            # only send after successful token release because otherwise the message may get lost
            while not self.timeout and not self.txq.empty():
                msg = None
                try:
                    msg = self.txq.get(block=False, timeout=1)
                except queue.Empty:
                    # ignore, just timeout 
                    pass
                if msg is not None:
                    tx = TLD_SL.sl_encode(msg)
                    self.debug("HALFD: serialTX: " + str(tx))
                    try:
                        self.ser.write(tx)
                    except:
                        self.debug("HALFD: Serial Error.. Aborting")
                        #sys.exit()
                        return
        
            self.debug("HALFD: Token grant")
            # grant token, 10 messages, 10s timeout
            payload = [1,0,0,0] + list( self.messages.to_bytes(2, byteorder='little') ) + list( self.tokentimeout.to_bytes(2, byteorder='little')  ) #[1, 0, 0, 0, 10, 0, 16, 39]
            msg = TLD.get_tld_msg(TLD.TLD_TAG_TOKEN_MASTER_GRANT, payload, sequence=69)
            #msg = [15, 8, 142, 120, 1, 0, 0, 0, 10, 0, 16, 39]
            # 10 messages, 1s timeout
            #msg = [15, 8, 0, 134, 1, 0, 0, 0, 10, 0, 232, 3]
            
            tx = TLD_SL.sl_encode(msg)
            self.debug("HALFD: serialTX: " + str(tx))
            try:
                self.ser.write(tx)
            except:
                self.debug("HALFD: Serial Error.. Aborting")
                #sys.exit()
                return

            self.debug("HALFD: Receiving..")
            # receive
            try:
                self.rx()
            except:
                self.debug("HALFD: Serial Error.. Aborting")
                #sys.exit() 
                return
            
        self.ser.close()

            
    def rx(self):
        #tx_count = 0
        #error_count = 0
        line = 20
        msg = []
        start = False
        ongoing = False
    
        tokenrelease = False
        # TODO: how about timeout ?
        while not tokenrelease and self.runflag:
            b = self.ser.read(1)
            '''if b:
                print(str(b.hex()) + " ", end='', flush=True)
                # stupid hack to force command line printing
                line -= 1
                if line == 0:
                    print(" ", flush=True)
                    line = 20
            else:
                self.debug("HALFD: token or serial timeout")
                return'''
            if not b:
                self.debug("HALFD: token or serial timeout")
                self.timeout = True
                return
            i = int.from_bytes(b, "big", signed=False)
            if b and TLD_SL.is_separation(i) and not start:
                msg.append(i)
                start = True
                #self.debug("HALFD: TLD Start found")
            if b and start and not TLD_SL.is_separation(i):
                ongoing = True
                msg.append(i)
                #self.debug("HALFD: TLD byte")
            if b and ongoing and TLD_SL.is_separation(i):
                msg.append(i)
                start = False
                ongoing = False
                self.debug(" ")
                self.debug("HALFD: Found a TLD message " + str(msg))
                msg = TLD_SL.sl_decode(msg)
                self.debug("HALFD: Decoded TLD message " + str(msg))
                
                self.tx_count += 1
                
                if TLD.check_CRC(msg):
                    self.debug("HALFD: CRC correct")
                    if msg[0] == 0x10:
                        self.debug("HALFD: Token release")
                        tokenrelease = True
                        self.timeout = False
                    else: 
                        ts = time.time()
                        self.rxq.put_nowait((msg, ts))
                else:
                    self.error_count += 1
                    self.error_rate = (self.error_count / self.tx_count)*100
                    self.debug("HALFD: CRC mismatch, but continue. TLD packet error rate: " + str(self.error_rate) + "%" )
                    # despite CRC mismatch, react to token release TLD (the CRC is not over the tag..)
                    # TODO: this might be a problem... timeout should resolve it however.. implement timeout!
                    if msg[0] == 0x10:
                        self.debug("HALFD: Token release on CRC errored message!")
                        tokenrelease = True
                        self.timeout = False

                
                #if msg[0] == 0x10:
                #    tokenrelease = True
                #else: 
                #    self.rxq.put_nowait((msg, ts))
                msg = []
                
    def get_error_count(self):
        return self.error_rate