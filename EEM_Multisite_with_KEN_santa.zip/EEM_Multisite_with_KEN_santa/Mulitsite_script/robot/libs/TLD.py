import unittest
import itertools as it
import re
import logging


class TLD:

    START_BYTE = 0xC0
    ESC_BYTE = 0xDB
    ESC_START_BYTE = 0xDC
    ESC_ESC_BYTE = 0xDD

    def to_hex(self, string):
        return " ".join([hex(ord(c))[2:] for c in string]).upper()

    def to_hexstring(self, array, delimiter=' '):
        return delimiter.join(['{:02X}'.format(c) for c in array])

    # Function required for RobotTest framework where "everything" is a string
    def construct_message_from_strings(self, tag_str, seq_num_str, payload_str, spacing=False, escaping=True):

        # tag must be something like 03 or 05 or 1A
        assert(len(tag_str) is 2)
        # payload must be such as 0106CDFF, explicit hex pairs.
        assert(len(payload_str) % 2 == 0)

        # print(payload_str)
        payload = bytes.fromhex(payload_str)
        payload = list(payload)
        # print(payload)

        res = self.construct_message(
            int(tag_str, 16), payload, int(seq_num_str, 16), escaping=escaping)

        res_str = str(bytes(res).hex())

        if spacing:
            res_str = ' '.join(
                [i+j for i, j in zip(res_str[::2], res_str[1::2])])

        # from C0dfE1 to c0dfe1, all lowercase
        res_str = res_str.lower()
        # print(res_str)

        return res_str

    # sl_encode/sl_decode adapted from
    # https://scm.kone.com/kone/projects/maintenance_development/repositories/sniffer/tree/dev?path=tools%2Fsnifferlogger%2Ftldsl.py
    def construct_message(self, tag, payload, seq_num=0, escaping=True):
        assert(isinstance(payload, list))
        """Construct a valid `tag` type TLD message with given payload"""
        crc = self.calculate_crc(payload)
        ret = [tag, len(payload), crc & 0xFF, (crc >> 8) & 0xFF, seq_num] + payload
        if escaping:
            ret = self.sl_encode(ret)
        return ret

    def calculate_crc(self, payload):
        crc = 0
        for data in payload:
            crc = (crc >> 8) | (crc << 8)
            crc ^= data & 0xff
            crc ^= (crc & 0xff) >> 4
            crc ^= crc << 12
            crc ^= (crc & 0xff) << 5
            crc = crc & 0xffff
        return crc

    def is_separation(self, byte):
        if byte == TLD.START_BYTE:
            return True
        else:
            return False

    def sl_encode(self, msg):
        outmsg = []
        outmsg.append(TLD.START_BYTE)
        for b in msg:
            if b == TLD.START_BYTE:
                outmsg.append(TLD.ESC_BYTE)
                outmsg.append(TLD.ESC_START_BYTE)
            elif b == TLD.ESC_BYTE:
                outmsg.append(TLD.ESC_BYTE)
                outmsg.append(TLD.ESC_ESC_BYTE)
            else:
                outmsg.append(b)
        outmsg.append(TLD.START_BYTE)
        return outmsg

    def sl_decode(self, msg):
        l = 0
        outmsg = []
        while l < len(msg):
            if msg[l] == TLD.START_BYTE:
                l += 1
                continue
            elif msg[l] == TLD.ESC_BYTE:
                if msg[l+1] == TLD.ESC_START_BYTE:
                    outmsg.append(TLD.START_BYTE)
                elif msg[l+1] == TLD.ESC_ESC_BYTE:
                    outmsg.append(TLD.ESC_BYTE)
                else:
                    raise ValueError("esc byte was followed by non esc_* byte")
                l += 2
            else:
                outmsg.append(msg[l])
                l += 1
        return outmsg

    def split_to_messages(self, content):
        """
        Split string-formatted sequence of TLD messages to a list of
        TLD messages, each represented as a list of integers (bytes).

        Alternatively if the content is already a list, it is assumed to be already
        split but in hex format.
        """

        if isinstance(content, list):
            for msg in content:
                msg = self.condense_message_data(msg)
                yield bytes.fromhex(msg)
            return

        content = self.condense_message_data(content)

        # Make sure the bytes are space separated
        content = ' '.join(content[i:i+2] for i in range(0, len(content), 2))

        # The messages are the non-empty data between 'c0' strings
        msgs = [self.condense_message_data(m) for m in content.split('c0')]

        if len(msgs) == 0:
            return

        if msgs[0] != '':
            logging.warning('Extra bytes before first message: {}'.format(msgs[0]))
            msgs = msgs[1:]
        if len(msgs) > 0 and msgs[-1] != '':
            logging.warning('Extra bytes after last message: {}'.format(msgs[-1]))

        # Remove the empty fields in the messages list
        msgs = list(filter(None, msgs))

        for m in msgs:
            yield self.sl_decode([
                int(m[i:i+2], base=16) for i in range(0, len(m), 2)
            ])

    def convert_unescaped_message(self, content):
        """
        Convert a string message without escape characters to an array.
        """
        content = self.condense_message_data(content)
        return bytes.fromhex(content)

    def enums(*seq):
        return dict(zip(seq, range(len(seq))))

    # Taken from sniffer/tld/include/tld_msg.h
    TLD_TAGS = enums(
        # TODO remove this when the proper TLD tag handling is implemented
        'TLD_TAG_GENERIC',
        'TLD_TAG_AUX_TEXT',

        'TLD_TAG_MEASUREMENT_GENERIC',
        'TLD_TAG_MEASUREMENT_BAROMETER',
        'TLD_TAG_MEASUREMENT_RSSI',
        'TLD_TAG_MEASUREMENT_WAVEFORM',
        'TLD_TAG_MEASUREMENT_WAVEFORM_DELTA',
        'TLD_TAG_MEASUREMENT_WAVEFORM_BITS',
        'TLD_TAG_MEASUREMENT_LOGIC_DATA',

        'TLD_TAG_SNIFFER_CMD_CONFIG',
        'TLD_TAG_SNIFFER_ELEVATOR_LANDING_CALL_CMD',
        'TLD_TAG_RESERVED1',

        'TLD_TAG_MEASUREMENT_CAN_BUS',

        'TLD_TAG_SNIFFER_LEDS',

        'TLD_TAG_DEVICE_INFO',

        'TLD_TAG_TOKEN_MASTER_GRANT',
        'TLD_TAG_TOKEN_SLAVE_RETURN',

        'TLD_TAG_ELEVATOR_SERVICE_PORT_CMD',
        'TLD_TAG_ELEVATOR_SERVICE_PORT_MSG',

        'TLD_TAG_OTAP_START_REQ',
        'TLD_TAG_OTAP_START_RESP',
        'TLD_TAG_OTAP_FRAME',
        'TLD_TAG_OTAP_FRAME_ACK',
        'TLD_TAG_OTAP_FRAME_REQ',
        'TLD_TAG_OTAP_ERROR',
        'TLD_TAG_OTAP_END',

        'TLD_TAG_DEVICE_FIRMWARE_INFO',

        'TLD_TAG_SNIFFER_DONE',

        'TLD_TAG_DEVICE_INFO_REQ',
        'TLD_TAG_SNIFFER_CAN_TIMINGS',

        'TLD_TAG_SNIFFER_ERROR',

        'TLD_TAG_ELEVATOR_CONTROLLER_STATUS_QUERY',
        'TLD_TAG_ELEVATOR_CONTROLLER_STATUS_RESPONSE',

        'TLD_TAG_SNIFFER_UNKNOWN_BUS_COMPENSATION',
        'TLD_TAG_SNIFFER_UNKNOWN_BUS_COMPENSATION_COMPLETE',

        'TLD_TAG_LOG_INFO',
        'TLD_TAG_LOG_DEBUG',
        'TLD_TAG_LOG_WARNING',
        'TLD_TAG_LOG_ERROR',
    )

    TLD_TAGS_REVERSE = {v: k for k, v in TLD_TAGS.items()}

    def message_as_string(self, arraydata):
        tag = arraydata[0:1]
        length = arraydata[1:2]
        crc = arraydata[2:4]
        sequence = arraydata[4:5]
        payload = arraydata[5:]

        def hs(d):
            return self.to_hexstring(d)

        def showcrc(crc, payload):
            calccrc = self.calculate_crc(payload)
            calccrc = [calccrc & 0xFF, (calccrc >> 8) & 0xFF]
            calccrc = hs(calccrc)
            crc = hs(crc)
            status = 'OK'
            if calccrc != crc:
                status = 'FAIL'
                logging.warning('CRC failure on TLD: {}'.format(
                    self.to_hexstring(arraydata),
                ))
            return 'Given: {} Calculated: {} Status: {}'.format(
                crc,
                calccrc,
                status
            )

        def showtag(tag):
            return 'Hex: {} Dec: {} Name: {}'.format(
                hs(tag),
                tag[0],
                self.TLD_TAGS_REVERSE[tag[0]]
            )

        return 'Raw data: {}\n'.format(self.to_hexstring(arraydata)) + \
            'Tag: ({}), Length: {}, Crc: ({}), Sequence: {}, Payload: {}\n'.format(
                showtag(tag),
                hs(length),
                showcrc(crc, payload),
                hs(sequence),
                hs(payload),
            )

    def print_message(self, arraydata):
        print(self.message_as_string(arraydata))

    def condense_message_data(self, msgstring):
        return msgstring.lower().replace(' ', '')

    def print_all_messages(self, msgstring):
        msgs = list(self.split_to_messages(msgstring))
        print("Count of messages: {}".format(len(msgs)))
        for m in msgs:
            self.print_message(m)

    def is_waveform_delta_message(self, message):
        return message[0] == 0x06

    def is_waveform_bits_message(self, message):
        return message[0] == 0x07

    def is_message(self, tag, message):
        return message[0] == self.TLD_TAGS[tag]

    def code(self, tag):
        # If the tag is given as a number, just return it.
        # This allows for invalid TLD IDs to be checked.
        if tag.isdigit():
            return '{:02x}'.format(int(tag))
        return '{:02x}'.format(self.TLD_TAGS[tag])

    def filter_given_messages(self, tag, msgstring):
        msgs = list(self.split_to_messages(msgstring))
        return [m for m in msgs if self.is_message(tag, m)]

    def contains_message(self, tag, msgstring):
        msgs = list(self.split_to_messages(msgstring))
        for m in msgs:
            if self.is_message(tag, m):
                return
        raise ValueError('given message data does not contain tag {}'.format(tag))

    def _to_bytes(self, number, length=4):
        return (int(number) & 0xFFFFFFFF).to_bytes(length, byteorder='little')

    def create_sniffer_cmd_config(self, ch1, ch2='', service='', sensors=''):
        def split_list(lst):
            return re.split(r'\s*,\s*', lst)

        serial_config_values = {
            'off': 0x00,
            '7n1': 0x01,
            '8n1': 0x02,
            '7o1': 0x03,
            '8o1': 0x04,
            '7e1': 0x05,
            '8e1': 0x06,
            '7n2': 0x07,
            '8n2': 0x08,
            '7o2': 0x09,
            '8o2': 0x0a,
            '7e2': 0x0b,
            '8e2': 0x0c,
        }

        def parse_channel_config(chdata):
            type_values = {
                'no': 0,
                'unknown': 1,
                'uart': 2,
                'can': 3,
                'unknown_bits': 4
            }
            polarity_values = {
                'n': 0,
                'p': 1,
            }
            inverted_values = {
                '': 0,
                'inverted': 1,
            }

            fields = split_list(chdata.lower())
            return [
                type_values[fields[0]],
                polarity_values[fields[1]],
                *self._to_bytes(int(fields[2])),
                serial_config_values[fields[3]],
                inverted_values[fields[4]],
                int(fields[5]) & 0xFF,
            ]

        def parse_service_config(srvdata):
            type_values = {
                'off': 0x00,
                'uart': 0x01,
                'rs232': 0x02,
                'rs422': 0x03,
                'rs485_full_duplex': 0x04,
                'rs485_half_duplex': 0x05,
                'can': 0x06,
                'rs422_low_speed': 0x07,
                'rs485_full_duplex_low_speed': 0x08,
                'rs485_half_duplex_low_speed': 0x09,
            }
            flow_values = {
                '': 0,
            }
            option_values = {
                '': 0,
                'thyssen_break': 1,
            }

            fields = split_list(srvdata.lower())
            return [
                type_values[fields[0]],
                *self._to_bytes(int(fields[1])),
                serial_config_values[fields[2]],
                flow_values[fields[3]],
                option_values[fields[4]],
            ]

        sensor_values = {
            '': 0,
            'sensors': 1,
        }

        # if channel2 configuration is not given, use the same as for channel1
        if ch2 == '':
            ch2 = ch1

        # If service configuration is not given, disable it
        if service == '':
            service = 'off,0,off,,,'

        return [
            *parse_channel_config(ch1),
            *parse_channel_config(ch2),
            *parse_service_config(service),
            sensor_values[sensors],
        ]

    def create_token_master_grant(self, tokenid, count, expiration):
        return [
            *self._to_bytes(tokenid, 4),
            *self._to_bytes(count, 2),
            *self._to_bytes(expiration, 2),
        ]

    def create_device_info_req(self, info):
        return [
            *self._to_bytes(info, 4),
        ]

    def create_sniffer_can_timings(self, channel, bitrate, propagation, phase1,
                                   phase2, sync_jump):
        return [
            *self._to_bytes(channel, 1),
            *self._to_bytes(bitrate, 4),
            *self._to_bytes(propagation, 2),
            *self._to_bytes(phase1, 2),
            *self._to_bytes(phase2, 2),
            *self._to_bytes(sync_jump, 2),
        ]

    def create_unknown_bus_compensation(self, ch1, ch2=''):
        def split_list(lst):
            return re.split(r'\s*,\s*', lst)

        def parse_compensation(chan):
            fields = split_list(chan.lower())

            return [
                *self._to_bytes(fields[0], 1),
                *self._to_bytes(fields[1], 1),
                *self._to_bytes(fields[2], 2),
            ]

        if ch2 == '':
            ch2 = ch1

        return [
            *parse_compensation(ch1),
            *parse_compensation(ch2),
        ]

    def create_elevator_service_port_cmd(self, command):
        payload = bytes.fromhex(command)
        payload = list(payload)
        return [
            *self._to_bytes(len(payload), 1),
            *payload,
        ]

    def create_raw_tld_payload(self, *fields):
        """Create a tld contents with a list of value-length pairs."""

        ret = []
        for i in range(0, len(fields), 2):
            ret.extend(self._to_bytes(int(fields[i]), int(fields[i+1])))
        return ret

class TestTLD(unittest.TestCase):
    test_data = (
        "c0067fc9a1020000512502200002011d004a010000b20300002f01000042010000a00300004101000030010000420100002f010000420100002f0100007a02000068020000420100002f01000042010000680200007a020000a00300004201000030010000b20300002f01000042010000a1030000410100"
        "00300100004101000030010000c0c0067f720c030000512502200001001d00b3030000680200007a0200002f0100007a020000300100007a020000680200007a0200002f01000042010000680200007a020000680200007a02000030010000b20300003001000042010000670200007b0200002f01000042"
        "0100002f0100004201000068020000eb0400002f0100007b020000c0c0061f12300400005125022000000105002f010000420100002f010000ec04000022500000c0"
        "c0067f2666050000512502200102011d004b010000b10300002f01000042010000a00300004101000030010000410100002f010000420100002f0100007a02000067020000420100003001000042010000690200007b020000a0030000420100002f010000b20300003001000041010000a2030000420100"
        "002f0100004201000030010000c0c0067f01ab060000512502200101001d00b3030000680200007b020000300100007c0200002f0100007c020000690200007c02000030010000420100006a0200007c020000690200007c0200002f010000b50300003001000043010000690200007c0200003001000042"
        "01000030010000420100006a020000ee040000300100007c020000c0c0061f0856070000512502200100010500300100004201000030010000ee04000094500000c0"
        "c0067fc60c080000512502200202011d004b010000ea0400002f0100004201000067020000420100002f010000420100002f010000420100002f0100007a02000067020000420100002f010000b3030000670200004101000067020000410100002e010000410100006802000079020000a0030000420100"
        "002f010000420100002f010000c0c0067f2034090000512502200201001d007a0200002f0100004101000068020000410100002f0100007a020000a00300004201000067020000420100002f0100004101000068020000420100002f0100004101000068020000410100002f010000420100002f0100007a"
        "0200002f0100004201000067020000420100002f01000041010000c0c006378e4e0a0000512502200200010b00300100004101000068020000ea040000300100007a0200002f010000410100002f010000eb0400008b500000c0"
        "c0067fe1dbdd0b0000512502200302011d00be0e0000b63a0000a00e0000ae0e0000411d0000ae0e00009c0e0000ae0e00009d0e0000ae0e00009c0e0000541d0000421d0000af0e00009c0e0000fb2b0000411d0000ae0e0000411d0000b40e0000a10e0000b30e0000541d0000621d0000f52b0000b40e"
        "0000a20e0000b30e0000a30e0000c0c0067ff3a60c0000512502200301001d005e1d0000a20e0000b40e00004d1d0000b20e00009e0e0000561d0000ec2b0000b20e0000481d0000b00e0000a00e0000b10e0000401d0000aa0e0000920e0000ac0e0000431d0000ad0e00009c0e0000ad0e00009b0e0000"
        "511d00009b0e0000b20e00004c1d0000b40e0000a20e0000b40e0000c0c0063fb27a0d0000512502200300010d00a30e0000b30e00004d1d0000b33a0000a20e0000601d0000a30e0000b50e0000a30e0000b33a0000ad5f00004100000075000000c0"
    )

    def setUp(self):
        self.tld = TLD()

    def test_construct_message(self):
        encoded_message = self.tld.construct_message(
            0x05,
            [0xc0, 0x12]
        )

        # [0xc0, tag, payload length, crc, crc, sequence number, escaped payload, 0xc0]
        self.assertEqual(encoded_message[0], 0xc0)
        self.assertEqual(encoded_message[1], 0x05)
        self.assertEqual(encoded_message[2], 0x02)
        self.assertEqual(encoded_message[6:9], [0xdb, 0xdc, 0x12])
        self.assertEqual(encoded_message[9], 0xc0)

        # Test that decoding brings back original payload
        decoded_message = self.tld.sl_decode(encoded_message)
        self.assertEqual(decoded_message[0], 0x05)
        self.assertEqual(decoded_message[1], 0x02)
        self.assertEqual(decoded_message[5:], [0xc0, 0x12])

    def test_configuration_message_encoding(self):
        # configure as unknown bus N both channels
        self.assertEqual(
            self.tld.construct_message(
                0x09, [1, 0, 0, 0, 0, 0, 2, 0, 0, 1, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1]),
            [192, 9, 27, 81, 72, 0, 1, 0, 0, 0, 0, 0, 2, 0, 0, 1, 0,
                0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 192]
        )
        # configure as unknown bus P both channels
        self.assertEqual(
            self.tld.construct_message(
                0x09, [1, 1, 0, 0, 0, 0, 2, 0, 0, 1, 1, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1]),
            [192, 9, 27, 210, 244, 0, 1, 1, 0, 0, 0, 0, 2, 0, 0, 1, 1,
                0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 192]
        )
        # configure as serial decode
        self.assertEqual(
            self.tld.construct_message(
                0x09, [2, 0, 0, 0, 0, 0, 2, 0, 0, 2, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1]),
            [192, 9, 27, 137, 119, 0, 2, 0, 0, 0, 0, 0, 2, 0, 0, 2, 0,
                0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 192]
        )

    def test_configuration_message_encoding_strings(self):
        # configure as unknown bus N both channels
        self.assertEqual(
            self.tld.construct_message_from_strings(
                "09", "00", "010000000000020000010000000000020000000000000000000001"),
            "c0091b514800010000000000020000010000000000020000000000000000000001c0"
        )

        self.assertEqual(
            self.tld.construct_message_from_strings(
                "09", "00", "010000000000020000010000000000020000000000000000000001", True),
            "c0 09 1b 51 48 00 01 00 00 00 00 00 02 00 00 01 00 00 00 00 00 02 00 00 00 00 00 00 00 00 00 00 01 c0"
        )

        # seq number is DF
        self.assertEqual(
            self.tld.construct_message_from_strings(
                "09", "DF", "010000000000020000010000000000020000000000000000000001", True),
            "c0 09 1b 51 48 df 01 00 00 00 00 00 02 00 00 01 00 00 00 00 00 02 00 00 00 00 00 00 00 00 00 00 01 c0"
        )

    def test_to_hexstring(self):
        data = [
            {"in":  [27, 2, 33, 16, 7, 0, 1],
             "out": "1B 02 21 10 07 00 01"}
        ]
        for d in data:
            with self.subTest(d):
                r = self.tld.to_hexstring(d['in'])
                self.assertEqual(r, d['out'])

    def test_is_waveform_message(self):
        for message in self.tld.split_to_messages(self.test_data):
            if self.tld.is_waveform_delta_message(message):
                self.assertEqual(message[0], 0x06)

    def test_condense_message_data(self):
        data = [
            {'in': '1B 02 21 10 07 00 01',
             'out': '1b022110070001'},
        ]
        for d in data:
            with self.subTest(d):
                r = self.tld.condense_message_data(d['in'])
                self.assertEqual(r, d['out'])

    def test_contains_message(self):
        data = [
            {'in': 'C0 1B 02 21 10 02 00 01 C0 C0 08 09 76 DF 03 74 65 73 74 31 32 33 34 00 C0 C0 10 08 BB AA 02 01 00 00 00 02 00 00 00 C0',
             'contains': ['TLD_TAG_SNIFFER_DONE',
                          'TLD_TAG_MEASUREMENT_LOGIC_DATA',
                          'TLD_TAG_TOKEN_SLAVE_RETURN'],
             'ok': True},
            {'in': '1B 02 21 10 07 00 01',
             'contains': ['TLD_TAG_SNIFFER_DONE'],
             'ok': False},
        ]
        for d in data:
            with self.subTest(d):
                for tag in d['contains']:
                    if not d['ok']:
                        with self.assertRaises(ValueError):
                            self.tld.contains_message(tag, d['in'])
                    else:
                        self.tld.contains_message(tag, d['in'])

    def test_create_sniffer_cmd_config(self):
        data = [
            {'ch1': '', 'ch2': '', 'service': '', 'sensors': '',
             'out': '',
             'raises': KeyError},
            # No activity
            {'ch1': 'no,n,0,off,,0', 'service': 'off,0,off,,,', 'sensors': '',
             'out': '000000000000000000000000000000000000000000000000000000',
             },
            # Unknown bus - ch1 N and ch2 N + no service port + sensors
            {'ch1': 'unknown,n,0,8n1,,0', 'service': 'off,0,off,,,', 'sensors': 'sensors',
             'out': '010000000000020000010000000000020000000000000000000001',
             },
            # Unknown bus - ch1 P and ch2 P + no service port + sensors
            {'ch1': 'unknown,p,0,8n1,,0', 'service': 'off,0,off,,,', 'sensors': 'sensors',
             'out': '010100000000020000010100000000020000000000000000000001',
             },
            # Unknown bus - ch1 P and ch2 P inverted high gain + no service port + sensors
            {'ch1': 'unknown,p,0,8n1,inverted,16', 'service': 'off,0,off,,,', 'sensors': 'sensors',
             'out': '010100000000020110010100000000020110000000000000000001',
             },
            # Unknown bus as bits - ch1 N and ch2 N high gain + no service port + sensors
            {'ch1': 'unknown_bits,n,0,8n1,,16', 'service': 'off,0,off,,,', 'sensors': 'sensors',
             'out': '040000000000020010040000000000020010000000000000000001',
             },
            # Unknown bus as bits - ch1 N and ch2 N inverted high gain + no service port + sensors
            {'ch1': 'unknown_bits,n,0,8n1,inverted,16', 'service': 'off,0,off,,,', 'sensors': 'sensors',
             'out': '040000000000020110040000000000020110000000000000000001',
             },
            # Unknown bus as bits - ch1 P and ch2 P inverted high gain + no service port + sensors
            {'ch1': 'unknown_bits,p,0,8n1,inverted,16', 'service': 'off,0,off,,,', 'sensors': 'sensors',
             'out': '040100000000020110040100000000020110000000000000000001',
             },
            # UART - ch1 N and ch2 N + no service port + sensors
            {'ch1': 'uart,n,0,8n1,,0', 'service': 'off,0,off,,', 'sensors': 'sensors',
             'out': '020000000000020000020000000000020000000000000000000001',
             },
            # UART - ch1 N and ch2 N inverted high gain + no service port + sensors
            {'ch1': 'uart,n,0,8n1,inverted,16', 'service': 'off,0,off,,', 'sensors': 'sensors',
             'out': '020000000000020110020000000000020110000000000000000001',
             },
            # UART - ch1 P and ch2 P inverted high gain + no service port + sensors
            {'ch1': 'uart,p,0,8n1,inverted,16', 'service': 'off,0,off,,', 'sensors': 'sensors',
             'out': '020100000000020110020100000000020110000000000000000001',
             },
            # CAN -ch1 N and ch2 N + no service port + sensors
            {'ch1': 'can,n,0,off,,0', 'service': 'off,0,off,,', 'sensors': 'sensors',
             'out': '030000000000000000030000000000000000000000000000000001',
             },
            # CAN -ch1 P and ch2 P and 100kbit and high gain and inverted + no service port + sensors
            {'ch1': 'can,p,0,off,inverted,16', 'service': 'off,0,off,,', 'sensors': 'sensors',
             'out': '030100000000000110030100000000000110000000000000000001',
             },
            # CAN -ch1 P and ch2 P and 1mbit and high gain and inverted + no service port + sensors
            {'ch1': 'can,p,1000000,off,inverted,16', 'service': 'off,0,off,,', 'sensors': 'sensors',
             'out': '030140420F00000110030140420F00000110000000000000000001',
             },
            # Service port UART 8N1 + sensors
            {'ch1': 'no,n,0,off,,0', 'service': 'uart,0,8n1,,', 'sensors': 'sensors',
             'out': '000000000000000000000000000000000000010000000002000001',
             },
            # Service port RS232 8N1 + sensors
            {'ch1': 'no,n,0,off,,0', 'service': 'rs232,0,8n1,,', 'sensors': 'sensors',
             'out': '000000000000000000000000000000000000020000000002000001',
             },
            # Service port RS422 8N1 + sensors
            {'ch1': 'no,n,0,off,,0', 'service': 'rs422,0,8n1,,', 'sensors': 'sensors',
             'out': '000000000000000000000000000000000000030000000002000001',
             },
        ]
        def hexify(array):
            return ''.join(['{:02x}'.format(c) for c in array])
        for d in data:
            with self.subTest(d):
                if 'ch2' not in d:
                    d['ch2'] = d['ch1']

                if 'raises' in d:
                    with self.assertRaises(d['raises']):
                        self.tld.create_sniffer_cmd_config(d['ch1'], d['ch2'], d['service'], d['sensors'])
                else:
                    out = self.tld.create_sniffer_cmd_config(d['ch1'], d['ch2'], d['service'], d['sensors'])
                    out = hexify(out)
                    self.assertEqual(d['out'].lower(), out)

    def test_create_raw_tld_payload(self):
        data = [
            {'in': [], 'out': ''},
            {'in': [1, 1], 'out': '01'},
            {'in': [1, 2], 'out': '0100'},
            {'in': [1, 1, 6, 1], 'out': '0106'},
            {'in': [0, 4, 6, 1], 'out': '0000000006'},
            {'in': ['8', 1, '777', 2], 'out': '080903'},
        ]
        def hexify(array):
            return ''.join(['{:02x}'.format(c) for c in array])
        for d in data:
            with self.subTest(d):
                out = self.tld.create_raw_tld_payload(*d['in'])
                out = hexify(out)
                self.assertEqual(d['out'], out)


    def test_create_token_master_grant(self):
        data = [
            # token 10 messages 1 second timeout (id also 1)
            {'in': [1, 10, 1000], 'out': '010000000a00e803'},

            {'in': [0, 0, 0], 'out': '0000000000000000'},
            {'in': [1, 10, 0], 'out': '010000000a000000'},
            {'in': [4294967295, 65535, 65535], 'out': 'ffffffffffffffff'},
        ]
        def hexify(array):
            return ''.join(['{:02x}'.format(c) for c in array])
        for d in data:
            with self.subTest(d):
                token, count, expiration = d['in']
                out = self.tld.create_token_master_grant(token, count, expiration)
                out = hexify(out)
                self.assertEqual(d['out'], out)

    def test_corrupted_message(self):
        data = [
            '02 01 00 00 00 02 00 00 00 C0 C0 08 11 3B FE 04 00 0F 4C 6F 6E 67 65 72 20 74 65 78 74 20 70 72 6F C0 C0 08 16 21 83 05 00 14 62 61 62 6C 79 20 63 61 6E 20 62 65 20 69 6E 6A 65 63 74 65 C0 C0 08 16 5A D4 06 00 14 64 20 69 6E 74 6F 20 74 68 69 73 20 66 75 6E 63 74 69 6F 6E C0 C0 08 16 C2 93 07 00 14 2E 20 49 74 20 6D 69 67 68 74 20 67 65 74 20 73 70 6C 69 74 C0 C0 08 11 2C D3 08 00 0F 2C 20 62 75 74 20 69 74 27 73 20 6F 6B 2E 00 C0 C0 10 08 96 FB 03 01 00 00 00 05 00 00 00 C0',
            '00 01 00 00 00 06 00 00 00 C0 C0 12 09 56 94 06 08 74 65 73 74 31 32 33 34 C0 C0 10 08 67 31 01 01 00 00 00 01 00 00 00 C0',
        ]
        for d in data:
            with self.subTest(d):
                messages = list(self.tld.split_to_messages(d))
                s1 = [self.tld.message_as_string(m) for m in messages]
                self.assertNotEqual(s1, [])

    def test_compare_message_splitting(self):
        """Compare the old and new message splitting functionality."""
        data = [
            'C0 06 5B 26 4B 59 01 00 51 25 02 20 00 03 01 14 00 7F 68 04 00 0F 1A 01 00 7A 68 04 00 0B 1A 01 00 81 68 04 00 0F 1A 01 00 78 68 04 00 1A 1A 01 00 97 68 04 00 1B 1A 01 00 82 68 04 00 18 1A 01 00 A4 68 04 00 1E 1A 01 00 A2 68 04 00 11 1A 01 00 90 68 04 00 12 1A 01 00 73 68 04 00 0B 1A 01 00 C0 C0 06 5B 56 72 5A 01 00 51 25 02 20 00 02 01 14 00 76 68 04 00 0F 1A 01 00 8B 68 04 00 13 1A 01 00 85 68 04 00 15 1A 01 00 8D 68 04 00 18 1A 01 00 99 68 04 00 1A 1A 01 00 AC 68 04 00 10 1A 01 00 7D 68 04 00 1D 1A 01 00 9B 68 04 00 23 1A 01 00 D5 68 04 00 23 1A 01 00 D4 68 04 00 2C 1A 01 00 C0 C0 06 5B 2F 6C 5B 01 00 51 25 02 20 00 01 01 14 00 D1 68 04 00 21 1A 01 00 BD 68 04 00 1E 1A 01 00 9F 68 04 00 13 1A 01 00 8A 68 04 00 1B 1A 01 00 9B 68 04 00 15 1A 01 00 91 68 04 00 11 1A 01 00 96 68 04 00 19 1A 01 00 98 68 04 00 15 1A 01 00 87 68 04 00 11 1A 01 00 87 68 04 00 0F 1A 01 00 C0 C0 06 37 D4 CA 5C 01 00 51 25 02 20 00 00 01 0B 00 7E 68 04 00 12 1A 01 00 71 68 04 00 11 1A 01 00 99 68 04 00 14 1A 01 00 A0 68 04 00 12 1A 01 00 A3 68 04 00 18 1A 01 00 A7 68 04 00 C0 C0 06 5B FA 58 5D 01 00 51 25 02 20 01 03 01 14 00 90 68 04 00 20 1A 01 00 9E 68 04 00 1B 1A 01 00 78 68 04 00 0E 1A 01 00 6C 68 04 00 11 1A 01 00 92 68 04 00 15 1A 01 00 85 68 04 00 0D 1A 01 00 7A 68 04 00 04 1A 01 00 6A 68 04 00 14 1A 01 00 89 68 04 00 1A 1A 01 00 B2 68 04 00 20 1A 01 00 C0 C0 06 5B 84 28 5E 01 00 51 25 02 20 01 02 01 14 00 C6 68 04 00 18 1A 01 00 BE 68 04 00 1B 1A 01 00 B0 68 04 00 24 1A 01 00 C9 68 04 00 1D 1A 01 00 98 68 04 00 1F 1A 01 00 B4 68 04 00 1A 1A 01 00 B3 68 04 00 1E 1A 01 00 A9 68 04 00 1A 1A 01 00 BC 68 04 00 1D 1A 01 00 A8 68 04 00 18 1A 01 00 C0 C0 06 5B 76 1A 5F 01 00 51 25 02 20 01 01 01 14 00 AE 68 04 00 1D 1A 01 00 B4 68 04 00 22 1A 01 00 B4 68 04 00 24 1A 01 00 B7 68 04 00 13 1A 01 00 8E 68 04 00 10 1A 01 00 84 68 04 00 12 1A 01 00 75 68 04 00 0A 1A 01 00 7E 68 04 00 10 1A 01 00 71 68 04 00 0D 1A 01 00 6E 68 04 00 08 1A 01 00 C0 C0 06 37 2C 6E 60 01 00 51 25 02 20 01 00 01 0B 00 5D 68 04 00 0F 1A 01 00 76 68 04 00 0E 1A 01 00 96 68 04 00 0C 1A 01 00 57 68 04 00 0B 1A 01 00 5E 68 04 00 0F 1A 01 00 74 68 04 00 C0 C0 03 08 2A 57 61 29 89 01 00 89 09 00 00 C0 C0 10 08 A4 B4 1A 01 00 00 00 09 00 00 00 C0',
            'C0 07 30 14 E9 87 01 2D 05 FF FE FD F7 DF 7F FF FD F7 DF 7F FF FD F7 DF 7F FF FD F7 DF 7F FF FD F7 DF 7F FF FD F7 DF 7F FF FD F7 DF 7F FF FD F7 DF 7F FF FD F7 1F C0 C0 07 36 6E C2 88 01 33 05 00 00 00 FF FD EF 7F FF FB DF FF FE F7 BF FF FD EF 7F FF FB DF FF FE F7 BF FF FD EF 7F FF FB DF FF FE F7 BF FF FD EF 7F FF FB DF FF FE F7 BF FF FD EF 7F C0 C0 07 32 A2 4F 89 01 2F 03 00 00 00 BF FF FE FB EF BF FF FE FB EF BF FF FE FB EF BF FF FE FB EF BF FF FE FB EF BF FF FE FB EF BF FF FE FB EF BF FF FE FB EF BF FF FE 03 C0 C0 07 32 12 9B 8A 01 2F 06 00 00 00 01 04 10 40 00 01 04 10 40 00 01 04 10 40 00 01 04 10 40 00 01 04 10 40 00 01 04 10 40 00 01 04 10 40 00 01 04 10 40 00 01 04 10 00 C0 C0 07 31 30 5A 8B 01 2E 06 00 00 00 F7 DF 7F FF FD F7 DF 7F FF FD F7 DF 7F FF FD F7 DF 7F FF FD F7 DF 7F FF FD F7 DF 7F FF FD F7 DF 7F FF FD F7 DF 7F FF FD F7 DF 7F C0 C0 07 32 96 75 8C 01 2F 06 00 00 00 FF FD F7 DF 7F FF FD F7 DF 7F FF FD F7 DF 7F FF FD F7 DF 7F FF FD F7 DF 7F FF FD F7 DF 7F FF FD F7 DF 7F FF FD F7 DF 7F FF FD F7 1F C0 C0 07 31 0F 18 8D 01 2E 06 00 00 00 FD F7 DF 7F FF FD F7 DF 7F FF FD F7 DF 7F FF FD F7 DF 7F FF FD F7 DF 7F FF FD F7 DF 7F FF FD F7 DF 7F FF FD F7 DF 7F FF FD F7 1F C0 C0 07 36 67 25 8E 01 33 07 00 00 00 FF FE F7 BF FF FD EF 7F FF FB DF FF FE F7 BF FF FD EF 7F FF FB DF FF FE F7 BF FF FD EF 7F FF FB DF FF FE F7 BF FF FD EF 7F FF FB DF FF FE F7 3F C0 C0 07 37 EC D1 8F 01 34 05 00 00 00 1F 80 00 04 20 00 01 08 40 00 02 10 80 00 04 20 00 01 08 40 00 02 10 80 00 04 20 00 01 08 40 00 02 10 80 00 04 20 00 01 08 40 00 02 10 80 00 04 00 C0 C0 10 08 ED 3E 26 01 00 00 00 09 00 F8 01 C0'
        ]
        import difflib

        def old_split_to_messages(content):
            if isinstance(content, list):
                for msg in content:
                    msg = self.tld.condense_message_data(msg)
                    yield bytes.fromhex(msg)
                return

            content = self.tld.condense_message_data(content)

            start = None
            for i in range(0, len(content), 2):
                if content[i:i+2] == 'c0':
                    if start is not None:
                        message = content[start:i+2]
                        start = None
                        yield self.tld.sl_decode([
                            int(message[i:i+2], base=16) for i in range(0, len(message), 2)
                        ])
                    else:
                        start = i

        for d in data:
            with self.subTest(d):
                msgs1 = list(old_split_to_messages(d))
                msgs2 = list(self.tld.split_to_messages(d))
                s1 = [self.tld.message_as_string(m) for m in msgs1]
                s2 = [self.tld.message_as_string(m) for m in msgs2]

                diff = list(difflib.unified_diff(s1, s2, fromfile='old', tofile='new'))
                self.assertEqual(diff, [])


if __name__ == '__main__':
    unittest.main()
