#!/bin/sh

usage() {
    cat <<EOF
Usage: $0 [waveform-delta-json-object ...]

Read waveform delta JSON from stdin and plot the waveform.

Example usage:

curl http://raspberrypi-host/path/to/output_module_test_yabb330_B.xml | \
     ./plot_unknown_delta_waveform.sh

This generates ${OUTFILE} with all of the delta waveform printouts in the file.

EOF

}

OUTFILE=${OUTFILE:-delta-waveform.svg}
TMPFILE=/tmp/delta-gnuplot.tmp

get_deltalogs_startrows() {
    grep -n '^.msg timestamp.*deltas' | sed 's/:.*//'
}

# args: startrow
parse_deltas() {
    sed -n -e "/END/q; $1,/<.msg>\$/{ /^[0-9].*deltas.:/{ s/^.*deltas.: \[//; s/\].*//; p; }; };"
}

# args: startrow
get_initial_y() {
    sed -n -e "/END/q; $1,/<.msg>\$/{ /^[0-9].*symbols/{ s/.*symbols.:..\([01]\).*/\1/; p; q;}; };"
}

# args: startrow
generate_single_plot_data() (
    y=${INITIALY:-0}
    x=0
    cat | parse_deltas "$1" | sed 's/, */\n/g;' | while read inc; do
        echo "$x  $y"
        x=$(( x + $inc))
        y=$(( (y + 1) % 2 ))
    done
)

# args: filename
generate_plot_data() (
    i=0
    for s in $STARTROWS; do
        INITIALY=$(< "$1" get_initial_y "$s")
        cat <<EOF
\$data${i} <<EOD
EOF
        < "$1" generate_single_plot_data "$s"
        cat <<EOF
EOD
EOF
        i=$((i + 1))
    done
)

generate_plot_commands() (
    if test $STARTCOUNT -gt 1; then
        cat <<EOF
set multiplot layout $STARTCOUNT,1 title "Delta waveforms"
EOF
    fi

    for s in $(seq 0 $((STARTCOUNT - 1))); do
        cat <<EOF
plot \$data${s} using 1:2 w steps lc rgb "red" lw 2 ti "";
EOF
    done
)

# main script

if test -z "$1"; then
    # Read waveform delta data from STDIN
    cat > $TMPFILE
else
    # waveform delta jsons are given as arguments to this script

    # fake the xml file markers in the file
    echo ".msg timestamp..deltas" > $TMPFILE
    I=0
    for arg; do
        echo "$I: $arg" >> $TMPFILE
        I=$((I + 1))
    done
    echo "<.msg>" >> $TMPFILE
fi

STARTROWS=$(< $TMPFILE get_deltalogs_startrows)
STARTCOUNT=$(echo "$STARTROWS" | wc -l)

cat <<EOF | gnuplot -p -

$(generate_plot_data $TMPFILE)

set size ratio 0.3
set yrange [-0.05:1.2]
set terminal svg
set output "${OUTFILE}"

$(generate_plot_commands)
# plot \$data using 1:2 w steps lc rgb "red" lw 2 ti "delta waveform";

EOF

# rm -f "$TMPFILE"
