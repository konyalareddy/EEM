#!/bin/sh

usage() {
    cat <<EOF
Usage: $0 anylift-ip-address command

Commands:

install-ssh-key working-key    Install the $SSHKEY using a given key.

show-anylift-status            Print information of the anylift.
show-stidi-inventory           Print the inventory of stidis as comma separated addresses

delete-stidis                  Remove joined nodes and restart MeshApplication application

enable-stidi-debug             Enable debug log for MeshApplication and restart it
disable-stidi-debug

retrieve-stidi-debug           Retrieve and print the accumulated MeshApplication debug log.
                               Remove the log and restart MeshApplication.

enable-mqtt-traffic            Punch a hole through the firewall in the dev-edition
                               of Anylifts for the MQTT traffic.

restart-application             Restarts MeshApplication.

This script needs to be run in this directory !

EOF
}

SSHKEY=id_anylift_robot

CMDPFX=cmd_

log() { echo "$@"; }
error() { log "Error: $@"; }
die() { error "$@"; exit 1; }

_ssh_anylift() {
    ssh -i "$SSHKEY" root@${ANYLIFTIP} "$@"
}

cmd_install_ssh_key() {
    KEY="$1"

    test -f "$SSHKEY" || die Could not find ssh-key to install: "$SSHKEY"

    log "Installing the ssh-key to the anylift in ip $ANYLIFTIP using key $KEY"
    NEWKEY="$SSHKEY"
    SSHKEY="$KEY"
    cat "$NEWKEY".pub | _ssh_anylift 'set -x; F=/var/volatile/tmp/ssh-key.tmp; cat > $F; \
   if ! grep -Fq "$(cat $F)" $HOME/.ssh/authorized_keys; then mount -o remount,rw /; cat $F >> $HOME/.ssh/authorized_keys; mount -o remount,ro /; fi; \
   rm -vf $F;'
}

cmd_show_anylift_status() {
    _ssh_anylift '
echo "Anylift ID: $(grep -o "anylift.*" /configuration/encrypted/sa.conf)"
echo "Anylift Wirepas network configuration:"
sed  -n "/network_address/p; /network_channel/p; /node_role/p;" < /shared/conf/anylift.json
echo "MeshApplication debug logging: $(grep ^DEBUG_LOGGING /etc/init.d/MeshApplication)";
echo "Joined stidi addresses:"
grep "address.*" /shared/MeshApplication/nodes
echo "Anylift version update history:"
grep version /shared/SecurityLogger/logs/security.log
true
'
}

cmd_show_stidi_inventory() {
    _ssh_anylift "
{
    sed -n -e '/address/{s/.* : //; p; }' < /shared/MeshApplication/nodes | tr '\n' ' '
    echo
} | sed -e 's/, *$//'
"
}

ROOT_RW="mount -o remount,rw /;"
ROOT_RO="mount -o remount,ro /;"
RESTART_STIDI_APPLICATION="/etc/init.d/MeshApplication stop; /etc/init.d/MeshApplication start;"

cmd_delete_stidis() {
    _ssh_anylift "
rm -vf /shared/MeshApplication/nodes
$RESTART_STIDI_APPLICATION
"
}

cmd_enable_stidi_debug() {
    _ssh_anylift "F=/etc/init.d/MeshApplication;
if ! grep -q '^DEBUG_LOGGING=yes' \$F; then
  $ROOT_RW
  sed -e 's/^DEBUG_LOGGING=.*/DEBUG_LOGGING=yes/' -i \$F
  $ROOT_RO
  $RESTART_STIDI_APPLICATION
else
  echo 'MeshApplication debugging already enabled.'
fi
"
}

cmd_disable_stidi_debug() {
    _ssh_anylift "F=/etc/init.d/MeshApplication;
if ! grep -q '^DEBUG_LOGGING=no' \$F; then
  $ROOT_RW
  sed -e 's/^DEBUG_LOGGING=.*/DEBUG_LOGGING=no/' -i \$F
  $ROOT_RO
  $RESTART_STIDI_APPLICATION
else
  echo 'MeshApplication debugging already disabled.'
fi
"
}

cmd_retrieve_stidi_debug() {
    _ssh_anylift "F=/shared/meshapp.log;
if test -f \$F; then
  cat \$F;
  rm -vf \$F;
  $RESTART_STIDI_APPLICATION
else
  echo 'No MeshApplication debug log present.'
fi
"
}

MQTT_RULE="-A INPUT -p tcp -m tcp --dport 1883 -j ACCEPT"
cmd_enable_mqtt_traffic() {
    _ssh_anylift "
if /usr/sbin/iptables -S | grep -Fq -- \"$MQTT_RULE\"; then
  echo 'MQTT traffic passes the firewall already during this boot'
else
  /usr/sbin/iptables $MQTT_RULE
fi
"
}

cmd_restart_application() {
    _ssh_anylift "$RESTART_STIDI_APPLICATION"
}

# Get the command list via shell "introspection"
COMMANDS=$(sed -n "/^$CMDPFX/{ s/$CMDPFX\\([^ ()]*\\)(.*\$/\\1/; p;}" < "$0")

# main script
ANYLIFTIP="$1"
COMMAND="$2"
case "$ANYLIFTIP" in
    ''|-h|--help|help) usage; exit 0 ;;
esac

COMMAND=$(echo "$COMMAND" | sed 'y/-/_/;')

test -z "$COMMAND" && { usage; exit 1; }
case "$COMMANDS" in
    *${COMMAND}*) ;;
    *) usage; exit 1;;
esac

shift 2

chmod 600 ${SSHKEY} || die "Could not find file ${SSHKEY} in $(pwd)"

${CMDPFX}${COMMAND} "$@"
