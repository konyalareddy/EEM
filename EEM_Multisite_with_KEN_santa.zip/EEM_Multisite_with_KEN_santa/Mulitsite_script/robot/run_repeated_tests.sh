#!/bin/sh

usage() {
    cat <<EOF
Usage: $0 [-h|--help] <argsfile> <test-tag>

Runs tests repeatedly with the given tag.

The argsfile determines in which setup the tests are being run.

The following repeated tests found:

$(list_repeated_tags)

EOF
}

TESTDIR=tests

die() {
    echo "Error: $@"
    exit 1
}

list_repeated_tags() {
    grep -i 'tag.*_repeat' "$TESTDIR"/* | grep -o '[^ ]\+_repeat'
}

prepare_argsfile() {
    sed -e '/\(in\|ex\)clude/d; /^[^-]/d; /--rpa/d;'
}

# main script
case "$1" in
    ''|-h|--help) usage; exit 0 ;;
esac

ARGSFILE="$1"
TESTTAG="$2"

test -f "$ARGSFILE" || die "Could not find argument file: $ARGSFILE"

list_repeated_tags | grep -q "$TESTTAG" || die "Could not find test tag: $TESTTAG"


ROUND=0;
while :; do
    prepare_argsfile < "$ARGSFILE"

    prepare_argsfile < "$ARGSFILE" | \
        robot -A STDIN --include "$TESTTAG" $TESTDIR || \
        die "Running test $TESTTAG failed on round $ROUND"

    ROUND=$((ROUND + 1))
done
