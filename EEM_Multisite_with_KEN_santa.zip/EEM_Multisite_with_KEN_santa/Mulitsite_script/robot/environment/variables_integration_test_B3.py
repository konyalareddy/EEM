#These are the USB ID of the different JLink devices

jlink_stidi_anylift = '821000498'
jlink_stidi_yabb330 = '821000349'
jlink_yabb330 = '821001051'

sink_node = 'KM51671506G01.300XX205100062'

stidi_nodes = [
    'KM51671506G01.300XX205100061',
]

# Mapping of stidi nodes to jlink devices
stidi_jlink_nodes = {
    sink_node: jlink_stidi_anylift,
    stidi_nodes[0]: jlink_stidi_yabb330,
}

# Mapping of stidi nodes to wirepas addresses
stidi_addresses = {
    stidi_nodes[0]: 1760496861,
}

network_address = '866'

mqtt_broker_hostname = '192.168.0.68'
mqtt_broker_username = ''
mqtt_broker_password = ''
mqtt_broker_port = '1883'
gateway_ID = None
