# Introduction
This repository contain the robot frameworks test scripts
and additional python scripts that are used for integration testing of YABB330.

## Robot test files

All of the tests to run are in the `robot/tests` directory.
The tests to run are selected with the `arguments/*.args` files.

The tests are divided in the following files:

| Name                 | Description                                 |
|----------------------|---------------------------------------------|
| 0_selftests.robot    | Sanity checks for the tests.                |
| 1_bootup.robot       | Verify that devices boot correctly.         |
| 2_provisioning.robot | Verify device provisioning.                 |
| 3_otap.robot         | Verify YABB330 OTAP.                        |
| 4_led.robot          | Verify LED behaviour.                       |
| 5_sniffing.robot     | Verify YABB330 Sniffing capabilities.       |
| 6_remote_call.robot  | Verify Elevator landing call behaviour.     |
| 7_service_port.robot | Verify Service port capabilities.           |
| 8_validation.robot   | Tests to run in in-house-validation setups. |
| 9_challenging.robot  | Challenging tests.                          |


# Installation
sudo apt-get install robot-framework

Serial library dependency:

git clone https://github.com/whosaysni/robotframework-seriallibrary.git

cd robotframework-seriallibrary

sudo pip install .

cd ..

# Run the test cases

## YABB330 Module tests

Module tests are documented in:

https://confluence.kone.cbyte.fi/display/YABB330/YABB330+module+testing

Currently there are the following YABB330 module tests:

- module_test_yabb330_A
- module_test_yabb330_A2
- module_test_yabb330_B

They are specific hardware setups with distinct capabilities.
They can be run in the following way in their respective hardware setups.

```
# A
(cd robot && robot -A arguments/module_test_yabb330_A.args)

# A2
(cd robot && robot -A arguments/module_test_yabb330_A2.args)

# B
(cd robot && robot -A arguments/module_test_yabb330_B.args)
```

## Integration tests

Integration tests are documented in:

https://confluence.kone.cbyte.fi/display/YABB330/Integration+testing

There are the following integration test setups:

- integration_test_B2

The tests can be run in the following way in the respective hardware setup:

```
# B2
(cd robot && robot -A arguments/integration_test_B2.args)
```

## Repeated tests

Some tests can be run indefinitely in order to find hard-to-reproduce bugs.
For this there is a script `run_repeated_tests.sh`.

The current list of the repeated tests can be printed out in the following way:

```
(cd robot && ./run_repeated_tests.sh --help)
```

To run, for example, the OTAP repeated test on module setup A, run the following command:

```
(cd robot && ./run_repeated_tests.sh arguments/module_test_yabb330_A.args otap_repeat)
```

This will run the test with tag `otap_repeat` until it fails.
The log file names will be the same as with the default module tests.
(They are determined by the arguments file.)

# Reports of the test runs

Reports are contained in the folder: `robot/results`

The file name of the report depends on the robot run setup.
E.g. for the integration test B2, the following files are generated:

- log_integration_test_B2.html
- output_integration_test_B2.xml
- report_integration_test_B2.html

The HTML files are human readable format of the test results.
The XML file is a machine processable format of the results.


# In-house Validation (IHV) tests

These tests are documented in:

https://confluence.kone.cbyte.fi/display/YABB330/In-house+validation+test+setup

The goal of this testing is to run the tests continuously and report all failures.

There are multiple different IHV setups and they are all run in the following way:

```
screen
cd robot
./run_validation.sh
```

The test script is run inside `screen` so that the run will continue after the user has logged out of the setup.
On failure, the tests generate log packages that look like the following:

```
validation-test-ihv-bot-80-20210324-181514-round-600-20210325-005357.tar.gz
```

The log package contains the report HTML and XML files mentioned in the above "Reports of the test runs" section.


## Analyzing the IHV log packages

Most of the failures in the IHV tests are benign.
For example, some missing or incomplete data was received over the Wirepas.
As there are multiple IHV setups, a lot of these benign failures are reported.
Analyzing them all by hand is time consuming and for that there is the `analyze_validation.sh` script.

The script parses the failure reason from the log packages and prints out a summary of the whole batch.
The script can be run in the following way:

```
cd robot
./analyze_validation.sh validation-test*tar.gz
```

It prints out something like:

```
$ ./analyze_validation.sh *2021032{7,8,9}*tar.gz

validation-test-ihv-bot-80-20210326-125649-round-1089-20210327-005817.tar.gz
Error: NameError: Didn't receive data from received_data topic.
Node:  1214592046
Round: 1089
validation-test-ihv-bot-80-20210327-005819-round-245-20210327-034253.tar.gz
Error: Dictionary does not contain key '1803225767'.
Node:  1803225767
Round: 245

...

Summary:

Total Rounds:   5452
Failed rounds:  19
Average rounds before error: 286

Nodes that triggered errors:
3 1214592046
13 1803225767
1 216114994
1 812585240
1 1580018814

Errors and counts they happened:
11 NameError: Didn't receive data from received_data topic.
1 hello 13 != h
1 Dictionary does not contain key '1214592046'.
3 Dictionary does not contain key '1803225767'.
1 hello 17 != hello 1
1 hello 5 != h
1 hello 16 != hel
```

# Manage Anylifts as part of the test setups

As of this writing (2021-04-13, v3 Anylift), Anylift needs specific SSH handling for certain operations to be a functional part of the tests.

The operations include:
- Installing a test-specific SSH key, without a password, in the Anylift to be able to run the commands unattended.
- Delete the registered stidis from Anylift to be able to join them again.
- Enabling and retrieving the Stidi-applications debug-log.
- Punching a hole through the Anylift firewall for the MQTT traffic.
  This is needed only for the *DEV* version.
  The *TEST* version has already permissible firewall rules.

For this, there is the script `robot/scripts/manage_anylift.sh`.
It has the following usage:

```
Usage: ./manage_anylift.sh anylift-ip-address command

Commands:

install-ssh-key working-key    Install the id_anylift_robot using a given key.

show-anylift-status            Print information of the anylift.
show-stidi-inventory           Print the inventory of stidis as comma separated addresses

delete-stidis                  Remove joined nodes and restart Stidi application

enable-stidi-debug             Enable debug log for Stidi and restart it
disable-stidi-debug

retrieve-stidi-debug           Retrieve and print the accumulated Stidi debug log.
                               Remove the log and restart Stidi.

enable-mqtt-traffic            Punch a hole through the firewall in the dev-edition
                               of Anylifts for the MQTT traffic.


This script needs to be run in this directory !

```

The script needs to be run in the `robot/scripts` directory, because in the same directory, there is the `id_anylift_robot` SSH key.
The first argument of the script is always the IP address or host name of the Anylift device.

The `./manage_anylift.sh <ip-address> install-ssh-key <dev-or-test-ssh-key>` needs to be run first.
It installs the `id_anylift_robot` key using either the given *TEST* or the *DEV* keys (depending on the Anylift flavour).
Afterwards the commands work without using *TEST* or *DEV* keys and WITHOUT giving a password.

# Registering Stidis with v3 Anylift

The v3 Anylift has a feature that it joins and assigns stidis to the wirepas network using nameplate information and not the hard-coded node address.
The nameplate information is written with the firmware to the stidi itself using JLink in a file named `provisioning_config.hex`.

The nameplate information has the following kind of format:
```
KM51671506G01.300XX205100049
```

## Generating nameplate file

Flashable nameplate information can be generated using the scripts found in the yabb_production_tester repository:

https://scm.kone.com/kone/projects/maintenance_development/repositories/yabb_production_tester/tree/dev

The nameplate file can be generated with the following commands:

```
cd yabb_production_tester/common

# Install the python dependencies to be able to create the file
python3 -m virtualenv -p python3 venv
./venv/bin/pip install crcmod pyyaml
```

Create file:

```
cd yabb_production_tester/common
NAME=KM51671506G01.300XX205100049; ./venv/bin/python3 genConfigHex_kone.py open_join_config.yml --address 1036288 -c $NAME -o $NAME
```

This creates a file `KM51671506G01.300XX205100049` with the proper nameplate information.

## Flashing stidis with the proper nameplate information

To be able to flash the latest stidi firmware and the `provisioning_config.hex`, the following steps need to be taken:

- The file that is generated with the steps in the above section, needs to be put in the following directory in *this* repository: `build/provisioning_configs`
- The test environment file needs to be updated to instruct which JLink will be flashed with which nameplate information.
  In the `robot/environment/variables_integration_test_B2.py` there is the following section:
  ```
  jlink_stidi_yabb330 = '821001349'
  stidi_nodes = [
    'KM51671506G01.300XX205100049',
  ]

  # Mapping of stidi nodes to jlink devices
  stidi_jlink_nodes = {
	stidi_nodes[0]: jlink_stidi_yabb330,
  }
  ```

  The above instructs that JLink with serial `821001349` is connected to a stidi that will be flashed with nameplate information of `KM51671506G01.300XX205100049`.
