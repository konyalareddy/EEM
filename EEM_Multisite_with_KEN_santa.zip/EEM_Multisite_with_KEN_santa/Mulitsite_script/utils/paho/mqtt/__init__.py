__version__ = "1.5.1"


class MQTTException(Exception):
    pass
