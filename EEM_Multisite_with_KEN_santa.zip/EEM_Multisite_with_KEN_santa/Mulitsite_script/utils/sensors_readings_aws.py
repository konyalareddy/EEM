#!/bin/python

import json
import logging
import sys
import argparse
from time import sleep
from struct import *
import logging
import sys
import argparse
from time import sleep
from struct import *
import os
import time
import sys
import paho.mqtt.client as mqtt
import json
from datetime import datetime
from datetime import date
from time import sleep
from ctypes import *
from AWSIoTPythonSDK.MQTTLib import AWSIoTMQTTClient

#host = "a3d6q0lbn9mmos-ats.iot.us-east-2.amazonaws.com"    #Ohio
host = "a31ek7oii7b5nb-ats.iot.eu-west-1.amazonaws.com"     #Ireland
#certPath = "C:/Users/K64067997/Downloads/EEM_handover/EEM_python/EEM_data_routing_setup_3/utils/device_cert/"   # Change this for other directory
certPath = "C:/Users/k64107907/Downloads/EEM_Multisite_with_KEN_santa/Mulitsite_script/utils/device_cert/"
#certPath = "C:/Users/k64066761/Stidi_sdk/wm-sdk-kone/Python_script/EEM_data_routing_setup_3/utils/demo-cert/"
clientId = "elevator_68A_config"
topic_data = "Energy_Parameters_Values"
topic_config = "Energy_Metadata_Values"
topic_alert = "Energy_Threshold_Values"

V_R_past = 1
V_Y_past = 1
V_B_past = 1

flag = 0
'''
THINGSBOARD_HOST = 'ec2-63-35-251-175.eu-west-1.compute.amazonaws.com'
ACCESS_TOKEN = 'o4b3Sw8xDOBQ5BPo0IIc'

sensor_data = {'V(R)': 0, 'V(Y)': 0, 'V(B)': 0, 'I(R)': 0, 'I(Y)': 0, 'I(B)': 0, 'PA(t)': 0, 'PA(R)': 0, 'PA(Y)': 0, 'PA(B)': 0, 'PR(t)': 0, 'PR(R)': 0, 'PR(Y)': 0, 'PR(B)': 0, 'PF(t)': 0, 'PF(R)': 0, 'PF(Y)': 0, 'PF(B)': 0, 'Freq': 0, 'E(exp)': 0, 'E(imp)': 0}

config_data = {'METER_SW': 0, 'PR_PASS': 0, 'CON_MODE': 0, 'CT_R': 0, 'PT_R': 0, 'BAUD': 0, 'COM_ADR': 0}

next_reading = time.time() 

client = mqtt.Client()
# Set access token
client.username_pw_set(ACCESS_TOKEN)

# Connect to ThingsBoard using default MQTT port and 60 seconds keepalive interval
client.connect(THINGSBOARD_HOST, 1883, 60)

client.loop_start()
'''
# Init AWSIoTMQTTClient
myAWSIoTMQTTClient = None
myAWSIoTMQTTClient = AWSIoTMQTTClient(clientId)
myAWSIoTMQTTClient.configureEndpoint(host, 8883)
myAWSIoTMQTTClient.configureCredentials("{}root-CA.crt".format(certPath), "{}energy_metadata.private.key".format(certPath), "{}energy_metadata.cert.pem".format(certPath))
#myAWSIoTMQTTClient.configureCredentials("{}root-CA.crt".format(certPath), "{}elevator.private.key".format(certPath), "{}elevator.cert.pem".format(certPath))
# AWSIoTMQTTClient connection configuration
myAWSIoTMQTTClient.configureAutoReconnectBackoffTime(1, 32, 20)
myAWSIoTMQTTClient.configureOfflinePublishQueueing(-1) # Infinite offline Publish queueing
myAWSIoTMQTTClient.configureDrainingFrequency(2) # Draining: 2 Hz
myAWSIoTMQTTClient.configureConnectDisconnectTimeout(20) # 10 sec
myAWSIoTMQTTClient.configureMQTTOperationTimeout(20) # 5 sec
myAWSIoTMQTTClient.connect()

sys.path.insert(0, '../robot/libs/')
from AnyliftMiddleware import AnyliftMiddleware


class HydroReading():

    def __init__(self, raw_bytes, str_format = False):
        assert(raw_bytes)
        if str_format:
            raw_bytes = bytes.fromhex(raw_bytes)

        logging.debug(raw_bytes)

        '''
        Assuming to have 
        uint32_t sequence; NB: this field is actually uint8_t in the FW
        float32_t temperature;
        float32_t height;
        '''
        self.reading = unpack('Iff', raw_bytes)

    def get(self):
        return self.reading

    def __repr__(self):

        ret = "#{}\t{}\t{}".format(self.reading[0], self.reading[1], self.reading[2])

        logging.info(ret)

        return ret

############################For Energy Reading Decoding ###################################3
class EnergyReading():

    def __init__(self,ken, raw_bytes, str_format = False):
        assert(raw_bytes)
        global ken1
        if str_format:
            raw_bytes = bytes.fromhex(raw_bytes)
            ken1 = str(ken)
        print("HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH")
        print(ken1)
        print("HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH")
        logging.debug(raw_bytes)
        #print(type(raw_bytes[0]))
        global length
        length = sys.getsizeof(raw_bytes)
        print(length)
        if (length == 61) :
            self.reading = unpack('Iffffff', raw_bytes)
        
        elif (length == 117) :      
            self.reading = unpack('Iffffffffffffffffffff', raw_bytes)

        elif (length == 41) :
            self.reading = unpack('bbbbbbbb', raw_bytes) 
            

    def get(self):
        return self.reading

    def __repr__(self):
        global flag
        #print(self.reading[0])

        #Logic to parse Non-Critical Parameters
        if (length == 117) :
            ret = "\n********************************************************\n"
            ret += "#{}\n".format(self.reading[0])
            ret += "Active Power:{:.3f}\t{:.3f}\t{:.3f}\t{:.3f}\n".format(self.reading[1], self.reading[2], self.reading[3], self.reading[4])
            ret += "--------------------------------------------------------\n"
            ret += "Reactive Power:{:.3f}\t{:.3f}\t{:.3f}\t{:.3f}\n".format(self.reading[5], self.reading[6], self.reading[7], self.reading[8])
            ret += "--------------------------------------------------------\n"
            ret += "F Power:{:.3f}\t{:.3f}\t{:.3f}\t{:.3f}\n".format(self.reading[9], self.reading[10], self.reading[11], self.reading[12])
            ret += "--------------------------------------------------------\n"
            ret += "Freq:{:.3f}\n".format(self.reading[13])
            ret += "--------------------------------------------------------\n"
            ret += "D_POW:{:.3f}\n".format(self.reading[14])
            ret += "--------------------------------------------------------\n"
            ret += "Energy:{:.3f}\t{:.3f}\n".format(self.reading[15], self.reading[16])           
            ret += "--------------------------------------------------------\n"
            ret += "Quadrant Reactive Energy:{:.3f}\t{:.3f}\t{:.3f}\t{:.3f}\n".format(self.reading[17], self.reading[18], self.reading[19], self.reading[20])
            ret += "*********************************************************\n"  
            message = {"Critical" : "N","Version" : 3,
                                      "Ken":ken1,
                                      "Device_Time": date.today().strftime("%Y/%m/%d") + 'T' + datetime.now().strftime("%H:%M:%S"),
                                      "Created_on" : " ", 
                                      "PA_t": self.reading[1], "PA_R": self.reading[2],"PA_Y": self.reading[3], "PA_B": self.reading[4],
                                      "PR_t": self.reading[5], "PR_R": self.reading[6],"PR_Y": self.reading[7], "PR_B": self.reading[8],
                                      "PF_t": self.reading[9], "PF_R": self.reading[10],"PF_Y": self.reading[11], "PF_B": self.reading[12],
                                      "Freq": self.reading[13], "D_POW": self.reading[14], "E_exp": self.reading[15],"E_imp": self.reading[16],
                                      "Q1_Eq": self.reading[17],"Q2_Eq": self.reading[18],"Q3_Eq": self.reading[19],"Q4_Eq": self.reading[20]}
            
            messageJson = json.dumps(message)
            myAWSIoTMQTTClient.publish(topic_data, messageJson, 1)
        
        #Logic to parse Metadata
        elif((length == 61)) :
            if((self.reading[0] == 1121583104)) :
                ret = "\n********************************************************\n"
                ret += "Meter Software:{:.3f}\tPassword:{:.3f}\tCon_mode:{:.3f}\n".format(self.reading[0], self.reading[1], self.reading[2])
                ret += "-------------------------------------------------------\n"
                ret += "CT Ratio:{:.3f}\tPT Ratio:{:.3f}\tBaud:{:.3f}\n".format(self.reading[3], self.reading[4], self.reading[5])
                ret += "--------------------------------------------------------\n"
                ret += "Communication Address:{:.3f}\n".format(self.reading[6])
                ret += "*********************************************************\n"
                
                message ={   "Ken": ken1,
                                          "Device_Time": date.today().strftime("%Y/%m/%d") + 'T' + datetime.now().strftime("%H:%M:%S"),
                                          "Created_on" : " ", 
                                          "METER_SW": self.reading[0],   "PR_PASS": self.reading[1],  "CON_MODE": self.reading[2],
                                          "CT_R": self.reading[3],   "PT_R": self.reading[4],  "BAUD": self.reading[5],
                                          "COM_ADR": self.reading[6]}
                                          
                messageJson = json.dumps(message)
                myAWSIoTMQTTClient.publish(topic_config, messageJson, 1)
             
            #Logic to parse Critical parameters  
            else :
                ret = "\n********************************************************\n"
                ret += "#{}\n".format(self.reading[0])
                ret += "Volts:{:.3f}\t{:.3f}\t{:.3f}\n".format(self.reading[1], self.reading[2], self.reading[3])
                ret += "---------Volts----------------------------------------------\n"
                ret += "Amps:{:.3f}\t{:.3f}\t        {:.3f}\n".format(self.reading[4], self.reading[5], self.reading[6])
                ret += "--------------------------------------------------------\n"
                if (flag == 1) :
                    message = {"Critical" : "Y", "Version" : 3,
                                              "Ken": ken1,
                                              "Device_Time": date.today().strftime("%Y/%m/%d") + 'T' + datetime.now().strftime("%H:%M:%S"),
                                              "Created_on" : " ", 
                                              "V_R": self.reading[1],   "V_Y": self.reading[2],  "V_B": self.reading[3],
                                              "I_R": self.reading[4],   "I_Y": self.reading[5],  "I_B": self.reading[6]}
                    flag = 0
                    messageJson = json.dumps(message)
                    myAWSIoTMQTTClient.publish(topic_data, messageJson, 1)
                    logging.info(ret)

        #Logic to parse Alert messages 
        elif (length == 41) :
            global V_R_past
            global V_Y_past
            global V_B_past
        
            i = 0
            ret = "\n*****************Threshold Alert***************************\n"
            ret += "Volts :{}\t\t{}\t{}\n".format(self.reading[0], self.reading[1], self.reading[2])
            ret += "-------------------------------------------------------\n"
            ret += "Amps  :{}\t\t{}\t{}\n".format(self.reading[3], self.reading[4], self.reading[5])
            ret += "--------------------------------------------------------\n"
            #ret += "Pow_F :{}\t Freq :{}\t".format(self.reading[6], self.reading[7])

            # Comapare if there is some change in alert message i.e. new alert or recovery      
            if(self.reading[0] != V_R_past):
                var = "V_R"
                i = 0
                V_R_past = self.reading[0]
            elif(self.reading[1] != V_Y_past):
                var = "V_Y"
                i = 1
                V_Y_past = self.reading[1]
            elif(self.reading[2] != V_B_past):
                var = "V_B"
                i = 2
                V_B_past = self.reading[2]
            else :
                i = 3
                
            if(i < 3) and (flag == 0)  :  
                message = {"Critical" : "Y", "Version" : 3,
                                          "Ken": ken1,
                                          "Device_time": date.today().strftime("%Y/%m/%d") + 'T' + datetime.now().strftime("%H:%M:%S"),
                                          "Created_on" : date.today().strftime("%Y/%m/%d"), var : self.reading[i]}
                flag = 1
                messageJson = json.dumps(message)
                myAWSIoTMQTTClient.publish(topic_alert, messageJson, 1)
                logging.info(ret)         
        else :
            ret = "\n*****************invallid data*************************\n" #some time data comes with Stidi address 1 & length 61. 
            
        return ret

import unittest

#run it with command python3 -m unittest hydro_readings 
class TestSensors(unittest.TestCase):

    def setUp(self):
        log_level = logging.DEBUG

        logging.basicConfig(format='Date-Time : %(asctime)s : %(filename)s \
            - %(funcName)s - %(lineno)d - %(message)s',
                            level=log_level)

    #@unittest.skip("skipping")
    def test_a(self):
        hr = HydroReading(b'\x1a\x00\x00\x00\xdb\x0f\x49\x40\xbd\x1b\xcf\x3f')
        idx, temp, height = hr.get()
        self.assertEqual(idx, 26)
        self.assertEqual(temp, 3.1415927410125732)
        self.assertEqual(height, 1.6180340051651)
        self.assertEqual(repr(hr), '#26\t3.1415927410125732\t1.6180340051651')

        hr2 = HydroReading("1a000000db0f4940bd1bcf3f", True)
        idx2, temp2, height2 = hr2.get()
        self.assertEqual(idx2, 26)
        self.assertEqual(temp2, 3.1415927410125732)
        self.assertEqual(height2, 1.6180340051651)
        self.assertEqual(repr(hr2), '#26\t3.1415927410125732\t1.6180340051651')

        #real measurement also tested
        hr3 = HydroReading("06000000754db541fcc7183f", True)
        idx3, temp3, height3 = hr3.get()
        self.assertEqual(idx3, 6)
        self.assertEqual(temp3, 22.66282081604004)
        self.assertEqual(height3, 0.5968015193939209)
        self.assertEqual(repr(hr3), '#6\t22.66282081604004\t0.5968015193939209')



    #@unittest.skip("skipping")
    def test_b(self):
        er = EnergyReading("50000000cd4c7f4300c08043333380438fc2753d5c8fe23f52b87e400000b0420000c040000060410000c042000028c200000000000082c200005842355eba3e0000803fe17a14be8d974e3fd7a34842cdcc9d4266867144", True)
        data = er.get()
        self.assertEqual(data[0], 80)
        self.assertAlmostEqual(data[1], 255.3, places=3)
        self.assertAlmostEqual(data[2], 257.5, places=3)
        self.assertAlmostEqual(data[3], 256.4, places=3)
        self.assertAlmostEqual(data[4], 0.06, places=3)
        self.assertAlmostEqual(data[5], 1.77, places=3)
        self.assertAlmostEqual(data[6], 3.98, places=3)
        self.assertAlmostEqual(data[7], 88, places=3)
        self.assertAlmostEqual(data[8], 6, places=3)
        self.assertAlmostEqual(data[9], 14, places=3)
        self.assertAlmostEqual(data[10], 96, places=3)
        self.assertAlmostEqual(data[11], -42, places=3)
        self.assertAlmostEqual(data[12], 0, places=3)
        self.assertAlmostEqual(data[13], -65, places=3)
        self.assertAlmostEqual(data[14], 54, places=3)
        self.assertAlmostEqual(data[15], 0.364, places=3)
        self.assertAlmostEqual(data[16], 1, places=3)
        self.assertAlmostEqual(data[17], -0.145, places=3)
        self.assertAlmostEqual(data[18], 0.807, places=3)
        self.assertAlmostEqual(data[19], 50.16, places=3)
        self.assertAlmostEqual(data[20], 78.9, places=3)
        self.assertAlmostEqual(data[21], 966.1, places=3)

        repr(er)

        #self.assertEqual(repr(er), '3.1415927410125732\t1.6180340051651')
        



if __name__ == "__main__":

    parser = argparse.ArgumentParser()
    
    parser.add_argument('-sa', '--sensor_address',
                        help="Specify what is the sensor node", type=int, default=650085437)      # Change this for other devices
    parser.add_argument('-c', '--config',
                        help="Input configuration file", type=str, default="config.json") 
    parser.add_argument('-al', '--anylift_id',
                        help="Anylift unique ID", type=str, default=778566345629588)    # Change this for other devices
    parser.add_argument('-s', '--sensor_type',
                        help="Type of sensor and application running", type=str, default="energy")
    parser.add_argument('-ip', '--anylift_ip',
                        help="Use local network and Anylift local MQTT broker", type=str)


    args = parser.parse_args()

    logging.basicConfig(level=logging.DEBUG, filename='sensor_debug.log', filemode='w', format='Date-Time : %(asctime)s : %(filename)s - %(funcName)s - %(lineno)d - %(message)s')

    logging.debug(args)

    print("Connecting to MQTT broker....")
    if args.config is not None:
        # Opening JSON file
        f = open('config.json')
        # returns JSON object as
        # a dictionary
        data = json.load(f)
        print(data)

    mid = AnyliftMiddleware()
    
    try:

        if args.anylift_ip is not None:

            print("....Anylift local network (IP: {}).....".format(args.anylift_ip))

            #Connect to broker running on the device (dev-test)
            mid.connect(host=args.anylift_ip,
                port=1883,
                username="",
                password="",
                gateway_id = None,
                network_address=895
                )
        else:
        
            print("....IBM cloud.....")
            #Connect to IoT platform
            mid.connect(host="lx1oxl.messaging.internetofthings.ibmcloud.com",
                    port=8883,
                    username="a-lx1oxl-bpmtxgcoko",
                    password="FdR&QRbQvzlaJ+ku4@",
                    gateway_id = args.anylift_id,
                    network_address=895
                    )      
        
    except:
        exit(1)


    info = mid.info()
    logging.info(info['sw_version'])

    assert('Mesh' in info['sw_version'])

    print("Connected to Anylift: {}".format(args.anylift_id))
    print("SW version for Anylift: {}".format(info['sw_version']))

    '''
    print("List all nodes")

    #todo check if it is already running yabb330_app
    nodes = mid.list_nodes(amount=1)

    print(nodes)
    '''

    print("Data from node: {}".format(args.sensor_address))

    print("Using format for application: {}".format(args.sensor_type))

    if "energy" in args.sensor_type:
        ep = 40
    else:
        ep = 30

    print("Wait for events on endpoints: {}".format(ep))


    try:
        while True: 
            messages = mid.receive(address = args.sensor_address,
                      source_endpoint = ep, destination_endpoint = ep,
                      timeout = 300, amount = 1)

            #print(messages)        
                        
            if "energy" in args.sensor_type:
                a,b = messages[0].split(":")
                meas = EnergyReading(a, b, True)
                              
            else:
                meas = HydroReading(messages[0], True)
            # Sending energy data to ThingsBoard
            #client.publish('v1/devices/me/telemetry', json.dumps(sensor_data), 1)

            print(repr(meas))
                        
            
    except KeyboardInterrupt:
        print('interrupted!')

    logging.info("Done!")

    exit(0)


